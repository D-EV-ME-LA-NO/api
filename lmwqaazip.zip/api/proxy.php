<?php
/**
 * api/proxy.php — Generic URL proxy (for subtitle VTT files and similar)
 *
 * GET /api/proxy?url=https://...
 *
 * يُستخدم بالبلاير كـ fallback لتحميل ملفات الترجمة (.vtt / .srt)
 * عند وجود قيود CORS على الدومين الأصلي.
 */

ini_set('display_errors', '0');
ini_set('log_errors', '1');

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, HEAD, OPTIONS');
header('Access-Control-Allow-Headers: Range, Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

$url = trim($_GET['url'] ?? '');

if (!$url) {
    http_response_code(400);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'missing url']);
    exit;
}

// ── Validate: must be http/https ──────────────────────────────────────────────
if (!preg_match('#^https?://#i', $url)) {
    http_response_code(400);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'invalid url']);
    exit;
}

// ── Block private/local IPs ───────────────────────────────────────────────────
$host = strtolower(parse_url($url, PHP_URL_HOST) ?? '');
if (!$host) {
    http_response_code(400);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'invalid host']);
    exit;
}

$ip = @gethostbyname($host);
if ($ip && !filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
    http_response_code(403);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'private address blocked']);
    exit;
}

// ── Fetch ─────────────────────────────────────────────────────────────────────
$UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_MAXREDIRS      => 4,
    CURLOPT_TIMEOUT        => 20,
    CURLOPT_CONNECTTIMEOUT => 8,
    CURLOPT_USERAGENT      => $UA,
    CURLOPT_REFERER        => 'https://www.lookmovie2.to/',
    CURLOPT_HTTPHEADER     => [
        'Accept: text/vtt,text/plain,*/*',
        'Origin: https://www.lookmovie2.to',
        'Sec-Fetch-Dest: empty',
        'Sec-Fetch-Mode: cors',
        'Sec-Fetch-Site: cross-site',
    ],
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => false,
]);

$body     = curl_exec($ch);
$httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
$ctype    = (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
curl_close($ch);

if (!$body || $httpCode < 200 || $httpCode >= 400) {
    http_response_code(502);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'upstream returned ' . $httpCode]);
    exit;
}

// ── Detect content type ───────────────────────────────────────────────────────
$path = strtolower(parse_url($url, PHP_URL_PATH) ?? '');
if (!$ctype || $ctype === 'application/octet-stream') {
    if (str_ends_with($path, '.vtt')) {
        $ctype = 'text/vtt; charset=utf-8';
    } elseif (str_ends_with($path, '.srt')) {
        $ctype = 'text/plain; charset=utf-8';
    }
}

header('Content-Type: ' . ($ctype ?: 'text/plain; charset=utf-8'));
header('Content-Length: ' . strlen($body));
header('Cache-Control: public, max-age=3600');
echo $body;
