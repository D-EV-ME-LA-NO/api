<?php
/*
 * بروكسي الترجمة — يجلب ملفات VTT/SRT ويعيد كتابتها لضمان
 * سلامة CORS وإضافة ترويسة Access-Control-Allow-Origin
 */
error_reporting(0);
define('UA', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36');

$url = $_GET['url'] ?? '';
if ($url === '') { http_response_code(400); echo 'Missing url'; exit; }
$url = rawurldecode($url);
if (strpos($url, 'http') !== 0 && strpos($url, 'data:') !== 0) {
    http_response_code(400); echo 'Invalid url'; exit;
}

// data: URI
if (strpos($url, 'data:') === 0) {
    header('Content-Type: text/vtt; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    echo urldecode(explode(',', $url, 2)[1] ?? '');
    exit;
}

$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_MAXREDIRS      => 5,
    CURLOPT_TIMEOUT        => 30,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_ENCODING       => 'gzip, deflate, br',
    CURLOPT_USERAGENT      => UA,
]);
$body = curl_exec($ch);
$ct = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
curl_close($ch);

if ($body === false || $body === '') {
    http_response_code(404);
    echo 'Failed to load subtitle: ' . $url;
    exit;
}

// إزالة WEBVTT المكررة عند الدمج
$body = ltrim($body, "\xEF\xBB\xBF");
if (stripos($body, 'WEBVTT') === false && stripos($ct ?? '', 'vtt') !== false) {
    $body = "WEBVTT\n\n" . $body;
}

header('Content-Type: text/vtt; charset=utf-8');
header('Access-Control-Allow-Origin: *');
echo $body;
