<?php
/**
 * Unified provider probe.
 *
 * The player calls this endpoint once. It checks every configured provider,
 * keeps failures in the response, and returns a consistent provider array:
 * { id, name, ok, status, sources, subtitles, subtitleCount, error, response }.
 */
require_once __DIR__ . '/../config.php';
set_time_limit(25);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Access-Control-Allow-Origin: *');

$type = ($_GET['type'] ?? 'movie') === 'tv' ? 'tv' : 'movie';
$id = (int)($_GET['id'] ?? 0);
$season = max(1, (int)($_GET['season'] ?? 1));
$episode = max(1, (int)($_GET['episode'] ?? 1));
$token = (string)($_GET['_st'] ?? '');

if ($id < 1 || !sec_verify_stream_token($token, $type, $id)) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'Access denied. Please reload the watch page.']);
    exit;
}

$providers = [
    ['id' => 'lookmovie', 'name' => 'LookMovie', 'path' => '/api/lookmovie/index.php'],
    ['id' => 'animecurx', 'name' => 'AnimeCurX', 'path' => '/api/animecurx/index.php'],
];

$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$publicOrigin = $scheme . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost');
$port = (int)($_SERVER['SERVER_PORT'] ?? 5000);
// The public PHP server is single-request while it is handling this
// aggregator. Provider requests therefore use the companion internal server.
$localBase = 'http://127.0.0.1:5001';
$cookie = $_SERVER['HTTP_COOKIE'] ?? '';
$handles = [];
$responses = [];

function unified_request_url(array $provider): string {
    global $localBase, $type, $id, $season, $episode, $token;
    $query = [
        'type' => $type,
        'id' => $id,
        '_st' => $token,
        '_ts' => time(),
        '_nonce' => bin2hex(random_bytes(16)),
    ];
    if ($type === 'tv') {
        $query['season'] = $season;
        $query['episode'] = $episode;
    }
    if ($provider['id'] === 'animecurx') {
        $query['action'] = 'streams';
        $query['format'] = 'player';
        if ($type === 'tv') {
            $query['s'] = $season;
            $query['e'] = $episode;
        }
    }
    return $localBase . $provider['path'] . '?' . http_build_query($query);
}

function unify_url(string $url): string {
    global $publicOrigin, $localBase;
    if ($url === '') return '';
    if (str_starts_with($url, $localBase . '/')) {
        return $publicOrigin . substr($url, strlen($localBase));
    }
    return $url;
}

function normalize_unified_provider(array $provider, ?array $payload, int $httpCode): array {
    $sources = [];
    $subtitles = [];
    $error = '';

    if (is_array($payload) && isset($payload['source']) && is_array($payload['source'])) {
        $source = $payload['source'];
        if (!empty($source['qualities']) && is_array($source['qualities'])) {
            foreach ($source['qualities'] as $quality) {
                if (!empty($quality['url'])) {
                    $sources[] = [
                        'url' => unify_url((string)$quality['url']),
                        'label' => $quality['label'] ?? ($quality['quality'] ?? 'HD'),
                        'quality' => $quality['quality'] ?? ($quality['label'] ?? ''),
                        'type' => $quality['type'] ?? 'hls',
                        'provider' => $source['provider'] ?? $provider['id'],
                    ];
                }
            }
        } elseif (!empty($source['m3u8'])) {
            $sources[] = [
                'url' => unify_url((string)$source['m3u8']),
                'label' => $source['quality'] ?? 'HD',
                'type' => $source['type'] ?? 'hls',
                'provider' => $source['provider'] ?? $provider['id'],
            ];
        }
        $subtitles = is_array($source['subtitles'] ?? null) ? $source['subtitles'] : [];
    } elseif (is_array($payload) && is_array($payload['sources'] ?? null)) {
        foreach ($payload['sources'] as $source) {
            if (!empty($source['url'])) {
                $source['url'] = unify_url((string)$source['url']);
                $sources[] = $source;
            }
        }
        $subtitles = is_array($payload['subtitles'] ?? null) ? $payload['subtitles'] : [];
    }

    foreach ($subtitles as &$subtitle) {
        if (is_array($subtitle) && isset($subtitle['url'])) {
            $subtitle['url'] = unify_url((string)$subtitle['url']);
        }
    }
    unset($subtitle);

    if (!$sources) {
        $error = (string)($payload['error'] ?? '');
        if ($error === '' && $httpCode !== 200) $error = 'HTTP ' . $httpCode;
        if ($error === '') $error = 'No playable sources';
    }

    return [
        'id' => $provider['id'],
        'name' => $provider['name'],
        'ok' => !empty($sources),
        'status' => !empty($sources) ? 'online' : 'offline',
        'sources' => array_values($sources),
        'subtitles' => array_values($subtitles),
        'subtitleCount' => count($subtitles),
        'error' => $error ?: null,
        'response' => $payload,
    ];
}

if (function_exists('curl_multi_init')) {
    $multi = curl_multi_init();
    foreach ($providers as $provider) {
        $ch = curl_init(unified_request_url($provider));
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 3,
            // One slow external provider must not block the complete provider
            // matrix or make the player wait indefinitely.
            CURLOPT_CONNECTTIMEOUT => 3,
            CURLOPT_TIMEOUT => 12,
            CURLOPT_HTTPHEADER => array_filter([
                'Accept: application/json',
                'Host: ' . ($_SERVER['HTTP_HOST'] ?? 'localhost'),
                $cookie ? 'Cookie: ' . $cookie : null,
            ]),
            CURLOPT_USERAGENT => 'HZFlix-Provider-Check/1.0',
        ]);
        $handles[$provider['id']] = $ch;
        curl_multi_add_handle($multi, $ch);
    }
    do {
        $status = curl_multi_exec($multi, $running);
        if ($running) curl_multi_select($multi, 1.0);
    } while ($running && $status === CURLM_OK);

    foreach ($providers as $provider) {
        $ch = $handles[$provider['id']];
        $body = curl_multi_getcontent($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $payload = json_decode($body, true);
        $responses[] = normalize_unified_provider($provider, is_array($payload) ? $payload : null, $code);
        curl_multi_remove_handle($multi, $ch);
        curl_close($ch);
    }
    curl_multi_close($multi);
} else {
    foreach ($providers as $provider) {
        $body = @file_get_contents(unified_request_url($provider));
        $payload = json_decode((string)$body, true);
        $responses[] = normalize_unified_provider($provider, is_array($payload) ? $payload : null, $body ? 200 : 502);
    }
}

echo json_encode([
    'ok' => (bool)array_filter($responses, fn($item) => !empty($item['ok'])),
    'providers' => $responses,
], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);