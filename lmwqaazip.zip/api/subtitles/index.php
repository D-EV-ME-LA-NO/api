<?php
/**
 * api/subtitles/index.php
 *
 * GET /api/subtitles/index.php?type=movie&id={tmdb}
 * GET /api/subtitles/index.php?type=tv&id={tmdb}&season={s}&episode={e}
 * (وأيضاً عبر المسارات المختصرة /subtitles/movie/{id} و /subtitles/tv/{id}/{s}/{e})
 *
 * يرجع: [{"label":"Arabic","url":"/api/proxy.php?url=..."}, ...]
 *
 * الترجمات مشتركة لكل سيرفرات التشغيل: تُجمع هنا من (VidFast + AnimeCurX + LookMovie)
 * حتى تبقى ظاهرة مهما كان السيرفر المختار، وحتى لو فشل المشغّل بجلب ترجمته.
 */

if (!defined('APP_SECRET')) require_once __DIR__ . '/../../config.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Cache-Control: public, max-age=300');

$type    = ($_GET['type'] ?? 'movie') === 'tv' ? 'tv' : 'movie';
$id      = (int)($_GET['id'] ?? 0);
$season  = isset($_GET['season'])  ? (int)$_GET['season']  : 1;
$episode = isset($_GET['episode']) ? (int)$_GET['episode'] : 1;

if (!$id) { echo json_encode([]); exit; }

$subs = [];
$seen = [];

function subs_add(&$subs, &$seen, $label, $lang, $source, $url) {
    $url = trim((string)$url);
    if ($url === '' || !preg_match('#^https?://#i', $url)) return;
    if (isset($seen[$url])) return;
    $seen[$url] = true;
    $label = trim((string)$label);
    if ($label === '') $label = trim((string)$lang);
    if ($label === '') $label = 'Subtitle';
    $subs[] = [
        'label'    => $label,
        'language' => (string)$lang,
        'encoding' => 'UTF-8',
        'format'   => 'vtt',
        'source'   => $source,
        'url'      => '/api/proxy.php?url=' . rawurlencode($url),
        'file'     => '/api/proxy.php?url=' . rawurlencode($url),
    ];
}

function subs_http($url, $headers = [], $post = null, $timeout = 15) {
    $ch = curl_init($url);
    $opts = [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS      => 5,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_TIMEOUT        => $timeout,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_ENCODING       => '',
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_USERAGENT      => 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
    ];
    if ($post !== null) {
        $opts[CURLOPT_POST] = true;
        $opts[CURLOPT_POSTFIELDS] = is_array($post) ? json_encode($post) : $post;
        $opts[CURLOPT_HTTPHEADER] = array_merge(['Content-Type: application/json'], $headers);
    }
    curl_setopt_array($ch, $opts);
    $body = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ['code' => $code, 'body' => $body];
}

// ── 1) VidFast (أسرع مصدر وأشمله) ────────────────────────────────────────────
$vidfast_params = 'id=' . rawurlencode((string)$id);
if ($type === 'tv') {
    $vidfast_params .= '&type=tv&s=' . rawurlencode((string)$season)
        . '&e=' . rawurlencode((string)$episode);
}
$vf = subs_http('https://vidfast.vc/wyzie?' . $vidfast_params, [
    'Accept: application/json',
    'Referer: https://vidfast.vc/',
]);
if ($vf['code'] >= 200 && $vf['code'] < 300) {
    $vf_json = @json_decode((string)$vf['body'], true);
    if (is_array($vf_json)) {
        foreach ($vf_json as $row) {
            if (!is_array($row)) continue;
            subs_add($subs, $seen,
                $row['display'] ?? ($row['language'] ?? ''),
                $row['language'] ?? '',
                'VidFast',
                $row['url'] ?? ''
            );
        }
    }
}

// ── 2) AnimeCurX ─────────────────────────────────────────────────────────────
$acx = subs_http('https://7movies.in/api/playback-token', [], [
    'tmdbId'  => $id,
    'type'    => $type,
    'season'  => $type === 'tv' ? $season : null,
    'episode' => $type === 'tv' ? $episode : null,
], 12);
$acx_token = null;
if ($acx['code'] === 200) {
    $acx_json  = @json_decode((string)$acx['body'], true);
    $acx_token = $acx_json['token'] ?? null;
}
if ($acx_token) {
    $acx_path = $type === 'tv' ? "tv/$id/$season/$episode" : "movie/$id";
    $acx_page = subs_http(
        'https://embed.animecurx.tech/embed/' . $acx_path
            . '?source=0&mobileSheets=true&title=&token=' . rawurlencode($acx_token),
        ['Referer: https://embed.animecurx.tech/']
    );
    if ($acx_page['code'] === 200 && $acx_page['body']) {
        if (preg_match_all(
            '/\{"code"\s*:\s*"([^"]+)"\s*,\s*"label"\s*:\s*"([^"]+)"\s*,\s*"url"\s*:\s*"([^"]+)"\s*\}/',
            (string)$acx_page['body'], $acx_m, PREG_SET_ORDER
        )) {
            foreach ($acx_m as $mm) {
                $acx_url = str_replace('\\/', '/', trim($mm[3]));
                if ($acx_url !== '' && !preg_match('#^https?://#i', $acx_url)) {
                    $acx_url = 'https://embed.animecurx.tech'
                        . (strpos($acx_url, '/') === 0 ? '' : '/') . $acx_url;
                }
                subs_add($subs, $seen, $mm[2], $mm[1], 'AnimeCurX', $acx_url);
            }
        }
    }
}

// ── 3) LookMovie (من الكاش فقط — المشغّل يدمج ترجمة lookmovie مباشرة عند التشغيل)
$cache_key  = $type === 'tv' ? "{$type}-{$id}-{$season}-{$episode}" : "{$type}-{$id}";
$cache_file = __DIR__ . '/../../.cache/lookmovie/' . $cache_key . '.json';
$lm_subs = [];
if (is_file($cache_file)) {
    $cached  = @json_decode((string)@file_get_contents($cache_file), true);
    $lm_subs = $cached['source']['subtitles'] ?? [];
}
foreach ((array)$lm_subs as $row) {
    if (!is_array($row)) continue;
    $u = (string)($row['url'] ?? ($row['file'] ?? ''));
    if ($u === '') continue;
    if (!preg_match('#^https?://#i', $u)) {
        if (!isset($seen[$u])) {
            $seen[$u] = true;
            $row['file']   = $u;
            $row['source'] = $row['source'] ?? 'LookMovie';
            $subs[] = $row;
        }
        continue;
    }
    subs_add($subs, $seen, $row['label'] ?? '', $row['language'] ?? '', 'LookMovie', $u);
}

echo json_encode(array_values($subs), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
