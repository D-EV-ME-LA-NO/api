<?php
/**
 * api/auth.php
 *
 * POST /api/auth
 *
 * يُستخدم من المشغّل للحصول على session token.
 * المشروع يعمل بمصادقة محلية كاملة فلا يحتاج توكن خارجي،
 * لذلك نُعيد null ليتجاهله المشغّل ويُكمل عمله.
 */

if (!defined('APP_SECRET')) require_once __DIR__ . '/../config.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

echo json_encode(['ok' => true, 'token' => null]);
