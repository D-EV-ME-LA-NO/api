<?php
/**
 * صفحة المشاهدة — تستخدم نفس مشغّل المشروع السابق (Vyla Player)
 * الموجود في /player مع نفس نظام الترجمة والإعدادات.
 */
$type    = ($_GET['type'] ?? 'movie') === 'tv' ? 'tv' : 'movie';
$id      = (int)($_GET['id'] ?? 0);
$season  = isset($_GET['season'])  && $_GET['season']  !== '' ? (int)$_GET['season']  : 1;
$episode = isset($_GET['episode']) && $_GET['episode'] !== '' ? (int)$_GET['episode'] : 1;

if (!$id) { header('Location: /'); exit; }

$d = tmdb_details($type, $id);
if (!$d || empty($d['id'])) { http_response_code(404); echo 'Not found'; exit; }

$title      = $d['title'] ?? $d['name'] ?? '';
$slug       = $id . '-' . slugify($title);
$page_title = 'Watch · ' . $title;
db_increment_view($id, $type);

$back_url = $type === 'movie' ? '/movie/' . $slug : '/tv-show/' . $slug;

// معطيات المشغّل: type, id, season, episode, title + stream auth token
$stream_token = sec_stream_token($type, $id);
$player_qs = 'type=' . $type . '&id=' . $id
    . ($type === 'tv' ? '&season=' . $season . '&episode=' . $episode : '')
    . '&title=' . urlencode($title)
    . '&_st='   . urlencode($stream_token);
$player_src = '/player/index.html?' . $player_qs;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, viewport-fit=cover"/>
<title><?= htmlspecialchars($page_title) ?> · <?= SITE_NAME ?></title>
<link rel="icon" type="image/svg+xml" href="data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='80' font-size='90' font-family='Arial' font-weight='900' fill='%23e50914'>HZ</text></svg>"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>
<style>
  *{margin:0;padding:0;box-sizing:border-box}
  html,body{width:100%;height:100%;background:#000;overflow:hidden;font-family:Inter,system-ui,sans-serif}
  #player-frame{position:fixed;inset:0;width:100%;height:100%;border:0;background:#000}
  .wp-back{position:fixed;top:max(14px,env(safe-area-inset-top));left:max(14px,env(safe-area-inset-left));z-index:50;
    display:inline-flex;align-items:center;gap:8px;padding:9px 14px;border-radius:999px;
    background:rgba(0,0,0,.55);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);
    border:1px solid rgba(255,255,255,.14);color:#fff;text-decoration:none;font-size:13px;font-weight:600;
    opacity:0;transform:translateY(-6px);transition:opacity .25s ease,transform .25s ease;pointer-events:none}
  .wp-back.show{opacity:1;transform:none;pointer-events:auto}
  .wp-back:hover{background:rgba(0,0,0,.75)}
</style>
</head>
<body>
  <a class="wp-back show" id="wpBack" href="<?= htmlspecialchars($back_url) ?>">
    <i class="fa-solid fa-chevron-left"></i><span><?= htmlspecialchars($title) ?></span>
  </a>
  <iframe id="player-frame"
          src="<?= htmlspecialchars($player_src) ?>"
          allow="autoplay; fullscreen; picture-in-picture; encrypted-media; accelerometer; gyroscope"
          allowfullscreen></iframe>
<script>
  // إخفاء زر الرجوع بعد سكون الماوس (نفس سلوك شريط العنوان في المشغّل)
  var back = document.getElementById('wpBack'), t;
  function ping(){ back.classList.add('show'); clearTimeout(t); t = setTimeout(function(){ back.classList.remove('show'); }, 3200); }
  ['mousemove','touchstart','keydown'].forEach(function(e){ window.addEventListener(e, ping, {passive:true}); });
  ping();
</script>
</body>
</html>
