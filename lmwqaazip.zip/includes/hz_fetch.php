<?php
/**
 * includes/hz_fetch.php
 * دالة HTTP مشتركة — تستخدم curl إن توفّر، وإلا تعود إلى file_get_contents.
 * مفيدة على استضافات مثل InfinityFree التي تقيّد curl.
 */

if (!function_exists('hz_get')) {
    /**
     * GET request — يُعيد ['body'=>string, 'code'=>int, 'ok'=>bool]
     */
    function hz_get(string $url, array $opts = []): array {
        $timeout = $opts['timeout'] ?? 5;
        $headers = $opts['headers'] ?? [];
        $ua      = $opts['ua']      ?? 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';
        $follow  = $opts['follow']  ?? true;
        $verify  = $opts['verify']  ?? false;

        // ── محاولة curl ───────────────────────────────────────────────────────
        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT        => $timeout,
                CURLOPT_CONNECTTIMEOUT => min($timeout, 5),
                CURLOPT_FOLLOWLOCATION => $follow,
                CURLOPT_MAXREDIRS      => 5,
                CURLOPT_ENCODING       => '',
                CURLOPT_HTTPHEADER     => array_merge(['User-Agent: ' . $ua], $headers),
                CURLOPT_SSL_VERIFYPEER => $verify,
                CURLOPT_SSL_VERIFYHOST => $verify ? 2 : 0,
            ]);
            $body = curl_exec($ch);
            $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $err  = curl_error($ch);
            curl_close($ch);
            if ($body !== false && empty($err)) {
                return ['body' => (string)$body, 'code' => $code, 'ok' => $code >= 200 && $code < 400];
            }
        }

        // ── احتياط: file_get_contents ─────────────────────────────────────────
        $raw_headers = 'User-Agent: ' . $ua;
        foreach ($headers as $h) {
            $raw_headers .= "\r\n" . $h;
        }
        $ctx = stream_context_create([
            'http' => [
                'method'          => 'GET',
                'header'          => $raw_headers,
                'timeout'         => $timeout,
                'follow_location' => $follow ? 1 : 0,
                'max_redirects'   => 5,
                'ignore_errors'   => true,
            ],
            'ssl'  => ['verify_peer' => false, 'verify_peer_name' => false],
        ]);
        $body = @file_get_contents($url, false, $ctx);
        if ($body === false) {
            return ['body' => '', 'code' => 0, 'ok' => false];
        }
        $code = 200;
        if (!empty($http_response_header)) {
            foreach ($http_response_header as $h) {
                if (preg_match('/^HTTP\/[\d.]+ (\d+)/i', $h, $m)) {
                    $code = (int)$m[1];
                }
            }
        }
        return ['body' => $body, 'code' => $code, 'ok' => $code >= 200 && $code < 400];
    }
}

if (!function_exists('hz_post')) {
    /**
     * POST request — يُعيد ['body'=>string, 'code'=>int, 'ok'=>bool]
     *
     * @param string|array $data  string body أو مصفوفة (ترسل كـ JSON)
     */
    function hz_post(string $url, $data = '', array $opts = []): array {
        $timeout  = $opts['timeout']      ?? 5;
        $headers  = $opts['headers']      ?? [];
        $ua       = $opts['ua']           ?? 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';
        $follow   = $opts['follow']       ?? true;
        $verify   = $opts['verify']       ?? false;
        $json     = is_array($data);
        $body_str = $json ? json_encode($data) : (string)$data;

        if ($json && !in_array_ci('Content-Type', $headers)) {
            $headers[] = 'Content-Type: application/json';
        }

        // ── curl ─────────────────────────────────────────────────────────────
        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST           => true,
                CURLOPT_POSTFIELDS     => $body_str,
                CURLOPT_TIMEOUT        => $timeout,
                CURLOPT_CONNECTTIMEOUT => min($timeout, 5),
                CURLOPT_FOLLOWLOCATION => $follow,
                CURLOPT_MAXREDIRS      => 5,
                CURLOPT_ENCODING       => '',
                CURLOPT_HTTPHEADER     => array_merge(['User-Agent: ' . $ua], $headers),
                CURLOPT_SSL_VERIFYPEER => $verify,
                CURLOPT_SSL_VERIFYHOST => $verify ? 2 : 0,
            ]);
            $body = curl_exec($ch);
            $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $err  = curl_error($ch);
            curl_close($ch);
            if ($body !== false && empty($err)) {
                return ['body' => (string)$body, 'code' => $code, 'ok' => $code >= 200 && $code < 400];
            }
        }

        // ── احتياط: file_get_contents ─────────────────────────────────────────
        $raw_headers = 'User-Agent: ' . $ua . "\r\nContent-Length: " . strlen($body_str);
        foreach ($headers as $h) { $raw_headers .= "\r\n" . $h; }
        $ctx = stream_context_create([
            'http' => [
                'method'          => 'POST',
                'header'          => $raw_headers,
                'content'         => $body_str,
                'timeout'         => $timeout,
                'follow_location' => $follow ? 1 : 0,
                'max_redirects'   => 5,
                'ignore_errors'   => true,
            ],
            'ssl'  => ['verify_peer' => false, 'verify_peer_name' => false],
        ]);
        $body = @file_get_contents($url, false, $ctx);
        if ($body === false) {
            return ['body' => '', 'code' => 0, 'ok' => false];
        }
        $code = 200;
        if (!empty($http_response_header)) {
            foreach ($http_response_header as $h) {
                if (preg_match('/^HTTP\/[\d.]+ (\d+)/i', $h, $m)) { $code = (int)$m[1]; }
            }
        }
        return ['body' => $body, 'code' => $code, 'ok' => $code >= 200 && $code < 400];
    }
}

// مساعد داخلي
if (!function_exists('in_array_ci')) {
    function in_array_ci(string $needle, array $arr): bool {
        $nl = strtolower($needle);
        foreach ($arr as $v) {
            if (strpos(strtolower((string)$v), $nl) !== false) return true;
        }
        return false;
    }
}
