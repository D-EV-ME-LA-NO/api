(function () {
  var v1 = {
    ENTER: 13,
    LEFT: 37,
    RIGHT: 39,
    UP: 38,
    DOWN: 40,
    BACK: 8,
    PLAY_PAUSE: 179,
    PLAY: 415,
    PAUSE: 19,
    STOP: 413,
    FAST_FWD: 417,
    REWIND: 412,
    INFO: 457,
    RED: 403,
    GREEN: 404,
    YELLOW: 405,
    BLUE: 406,
  };
  var v2 = [];
  var v3 = -1;
  var v4 = false;
  var v5 = 0;
  var v6 = false;
  var v7 = null;
  var v8 = null;
  var v9 = 0;
  function v10() {
    var v34 = navigator.userAgent;
    return (
      /SmartTV|SMART-TV|HbbTV|Tizen|WebOS|TV|NetCast|BRAVIA|Philips|SonyDTV|MSPIE|Maple|Opera TV|AVS|OTV|AppleTV/.test(
        v34,
      ) ||
      (navigator.maxTouchPoints === 0 &&
        !/Mobi/.test(v34) &&
        window.innerWidth >= 1280)
    );
  }
  function v11() {
    if (v4) {
      return;
    }
    v4 = true;
    document.body.classList.add("tv-nav-mode");
    v22();
    if (v3 < 0 && v2.length) {
      v23(0);
    }
  }
  function v12() {
    v4 = false;
    v6 = false;
    document.body.classList.remove("tv-nav-mode");
    document.body.classList.remove("tv-slider-active");
    v2.forEach(function (arg1) {
      arg1.classList.remove("tv-focused");
    });
    v3 = -1;
  }
  function v13() {
    var v34 = document.getElementById("settings-modal-wrap");
    return v34 && v34.classList.contains("open");
  }
  function v14() {
    var v34 = document.getElementById("ep-panel");
    return v34 && v34.classList.contains("open");
  }
  function v15() {
    return v2[v3] || null;
  }
  function v16(arg1) {
    return arg1 && arg1.tagName === "INPUT" && arg1.type === "range";
  }
  function v17(arg1) {
    return arg1 && arg1.classList && arg1.classList.contains("settings-toggle");
  }
  function v18(arg1, arg2) {
    var v34 = parseFloat(arg1.step) || 1;
    var v35 = parseFloat(arg1.min) || 0;
    var v36 = parseFloat(arg1.max) || 100;
    var v37 = parseFloat(arg1.value);
    v37 = Math.min(v36, Math.max(v35, v37 + arg2 * v34));
    arg1.value = v37;
    arg1.dispatchEvent(
      new Event("input", {
        bubbles: true,
      }),
    );
    arg1.dispatchEvent(
      new Event("change", {
        bubbles: true,
      }),
    );
    haptic(6);
  }
  function v19() {
    var v34 = [
      {
        id: "sub-custom-view",
        back: function () {
          document.getElementById("sub-custom-view").style.display = "none";
          document.getElementById("sub-lang-group-view").style.display = "flex";
        },
      },
      {
        id: "sub-lang-entries-view",
        back: function () {
          document.getElementById("sub-lang-entries-view").style.display =
            "none";
          document.getElementById("sub-lang-group-view").style.display = "flex";
        },
      },
      {
        id: "src-detail-view",
        back: function () {
          document.getElementById("src-detail-view").style.display = "none";
          document.getElementById("src-list-view").style.display = "flex";
        },
      },
    ];
    for (var v35 = 0; v35 < v34.length; v35++) {
      var v36 = document.getElementById(v34[v35].id);
      if (v36 && v36.style.display !== "none" && v36.style.display !== "") {
        return v34[v35];
      }
    }
    return null;
  }
  function v20() {
    var v34 = document.querySelectorAll(".settings-view");
    for (var v35 = 0; v35 < v34.length; v35++) {
      var v36 = v34[v35];
      var v37 = v36.style.display;
      if (v37 === "flex" || v37 === "block") {
        return v36.id;
      }
    }
    return null;
  }
  function v21() {
    var v34 =
      document.getElementById("ep-panel") &&
      document.getElementById("ep-panel").classList.contains("open");
    if (v34) {
      var v35 = document.getElementById("ep-panel-season-view");
      var v36 = document.getElementById("ep-panel-episode-view");
      if (v36 && v36.style.display !== "none") {
        var v37 = document.getElementById("ep-panel-ep-back");
        if (v37) {
          v37.click();
          v9 = Date.now() + 150;
          setTimeout(function () {
            v9 = 0;
            v22();
            if (v2.length) {
              v23(0);
            }
          }, 200);
          return;
        }
      }
      var v38 = document.getElementById("ep-panel-close");
      if (v38) {
        v38.click();
      }
      setTimeout(function () {
        v9 = 0;
        v22();
        if (v2.length) {
          v23(0);
        }
      }, 200);
      return;
    }
    var v39 = v13();
    var v40 = v14();
    if (v39) {
      var v41 = v19();
      if (v41) {
        v41.back();
        v9 = Date.now() + 150;
        setTimeout(function () {
          v9 = 0;
          v22();
          if (v8) {
            var v43 = v2.indexOf(v8);
            if (v43 >= 0) {
              v23(v43);
              return;
            }
          }
          if (v2.length) {
            v23(0);
          }
        }, 200);
        return;
      }
      var v42 = v20();
      if (v42 && v42 !== "settings-view-main") {
        var v37 = document.querySelector(
          "#" + v42 + " .settings-back-btn, #" + v42 + " .svsh-back",
        );
        if (v37) {
          v37.click();
          v9 = Date.now() + 150;
          setTimeout(function () {
            v9 = 0;
            v22();
            if (v8) {
              var v43 = v2.indexOf(v8);
              if (v43 >= 0) {
                v23(v43);
                v9 = Date.now() + 300;
                return;
              }
            }
            if (v2.length) {
              v23(0);
            }
          }, 200);
          return;
        }
      }
      v8 = null;
      var v38 = document.getElementById("settings-close-btn");
      if (v38) {
        v38.click();
      }
      setTimeout(function () {
        v9 = 0;
        v22();
        if (v8) {
          var v43 = v2.indexOf(v8);
          if (v43 >= 0) {
            v23(v43);
            v9 = Date.now() + 300;
            return;
          }
        }
        if (v2.length) {
          v23(0);
        }
      }, 200);
    } else {
      showUI(true);
    }
  }
  function v22() {
    if (Date.now() < v9) {
      return;
    }
    var v34 = v13();
    var v35 =
      document.getElementById("ep-panel") &&
      document.getElementById("ep-panel").classList.contains("open");
    var v36 = v35
      ? document.getElementById("ep-panel")
      : v34
        ? document.getElementById("settings-modal-wrap")
        : document.getElementById("player-controls-wrapper");
    if (!v36) {
      return;
    }
    var v37 = document.getElementById("v");
    var v38 = v37 && v37.paused;
    v2 = Array.from(
      v36.querySelectorAll(
        'button:not([disabled]), [role="button"], .settings-list-item, .settings-tile,.settings-main-item, .ctrl-btn, .sub-lang-group-item, .sub-special-row,.ep-season-row, .ep-panel-ep-row, .quality-row, .quality-auto-row,.src-list-item, .sub-preset-btn, .sub-size-btn, .sub-pos-btn, .sub-bg-btn,input[type="range"], .settings-toggle',
      ),
    ).filter(function (arg1) {
      if (arg1.id === "track-wrap") {
        return false;
      }
      if (arg1.id === "progress-container") {
        return false;
      }
      if (arg1.closest && arg1.closest("#progress-container")) {
        return false;
      }
      var v40 = arg1;
      while (v40) {
        if (v40.style && v40.style.display === "none") {
          return false;
        }
        v40 = v40.parentElement;
      }
      var v41 = arg1.getBoundingClientRect();
      return v41.width > 0 && v41.height > 0;
    });
    if (!v34 && !v35) {
      var v39 = ["btn-play", "skip-segment-inner", "next-ep-inner"];
      if (v38) {
        v39.push("cf-skip-left", "cf-skip-right");
      }
      v39.forEach(function (arg1) {
        var v40 = document.getElementById(arg1);
        if (!v40) {
          return;
        }
        if (v2.indexOf(v40) >= 0) {
          return;
        }
        var v41 = v40.getBoundingClientRect();
        if (v41.width > 0 && v41.height > 0) {
          v2.push(v40);
        }
      });
      document.querySelectorAll(".skip-pill.show").forEach(function (arg1) {
        if (v2.indexOf(arg1) >= 0) {
          return;
        }
        var v40 = arg1.getBoundingClientRect();
        if (v40.width > 0 && v40.height > 0) {
          v2.push(arg1);
        }
      });
    }
  }
  function v23(arg1, arg2) {
    v2.forEach(function (arg3) {
      arg3.classList.remove("tv-focused");
    });
    if (arg1 < 0) {
      arg1 = 0;
    }
    if (arg1 >= v2.length) {
      arg1 = v2.length - 1;
    }
    v3 = arg1;
    v6 = false;
    document.body.classList.remove("tv-slider-active");
    var v34 = v2[arg1];
    if (!v34) {
      return;
    }
    if (!arg2) {
      v7 = v34;
    }
    v34.classList.add("tv-focused");
    v34.scrollIntoView({
      block: "nearest",
      behavior: "smooth",
    });
  }
  function v24() {
    v22();
    if (v7) {
      var v34 = v2.indexOf(v7);
      if (v34 >= 0) {
        v23(v34, true);
        return;
      }
    }
    if (v2.length) {
      v23(0, true);
    }
  }
  function v25(arg1) {
    var v34 = arg1.getBoundingClientRect();
    return {
      x: v34.left + v34.width / 2,
      y: v34.top + v34.height / 2,
    };
  }
  function v26(arg1) {
    v22();
    if (!v2.length) {
      return;
    }
    if (v3 < 0) {
      v23(0);
      return;
    }
    var v34 = v2[v3];
    if (!v34) {
      v23(0);
      return;
    }
    var v35 = v25(v34);
    var v36 = -1;
    var v37 = Infinity;
    for (var v38 = 0; v38 < v2.length; v38++) {
      if (v38 === v3) {
        continue;
      }
      var v39 = v25(v2[v38]);
      var v40 = v39.x - v35.x;
      var v41 = v39.y - v35.y;
      var v42 = false;
      if (arg1 === "right" && v40 > 12) {
        v42 = true;
      }
      if (arg1 === "left" && v40 < -12) {
        v42 = true;
      }
      if (arg1 === "down" && v41 > 12) {
        v42 = true;
      }
      if (arg1 === "up" && v41 < -12) {
        v42 = true;
      }
      if (!v42) {
        continue;
      }
      var v43 =
        arg1 === "left" || arg1 === "right" ? Math.abs(v40) : Math.abs(v41);
      var v44 =
        arg1 === "left" || arg1 === "right" ? Math.abs(v41) : Math.abs(v40);
      var v45 = v43 + v44 * 3.5;
      if (v45 < v37) {
        v37 = v45;
        v36 = v38;
      }
    }
    if (v36 >= 0) {
      v23(v36);
    } else {
      if (arg1 === "down" && v3 < v2.length - 1) {
        v23(v3 + 1);
      }
      if (arg1 === "up" && v3 > 0) {
        v23(v3 - 1);
      }
    }
  }
  function v27() {
    var v34 = v15();
    if (!v34) {
      return;
    }
    if (v16(v34)) {
      v6 = !v6;
      document.body.classList.toggle("tv-slider-active", v6);
      haptic(10);
      return;
    }
    if (v17(v34)) {
      v34.click();
      haptic(10);
      return;
    }
    var v35 =
      v34.classList.contains("settings-back-btn") ||
      v34.classList.contains("svsh-back");
    if (v35) {
      v21();
      return;
    }
    if (
      v34.classList.contains("settings-tile") ||
      v34.classList.contains("settings-main-item")
    ) {
      v8 = v34;
      v9 = Date.now() + 300;
    }
    v34.click();
    haptic(10);
  }
  var v28 = false;
  var v29 = null;
  var v30 = {};
  function v31(arg1) {
    if (v28) {
      return;
    }
    v28 = true;
    var v34 = document.getElementById("v");
    v29 = setInterval(function () {
      v34.currentTime = Math.max(
        0,
        Math.min(v34.duration || 0, v34.currentTime + arg1 * 5),
      );
      showUI();
    }, 300);
  }
  function v32() {
    v28 = false;
    clearInterval(v29);
    v29 = null;
  }
  var v33 = document.createElement("style");
  v33.textContent =
    '.tv-focused{outline:3px solid rgba(255,255,255,0.92)!important;outline-offset:3px!important;background:rgba(255,255,255,0.13)!important;border-radius:10px!important;}.tv-focused.ctrl-btn{background:rgba(255,255,255,0.2)!important;}.tv-focused.settings-tile{background:rgba(255,255,255,0.16)!important;}.tv-focused.cf-skip-btn{opacity:1!important;pointer-events:auto!important;}.tv-focused.settings-toggle{outline:3px solid rgba(255,255,255,0.92)!important;outline-offset:3px!important;border-radius:100px!important;background:transparent!important;}input[type="range"].tv-focused{outline:3px solid rgba(255,255,255,0.92)!important;outline-offset:4px!important;border-radius:6px!important;background:rgba(255,255,255,0.07)!important;}body.tv-slider-active input[type="range"].tv-focused{outline:3px solid #55aaff!important;outline-offset:4px!important;box-shadow:0 0 0 6px rgba(85,170,255,0.18)!important;}#center-flash.paused .cf-skip-btn{pointer-events:auto;}body.tv-nav-mode #center-flash.paused{pointer-events:auto;}body.tv-nav-mode *{cursor:none!important;}';
  document.head.appendChild(v33);
  document.addEventListener(
    "keydown",
    function (arg1) {
      var v34 = document.getElementById("v");
      if (!v34) {
        return;
      }
      var v35 = arg1.keyCode;
      if (v35 === v1.PLAY_PAUSE || v35 === v1.PLAY || v35 === v1.PAUSE) {
        arg1.preventDefault();
        if (v34.paused) {
          v34.play();
        } else {
          v34.pause();
        }
        showUI();
        return;
      }
      if (v35 === v1.STOP) {
        arg1.preventDefault();
        v34.pause();
        v34.currentTime = 0;
        showUI(true);
        return;
      }
      if (v35 === v1.FAST_FWD) {
        arg1.preventDefault();
        if (!v30[v35]) {
          v31(1);
        }
        v30[v35] = true;
        return;
      }
      if (v35 === v1.REWIND) {
        arg1.preventDefault();
        if (!v30[v35]) {
          v31(-1);
        }
        v30[v35] = true;
        return;
      }
      if (v35 === v1.INFO) {
        arg1.preventDefault();
        showUI(true);
        return;
      }
      var v36 = v13();
      if (v35 === v1.BACK || v35 === 27) {
        arg1.preventDefault();
        if (v6) {
          v6 = false;
          document.body.classList.remove("tv-slider-active");
          haptic(6);
          return;
        }
        v21();
        return;
      }
      if (v35 === v1.ENTER) {
        arg1.preventDefault();
        if (!v4) {
          v11();
          showUI(true);
          return;
        }
        var v37 = v3;
        var v38 = v2[v37];
        var v39 =
          v38 &&
          (v38.classList.contains("settings-back-btn") ||
            v38.classList.contains("svsh-back"));
        var v40 = v16(v38);
        var v41 = v17(v38);
        var v42 =
          v38 &&
          (v38.classList.contains("settings-tile") ||
            v38.classList.contains("settings-main-item"));
        v27();
        if (!v39 && !v40 && !v41 && !v42) {
          setTimeout(function () {
            if (Date.now() < v9) {
              return;
            }
            v22();
            if (!v2.length) {
              setTimeout(function () {
                v24();
              }, 200);
              return;
            }
            var v44 = v38 ? v2.indexOf(v38) : -1;
            if (v44 >= 0) {
              v23(v44);
            } else {
              v23(Math.min(v37, v2.length - 1));
            }
          }, 160);
        }
        return;
      }
      if (
        v35 === v1.UP ||
        v35 === v1.DOWN ||
        v35 === v1.LEFT ||
        v35 === v1.RIGHT
      ) {
        arg1.preventDefault();
        arg1.stopImmediatePropagation();
        if (Date.now() < v5) {
          return;
        }
        var v43 = v15();
        if (v6 && v16(v43)) {
          if (v35 === v1.LEFT || v35 === v1.DOWN) {
            v18(v43, -1);
          }
          if (v35 === v1.RIGHT || v35 === v1.UP) {
            v18(v43, 1);
          }
          return;
        }
        v11();
        showUI(true);
        if (v35 === v1.LEFT || v35 === v1.RIGHT) {
          if (v43 && v16(v43)) {
            v18(v43, v35 === v1.RIGHT ? 1 : -1);
            return;
          }
          if (!v36 && !epOpen && v3 < 0) {
            doSkip(v35 === v1.RIGHT ? "right" : "left", 1);
            v5 = Date.now() + 800;
            return;
          }
          v26(v35 === v1.LEFT ? "left" : "right");
          return;
        }
        if (v3 < 0) {
          v22();
          v23(0);
        } else {
          v26(v35 === v1.UP ? "up" : "down");
        }
        return;
      }
    },
    true,
  );
  document.addEventListener("keyup", function (arg1) {
    if (arg1.keyCode === v1.FAST_FWD || arg1.keyCode === v1.REWIND) {
      v32();
      v30[arg1.keyCode] = false;
    }
  });
  document.addEventListener("mousemove", function () {
    if (v4) {
      v12();
      document.body.style.cursor = "";
    }
  });
  document.addEventListener(
    "touchstart",
    function () {
      if (v4) {
        v12();
      }
    },
    {
      passive: true,
    },
  );
  if (v10()) {
    setTimeout(v11, 500);
  }
  document.addEventListener("DOMContentLoaded", function () {
    var v34 = document.getElementById("player");
    if (v34) {
      v34.focus();
    }
  });
  window.addEventListener("load", function () {
    document.body.focus();
    var v34 = document.getElementById("player");
    if (v34) {
      v34.setAttribute("tabindex", "0");
      v34.focus();
    }
    (function () {
      var v35 = null;
      var v36 = {};
      var v37 = {
        0: v1.ENTER,
        1: 27,
        8: v1.PLAY_PAUSE,
        9: v1.INFO,
        12: v1.UP,
        13: v1.DOWN,
        14: v1.LEFT,
        15: v1.RIGHT,
        6: v1.REWIND,
        7: v1.FAST_FWD,
      };
      function v38(arg1, arg2) {
        document.dispatchEvent(
          new KeyboardEvent(arg2, {
            keyCode: arg1,
            which: arg1,
            code: arg1 === 13 ? "Enter" : String(arg1),
            key: arg1 === 13 ? "Enter" : String.fromCharCode(arg1),
            bubbles: true,
            cancelable: true,
          }),
        );
      }
      function v39() {
        var v40 = navigator.getGamepads ? navigator.getGamepads() : [];
        for (var v41 = 0; v41 < v40.length; v41++) {
          var v42 = v40[v41];
          if (!v42) {
            continue;
          }
          for (var v43 in v37) {
            var v44 = v42.buttons[v43] && v42.buttons[v43].pressed;
            var v45 = v36[v41 + "_" + v43];
            if (v44 && !v45) {
              v38(v37[v43], "keydown");
            }
            if (!v44 && v45) {
              v38(v37[v43], "keyup");
            }
            v36[v41 + "_" + v43] = v44;
          }
          var v46 = 0.5;
          var v47 = v42.axes[0] < -v46;
          var v48 = v42.axes[0] > v46;
          var v49 = v42.axes[1] < -v46;
          var v50 = v42.axes[1] > v46;
          var v51 = {
            axLeft: v47,
            axRight: v48,
            axUp: v49,
            axDown: v50,
          };
          var v52 = {
            axLeft: v1.LEFT,
            axRight: v1.RIGHT,
            axUp: v1.UP,
            axDown: v1.DOWN,
          };
          for (var v53 in v51) {
            var v54 = v51[v53];
            var v55 = v36[v41 + "_" + v53];
            if (v54 && !v55) {
              v38(v52[v53], "keydown");
            }
            if (!v54 && v55) {
              v38(v52[v53], "keyup");
            }
            v36[v41 + "_" + v53] = v54;
          }
        }
        v35 = requestAnimationFrame(v39);
      }
      window.addEventListener("gamepadconnected", function () {
        if (!v35) {
          v35 = requestAnimationFrame(v39);
        }
      });
      window.addEventListener("gamepaddisconnected", function () {
        if (v35) {
          cancelAnimationFrame(v35);
          v35 = null;
        }
      });
      if (
        navigator.getGamepads &&
        Array.from(navigator.getGamepads()).some(Boolean)
      ) {
        v35 = requestAnimationFrame(v39);
      }
    })();
  });
})();
