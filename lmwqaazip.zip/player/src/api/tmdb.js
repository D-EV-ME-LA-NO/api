window.setTitleWithTmdbImage = async function (arg1, arg2) {
  var v3 = document.getElementById("title-text");
  var v4 = null;
  if (
    arg2 &&
    arg2.images &&
    arg2.images.logos &&
    arg2.images.logos.length > 0
  ) {
    v4 = arg2.images.logos.find(function (arg3) {
      return arg3.iso_639_1 === "en";
    });
    if (!v4) {
      v4 = arg2.images.logos.find(function (arg3) {
        return !arg3.iso_639_1 || arg3.iso_639_1 === "xx";
      });
    }
    if (!v4) {
      v4 = arg2.images.logos[0];
    }
  }
  if (!v4 && arg2 && arg2.logo_object && arg2.logo_object.file_path) {
    v4 = arg2.logo_object;
  }
  if (!v4) {
    var v5 = arg2 && (arg2.tmdb_id || arg2.id);
    var v6 = store.s ? "tv" : "movie";
    if (v5) {
      try {
        var v7 = await fetch(
          "https://api.themoviedb.org/3/" +
            v6 +
            "/" +
            v5 +
            "/images?api_key=" +
            window.TMDB_KEY,
        );
        var v8 = await v7.json();
        var v9 = v8.logos || [];
        if (v9.length > 0) {
          v4 = v9.find(function (arg3) {
            return arg3.iso_639_1 === "en";
          });
          if (!v4) {
            v4 = v9.find(function (arg3) {
              return !arg3.iso_639_1 || arg3.iso_639_1 === "xx";
            });
          }
          if (!v4) {
            v4 = v9[0];
          }
        }
      } catch (v1) {}
    }
  }
  if (v4 && v4.file_path) {
    var v10 = "https://image.tmdb.org/t/p/w300" + v4.file_path;
    v3.innerHTML =
      '<img src="' +
      v10 +
      '" alt="' +
      arg1 +
      '" style="max-height:24px;max-width:200px;object-fit:contain;">';
  } else {
    v3.textContent = arg1;
  }
};
