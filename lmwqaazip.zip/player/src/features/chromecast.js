window.__onGCastApiAvailable = function (arg1) {
  if (arg1) {
    cast.framework.CastContext.getInstance().setOptions({
      receiverApplicationId: chrome.cast.media.DEFAULT_MEDIA_RECEIVER_APP_ID,
      autoJoinPolicy: chrome.cast.AutoJoinPolicy.ORIGIN_SCOPED,
    });
  }
};
const s = document.createElement("script");
s.src =
  "https://www.gstatic.com/cv/js/sender/v1/cast_sender.js?loadCastFramework=1";
document.head.appendChild(s);
document.getElementById("btn-cast")?.addEventListener("click", async () => {
  try {
    const v1 = cast.framework.CastContext.getInstance();
    let v2 = v1.getCurrentSession();
    if (!v2) {
      await v1.requestSession();
      v2 = v1.getCurrentSession();
    }
    if (!v2) {
      return;
    }
    const v3 = document.getElementById("v");
    const v4 = new chrome.cast.media.MediaInfo(v3.src, "video/mp4");
    const v5 = new chrome.cast.media.GenericMediaMetadata();
    v5.title = document.title;
    v4.metadata = v5;
    const v6 = new chrome.cast.media.LoadRequest(v4);
    v6.currentTime = v3.currentTime;
    await v2.loadMedia(v6);
    v3.pause();
  } catch (v1) {}
});
