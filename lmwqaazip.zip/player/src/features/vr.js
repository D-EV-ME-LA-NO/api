(function () {
  var v1 = document.getElementById("v");
  var v2 = document.getElementById("vr-canvas");
  var v3 = document.getElementById("vr-permission-btn");
  var v4 = document.getElementById("vr-permission-confirm");
  var v5 = document.getElementById("btn-toggle-vr");
  var v6 = document.getElementById("vr-split-row");
  var v7 = document.getElementById("vr-projection-row");
  var v8 = document.getElementById("vr-split-select");
  var v9 = document.getElementById("vr-projection-select");
  if (!v1 || !v2 || !v5) {
    return;
  }
  var v10 = null;
  var v11 = null;
  var v12 = null;
  var v13 = null;
  var v14 = null;
  var v15 = false;
  var v16 = "mono";
  var v17 = "single";
  var v18 = 0;
  var v19 = 0;
  var v20 = null;
  var v21 = false;
  var v22 =
    "attribute vec3 aPos;attribute vec2 aUv;uniform mat4 uMvp;varying vec2 vUv;void main() {  vUv = aUv;  gl_Position = uMvp * vec4(aPos, 1.0);}";
  var v23 =
    "precision mediump float;varying vec2 vUv;uniform sampler2D uTex;void main() {  gl_FragColor = texture2D(uTex, vUv);}";
  function v24(arg1, arg2) {
    var v46 = v10.createShader(arg2);
    v10.shaderSource(v46, arg1);
    v10.compileShader(v46);
    if (!v10.getShaderParameter(v46, v10.COMPILE_STATUS)) {
      console.error("VR shader error", v10.getShaderInfoLog(v46));
      v10.deleteShader(v46);
      return null;
    }
    return v46;
  }
  function v25() {
    v10 =
      v2.getContext("webgl", {
        antialias: true,
      }) || v2.getContext("experimental-webgl");
    if (!v10) {
      return false;
    }
    var v46 = v24(v22, v10.VERTEX_SHADER);
    var v47 = v24(v23, v10.FRAGMENT_SHADER);
    if (!v46 || !v47) {
      return false;
    }
    v11 = v10.createProgram();
    v10.attachShader(v11, v46);
    v10.attachShader(v11, v47);
    v10.linkProgram(v11);
    if (!v10.getProgramParameter(v11, v10.LINK_STATUS)) {
      console.error("VR program link error", v10.getProgramInfoLog(v11));
      return false;
    }
    v13 = v26(32, 32);
    v12 = v10.createTexture();
    v10.bindTexture(v10.TEXTURE_2D, v12);
    v10.texParameteri(v10.TEXTURE_2D, v10.TEXTURE_WRAP_S, v10.CLAMP_TO_EDGE);
    v10.texParameteri(v10.TEXTURE_2D, v10.TEXTURE_WRAP_T, v10.CLAMP_TO_EDGE);
    v10.texParameteri(v10.TEXTURE_2D, v10.TEXTURE_MIN_FILTER, v10.LINEAR);
    v10.texParameteri(v10.TEXTURE_2D, v10.TEXTURE_MAG_FILTER, v10.LINEAR);
    return true;
  }
  function v26(arg1, arg2) {
    var v46 = [];
    var v47 = [];
    var v48 = [];
    var v49 = 10;
    for (var v50 = 0; v50 <= arg1; v50++) {
      var v51 = (v50 * Math.PI) / arg1;
      var v52 = Math.sin(v51);
      var v53 = Math.cos(v51);
      for (var v54 = 0; v54 <= arg2; v54++) {
        var v55 = (v54 * 2 * Math.PI) / arg2;
        var v56 = Math.sin(v55);
        var v57 = Math.cos(v55);
        var v58 = v57 * v52;
        var v59 = v53;
        var v60 = v56 * v52;
        var v61 = 1 - v54 / arg2;
        var v62 = v50 / arg1;
        v46.push(v49 * v58, v49 * v59, v49 * v60);
        v47.push(v61, v62);
      }
    }
    for (var v63 = 0; v63 < arg1; v63++) {
      for (var v64 = 0; v64 < arg2; v64++) {
        var v65 = v63 * (arg2 + 1) + v64;
        var v66 = v65 + arg2 + 1;
        v48.push(v65, v66, v65 + 1);
        v48.push(v66, v66 + 1, v65 + 1);
      }
    }
    var v67 = v10.createBuffer();
    v10.bindBuffer(v10.ARRAY_BUFFER, v67);
    v10.bufferData(v10.ARRAY_BUFFER, new Float32Array(v46), v10.STATIC_DRAW);
    var v68 = v10.createBuffer();
    v10.bindBuffer(v10.ARRAY_BUFFER, v68);
    v10.bufferData(v10.ARRAY_BUFFER, new Float32Array(v47), v10.STATIC_DRAW);
    var v69 = v10.createBuffer();
    v10.bindBuffer(v10.ELEMENT_ARRAY_BUFFER, v69);
    v10.bufferData(
      v10.ELEMENT_ARRAY_BUFFER,
      new Uint16Array(v48),
      v10.STATIC_DRAW,
    );
    return {
      pos: v67,
      uv: v68,
      idx: v69,
      count: v48.length,
    };
  }
  function v27(arg1, arg2, arg3, arg4) {
    var v46 = 1 / Math.tan(arg1 / 2);
    var v47 = 1 / (arg3 - arg4);
    return [
      v46 / arg2,
      0,
      0,
      0,
      0,
      v46,
      0,
      0,
      0,
      0,
      (arg4 + arg3) * v47,
      -1,
      0,
      0,
      arg4 * 2 * arg3 * v47,
      0,
    ];
  }
  function v28(arg1, arg2) {
    var v46 = new Array(16);
    for (var v47 = 0; v47 < 4; v47++) {
      for (var v48 = 0; v48 < 4; v48++) {
        var v49 = 0;
        for (var v50 = 0; v50 < 4; v50++) {
          v49 += arg1[v50 * 4 + v48] * arg2[v47 * 4 + v50];
        }
        v46[v47 * 4 + v48] = v49;
      }
    }
    return v46;
  }
  function v29(arg1) {
    var v46 = Math.cos(arg1);
    var v47 = Math.sin(arg1);
    return [v46, 0, -v47, 0, 0, 1, 0, 0, v47, 0, v46, 0, 0, 0, 0, 1];
  }
  function v30(arg1) {
    var v46 = Math.cos(arg1);
    var v47 = Math.sin(arg1);
    return [1, 0, 0, 0, 0, v46, v47, 0, 0, -v47, v46, 0, 0, 0, 0, 1];
  }
  function v31() {
    var v46 = v30(v19);
    var v47 = v29(v18);
    return v28(v47, v46);
  }
  function v32(arg1, arg2, arg3, arg4) {
    v10.viewport(arg1, arg2, arg3, arg4);
    v10.scissor(arg1, arg2, arg3, arg4);
    v10.enable(v10.SCISSOR_TEST);
    v10.clearColor(0, 0, 0, 1);
    v10.clear(v10.COLOR_BUFFER_BIT | v10.DEPTH_BUFFER_BIT);
    v10.useProgram(v11);
    var v46 = v27((Math.PI / 180) * 90, arg3 / arg4, 0.1, 100);
    var v47 = v31();
    var v48 = v28(v46, v47);
    var v49 = v10.getUniformLocation(v11, "uMvp");
    v10.uniformMatrix4fv(v49, false, new Float32Array(v48));
    var v50 = v10.getAttribLocation(v11, "aPos");
    v10.bindBuffer(v10.ARRAY_BUFFER, v13.pos);
    v10.enableVertexAttribArray(v50);
    v10.vertexAttribPointer(v50, 3, v10.FLOAT, false, 0, 0);
    var v51 = v10.getAttribLocation(v11, "aUv");
    v10.bindBuffer(v10.ARRAY_BUFFER, v13.uv);
    v10.enableVertexAttribArray(v51);
    v10.vertexAttribPointer(v51, 2, v10.FLOAT, false, 0, 0);
    v10.activeTexture(v10.TEXTURE0);
    v10.bindTexture(v10.TEXTURE_2D, v12);
    try {
      v10.texImage2D(
        v10.TEXTURE_2D,
        0,
        v10.RGBA,
        v10.RGBA,
        v10.UNSIGNED_BYTE,
        v1,
      );
    } catch (v52) {}
    v10.uniform1i(v10.getUniformLocation(v11, "uTex"), 0);
    v10.bindBuffer(v10.ELEMENT_ARRAY_BUFFER, v13.idx);
    v10.drawElements(v10.TRIANGLES, v13.count, v10.UNSIGNED_SHORT, 0);
    v10.disable(v10.SCISSOR_TEST);
  }
  function v33() {
    if (!v15) {
      return;
    }
    v34();
    if (v1.readyState >= v1.HAVE_CURRENT_DATA) {
      if (v17 === "split") {
        var v46 = v2.width / 2;
        v32(0, 0, v46, v2.height);
        v32(v46, 0, v46, v2.height);
      } else {
        v32(0, 0, v2.width, v2.height);
      }
    }
    v14 = requestAnimationFrame(v33);
  }
  function v34() {
    var v46 = Math.min(window.devicePixelRatio || 1, 2);
    var v47 = Math.floor(window.innerWidth * v46);
    var v48 = Math.floor(window.innerHeight * v46);
    if (v2.width !== v47 || v2.height !== v48) {
      v2.width = v47;
      v2.height = v48;
    }
  }
  function v35(arg1) {
    if (arg1.alpha === null) {
      return;
    }
    v21 = true;
    var v46 = (arg1.alpha || 0) * (Math.PI / 180);
    var v47 = (arg1.beta || 0) * (Math.PI / 180);
    v18 = -v46;
    v19 = Math.max(-Math.PI / 2, Math.min(Math.PI / 2, v47 - Math.PI / 2));
  }
  function v36(arg1) {
    if (v21 && v16 === "mono") {
      return;
    }
    v20 = {
      x: arg1.clientX,
      y: arg1.clientY,
    };
  }
  function v37(arg1) {
    if (!v20) {
      return;
    }
    var v46 = arg1.clientX - v20.x;
    var v47 = arg1.clientY - v20.y;
    v20 = {
      x: arg1.clientX,
      y: arg1.clientY,
    };
    v18 -= v46 * 0.005;
    v19 = Math.max(-Math.PI / 2, Math.min(Math.PI / 2, v19 - v47 * 0.005));
  }
  function v38() {
    v20 = null;
  }
  function v39(arg1) {
    if (arg1.touches.length !== 1) {
      return;
    }
    var v46 = arg1.touches[0];
    if (!v20) {
      v20 = {
        x: v46.clientX,
        y: v46.clientY,
      };
      return;
    }
    var v47 = v46.clientX - v20.x;
    var v48 = v46.clientY - v20.y;
    v20 = {
      x: v46.clientX,
      y: v46.clientY,
    };
    v18 -= v47 * 0.005;
    v19 = Math.max(-Math.PI / 2, Math.min(Math.PI / 2, v19 - v48 * 0.005));
  }
  function v40() {
    v20 = null;
  }
  function v41() {
    if (
      typeof DeviceOrientationEvent !== "undefined" &&
      typeof DeviceOrientationEvent.requestPermission === "function"
    ) {
      DeviceOrientationEvent.requestPermission()
        .then(function (arg1) {
          if (arg1 === "granted") {
            window.addEventListener("deviceorientation", v35);
          }
          v42();
        })
        .catch(function () {
          v42();
        });
    } else {
      window.addEventListener("deviceorientation", v35);
      v42();
    }
  }
  function v42() {
    if (v3) {
      v3.style.display = "none";
    }
    if (!v10 && !v25()) {
      console.error("VR: WebGL unavailable");
      return;
    }
    v15 = true;
    v18 = 0;
    v19 = 0;
    v2.style.display = "block";
    v2.addEventListener("mousedown", v36);
    window.addEventListener("mousemove", v37);
    window.addEventListener("mouseup", v38);
    v2.addEventListener("touchstart", function (arg1) {
      if (arg1.touches.length === 1) {
        v20 = {
          x: arg1.touches[0].clientX,
          y: arg1.touches[0].clientY,
        };
      }
    });
    v2.addEventListener("touchmove", v39, {
      passive: true,
    });
    v2.addEventListener("touchend", v40);
    window.addEventListener("resize", v34);
    v34();
    if (typeof v1.play === "function") {
      v1.play().catch(function () {});
    }
    v33();
  }
  function v43() {
    v15 = false;
    if (v14) {
      cancelAnimationFrame(v14);
    }
    v14 = null;
    v2.style.display = "none";
    if (v3) {
      v3.style.display = "none";
    }
    window.removeEventListener("deviceorientation", v35);
    v2.removeEventListener("mousedown", v36);
    window.removeEventListener("mousemove", v37);
    window.removeEventListener("mouseup", v38);
    window.removeEventListener("resize", v34);
    v21 = false;
    v20 = null;
  }
  function v44() {
    var v46 = v16 === "mono";
    if (
      v46 &&
      typeof DeviceOrientationEvent !== "undefined" &&
      typeof DeviceOrientationEvent.requestPermission === "function"
    ) {
      if (v3) {
        v3.style.display = "flex";
      }
    } else {
      if (v46) {
        window.addEventListener("deviceorientation", v35);
      }
      v42();
    }
  }
  function v45() {
    var v46 = v5.classList.contains("on");
    if (v6) {
      v6.style.display = v46 ? "flex" : "none";
    }
    if (v7) {
      v7.style.display = v46 ? "flex" : "none";
    }
  }
  v5.addEventListener("click", function () {
    var v46 = !v5.classList.contains("on");
    v5.classList.toggle("on", v46);
    v45();
    if (v46) {
      v44();
    } else {
      v43();
    }
  });
  if (v4) {
    v4.addEventListener("click", v41);
  }
  if (v8) {
    v8.addEventListener("change", function () {
      v17 = v8.value === "split" ? "split" : "single";
    });
  }
  if (v9) {
    v9.addEventListener("change", function () {
      v16 = v9.value === "stereo" ? "stereo" : "mono";
      if (v16 === "stereo" && v8) {
        v8.value = "split";
        v17 = "split";
      }
      if (v15) {
        v43();
        v5.classList.add("on");
        v44();
      }
    });
  }
  v45();
})();
