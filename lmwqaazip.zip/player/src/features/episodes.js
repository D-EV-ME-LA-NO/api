(function () {
  var v1 = window.store.s;
  var v2 = window.store.e;
  var v3 = window.store.id;
  if (!v1) {
    return;
  }
  var v4 = document.getElementById("ep-panel-backdrop");
  var v5 = document.getElementById("ep-panel");
  var v6 = document.getElementById("ep-panel-season-view");
  var v7 = document.getElementById("ep-panel-episode-view");
  var v8 = document.getElementById("ep-panel-show-title");
  var v9 = document.getElementById("ep-panel-season-title");
  var v10 = document.getElementById("ep-season-list");
  var v11 = document.getElementById("ep-panel-ep-list");
  var v12 = document.getElementById("ep-panel-close");
  var v13 = document.getElementById("ep-panel-ep-back");
  var v14 = document.getElementById("ep-panel-close-btn");
  var v15 = document.getElementById("btn-episodes");
  var v16 = 1;
  var v17 = {};
  var v18 = parseInt(v1);
  var v19 = parseInt(v2 || "1");
  function v20() {
    v4.style.display = "block";
    requestAnimationFrame(function () {
      v4.classList.add("open");
      v5.classList.add("open");
    });
    v22();
  }
  function v21() {
    v4.classList.remove("open");
    v5.classList.remove("open");
    setTimeout(function () {
      v4.style.display = "none";
    }, 300);
  }
  function v22() {
    v6.style.display = "flex";
    v6.style.flexDirection = "column";
    v7.style.display = "none";
    v24(v10, function (arg1) {
      v23(arg1);
    });
  }
  function v23(arg1) {
    v9.textContent = "Season " + arg1;
    v6.style.display = "none";
    v7.style.display = "flex";
    v7.style.flexDirection = "column";
    v25(arg1, v11, function (arg2) {
      v21();
      if (arg2 !== v19 || arg1 !== v18) {
        location.href =
          location.pathname +
          "?id=" +
          v3 +
          "&season=" +
          arg1 +
          "&episode=" +
          arg2 +
          "&ap=1";
      }
    });
  }
  function v24(arg1, arg2) {
    arg1.innerHTML = "";
    for (var v28 = 1; v28 <= v16; v28++) {
      (function (arg3) {
        var v29 = document.createElement("div");
        v29.className = "ep-season-row";
        v29.innerHTML =
          "Season " + arg3 + '<i class="fa-solid fa-chevron-right"></i>';
        v29.addEventListener("click", function () {
          window.haptic(6);
          arg2(arg3);
        });
        arg1.appendChild(v29);
      })(v28);
    }
  }
  function v25(arg1, arg2, arg3) {
    arg2.innerHTML =
      '<div style="padding:20px;text-align:center;"><svg width="28" height="28" viewBox="0 0 52 52" style="animation:_vyla_spin 0.9s linear infinite"><circle cx="26" cy="26" r="22" fill="none" stroke="rgba(255,255,255,0.4)" stroke-width="3.5" stroke-dasharray="100" stroke-dashoffset="70"/></svg></div>';
    v27(arg1, function (arg4) {
      arg2.innerHTML = "";
      arg4.forEach(function (arg5) {
        var v29 = arg1 === v18 && arg5.episode_number === v19;
        var v30 = document.createElement("div");
        v30.className = "ep-panel-ep-row" + (v29 ? " current" : "");
        var v31 = '<div class="ep-panel-ep-thumb">';
        if (arg5.still_path) {
          v31 +=
            '<img src="https://image.tmdb.org/t/p/w185' +
            arg5.still_path +
            '" alt="">';
        } else {
          v31 +=
            '<div class="ep-panel-ep-thumb-placeholder"><i class="fa-solid fa-film"></i></div>';
        }
        v31 +=
          '<span class="ep-panel-ep-badge">E' +
          arg5.episode_number +
          "</span></div>";
        v30.innerHTML =
          v31 +
          '<div class="ep-panel-ep-info"><div class="ep-panel-ep-name">' +
          (arg5.name || "Episode " + arg5.episode_number) +
          '</div><div class="ep-panel-ep-meta">' +
          (arg5.runtime ? arg5.runtime + " min" : "") +
          "</div></div>";
        if (!v29) {
          v30.addEventListener("click", function () {
            window.haptic(10);
            arg3(arg5.episode_number);
          });
        }
        arg2.appendChild(v30);
      });
      var v28 = arg2.querySelector(".current");
      if (v28) {
        setTimeout(function () {
          v28.scrollIntoView({
            block: "center",
            behavior: "smooth",
          });
        }, 80);
      }
    });
  }
  function v26(arg1) {
    var v28 = [];
    var v29 = v17["_count_" + arg1] || 20;
    for (var v30 = 1; v30 <= v29; v30++) {
      v28.push({
        episode_number: v30,
        name: "Episode " + v30,
        runtime: null,
        still_path: null,
      });
    }
    return v28;
  }
  function v27(arg1, arg2) {
    if (v17[arg1] && v17[arg1]._real) {
      arg2(v17[arg1]);
      return;
    }
    fetch(
      "https://api.themoviedb.org/3/tv/" +
        v3 +
        "/season/" +
        arg1 +
        "?api_key=" +
        window.TMDB_KEY +
        "&language=en-US&append_to_response=images",
    )
      .then(function (arg3) {
        if (!arg3.ok) {
          throw new Error("HTTP " + arg3.status);
        }
        return arg3.json();
      })
      .then(function (arg3) {
        if (!arg3.episodes || !arg3.episodes.length) {
          throw new Error("no episodes");
        }
        arg3.episodes._real = true;
        v17[arg1] = arg3.episodes;
        v17[arg1]._real = true;
        arg2(v17[arg1]);
      })
      .catch(function () {
        v17[arg1] = null;
        arg2(v26(arg1));
      });
  }
  fetch("https://api.themoviedb.org/3/tv/" + v3 + "?api_key=" + window.TMDB_KEY)
    .then(function (arg1) {
      return arg1.json();
    })
    .then(function (arg1) {
      v16 = arg1.number_of_seasons || parseInt(v1);
      if (v8) {
        v8.textContent = arg1.name || "";
      }
      if (v15) {
        v15.style.display = "";
      }
    })
    .catch(function () {
      if (v15) {
        v15.style.display = "";
      }
    });
  if (v15) {
    v15.addEventListener("click", function (arg1) {
      arg1.stopPropagation();
      v20();
      window.haptic(10);
    });
  }
  if (v12) {
    v12.addEventListener("click", function () {
      v21();
      window.haptic(6);
    });
  }
  if (v14) {
    v14.addEventListener("click", function () {
      v21();
      window.haptic(6);
    });
  }
  if (v4) {
    v4.addEventListener("click", function () {
      v21();
    });
  }
  if (v13) {
    v13.addEventListener("click", function () {
      v22();
      window.haptic(6);
    });
  }
})();
