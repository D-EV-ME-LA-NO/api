import { TMDB_KEY } from "../config.js";
import { store } from "../state.js";
export let alive = true;
export let shouldHideLoader = false;
export function setShouldHideLoader(arg1) {
  shouldHideLoader = arg1;
}
export function initLoaderBackdrop() {
  var v1 = document.getElementById("loader-bg");
  if (!v1) {
    return;
  }
  if (!store.id) {
    return;
  }
  var v2 = !!store.s;
  var v3 = v2
    ? "https://api.themoviedb.org/3/tv/" + store.id + "?api_key=" + TMDB_KEY
    : "https://api.themoviedb.org/3/movie/" + store.id + "?api_key=" + TMDB_KEY;
  fetch(v3)
    .then(function (arg1) {
      if (!arg1.ok) {
        throw new Error("TMDB fetch failed");
      }
      return arg1.json();
    })
    .then(function (arg1) {
      if (arg1.success === false) {
        return;
      }
      var v4 = arg1.backdrop_path;
      if (v4) {
        var v5 = "https://image.tmdb.org/t/p/original" + v4;
        v1.style.backgroundImage = "url(" + v5 + ")";
      } else {
        var v6 = arg1.poster_path;
        if (v6) {
          var v7 = "https://image.tmdb.org/t/p/w1280" + v6;
          v1.style.backgroundImage = "url(" + v7 + ")";
        }
      }
    });
}
export function hideLoader() {
  var v1 = document.getElementById("loader");
  v1.classList.add("out");
  setTimeout(function () {
    alive = false;
    v1.style.display = "none";
  }, 1000);
}
