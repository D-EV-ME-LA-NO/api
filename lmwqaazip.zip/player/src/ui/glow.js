var ambientCanvas = null;
var ambientCtx = null;
var ambientRenderId = null;
var ambientLastTime = 0;
var ambientEnabled = true;
export function initAmbientGlow() {
  ambientCanvas = document.getElementById("ambient-glow-canvas");
  if (!ambientCanvas) {
    return;
  }
  ambientCtx = ambientCanvas.getContext("2d", {
    willReadFrequently: false,
  });
  ambientCanvas.width = 64;
  ambientCanvas.height = 36;
}
export function renderAmbientFrame(arg1) {
  if (!ambientEnabled || !ambientCtx) {
    ambientRenderId = requestAnimationFrame(renderAmbientFrame);
    return;
  }
  var v2 = document.getElementById("v") || v;
  if (!v2 || v2.readyState < 2 || v2.paused) {
    ambientRenderId = requestAnimationFrame(renderAmbientFrame);
    return;
  }
  if (!arg1 || arg1 - ambientLastTime > 66) {
    ambientLastTime = arg1 || 0;
    try {
      ambientCtx.drawImage(v2, 0, 0, ambientCanvas.width, ambientCanvas.height);
      ambientCanvas.classList.add("active");
    } catch (v1) {}
  }
  ambientRenderId = requestAnimationFrame(renderAmbientFrame);
}
export function startAmbientGlow() {
  if (!ambientCanvas) {
    initAmbientGlow();
  }
  if (ambientRenderId) {
    cancelAnimationFrame(ambientRenderId);
  }
  ambientRenderId = requestAnimationFrame(renderAmbientFrame);
}
export function stopAmbientGlow() {
  if (ambientRenderId) {
    cancelAnimationFrame(ambientRenderId);
  }
  ambientRenderId = null;
  if (ambientCanvas) {
    ambientCanvas.classList.remove("active");
  }
}
export function toggleAmbientGlow(arg1) {
  ambientEnabled = arg1;
  if (window.videoState) {
    window.videoState.ambientGlow = arg1;
  }
  if (arg1) {
    startAmbientGlow();
  } else {
    stopAmbientGlow();
  }
}
window.toggleAmbientGlow = toggleAmbientGlow;
