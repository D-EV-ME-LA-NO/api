window.showNowPlayingToast = function (arg1) {
  var v2 = document.getElementById("now-playing-toast");
  v2.innerHTML =
    '<div class="np-glow"></div><div class="np-inner"><span class="np-label">Now Playing</span><span class="np-title">“' +
    arg1 +
    "”</span></div>";
  v2.className = "";
  setTimeout(function () {
    v2.classList.add("enter");
    setTimeout(function () {
      v2.classList.add("exit");
    }, 3800);
  }, 4500);
};
