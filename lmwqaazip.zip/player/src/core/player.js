import { initAmbientGlow, startAmbientGlow } from "../ui/glow.js";
window.play = (arg1, arg2) => {
  const v3 = () => {
    const v1 = () =>
      document.getElementById("v") &&
      document.getElementById("player-controls-wrapper") &&
      document.getElementById("center-flash") &&
      document.getElementById("subtitle-display") &&
      document.getElementById("subtitle-text");
    if (v1()) {
      _vylaPlayReady(arg1, arg2);
      return;
    }
    const v2 = Date.now() + 20000;
    const v4 = setInterval(() => {
      if (v1()) {
        clearInterval(v4);
        _vylaPlayReady(arg1, arg2);
      } else if (Date.now() > v2) {
        clearInterval(v4);
        console.error("window.play: required player DOM never appeared");
      }
    }, 100);
  };
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", v3, {
      once: true,
    });
  } else {
    v3();
  }
};
function _vylaPlayReady(arg1, arg2) {
  (function () {
    if (document.getElementById("_vyla_styles")) {
      return;
    }
    var v1 = document.createElement("style");
    v1.id = "_vyla_styles";
    v1.textContent =
      "@keyframes _vyla_spin{to{transform:rotate(360deg)}}@keyframes _vyla_dot{0%,80%,100%{transform:scale(0.55);opacity:0.25}40%{transform:scale(1);opacity:1}}";
    document.head.appendChild(v1);
  })();
  var v3 = arg1;
  var v4 = document.getElementById("v");
  if (!window._ambientGlowStarted) {
    window._ambientGlowStarted = true;
    initAmbientGlow();
    startAmbientGlow();
  }
  window._activeMediaUrl = v3;
  (function () {
    if (v4._vylaHooked) {
      return;
    }
    v4._vylaHooked = true;
    var v1 = Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype, "src");
    Object.defineProperty(v4, "src", {
      get: function () {
        return v1.get.call(v4);
      },
      set: function (arg3) {
        v1.set.call(v4, arg3);
      },
      configurable: true,
    });
    var v2 = v4.load.bind(v4);
    v4.load = function () {
      return v2();
    };
    var v233 = v4.play.bind(v4);
    v4.play = function () {
      return v233();
    };
  })();
  var v5 = document.getElementById("player-controls-wrapper");
  var v6 = document.getElementById("title-bar");
  var v7 = document.getElementById("track");
  var v8 = document.getElementById("track-wrap");
  var v9 = document.getElementById("prog");
  var v10 = document.getElementById("buf");
  var v11 = document.getElementById("thumb");
  var v12 = document.getElementById("t-cur");
  var v13 = document.getElementById("t-dur");
  var v14 = document.getElementById("td-cur");
  var v15 = document.getElementById("td-dur");
  var v16 = document.getElementById("ci");
  var v17 = document.getElementById("center-flash");
  var v18 = document.getElementById("cf-skip-left");
  var v19 = document.getElementById("cf-skip-right");
  v18.addEventListener("click", function (arg3) {
    arg3.stopPropagation();
    v4.currentTime = Math.max(0, v4.currentTime - 10);
    window.haptic();
  });
  v18.addEventListener(
    "touchend",
    function (arg3) {
      arg3.preventDefault();
      arg3.stopPropagation();
      v4.currentTime = Math.max(0, v4.currentTime - 10);
      window.haptic();
    },
    {
      passive: false,
    },
  );
  v19.addEventListener("click", function (arg3) {
    arg3.stopPropagation();
    v4.currentTime = Math.min(v4.duration || 0, v4.currentTime + 10);
    window.haptic();
  });
  v19.addEventListener(
    "touchend",
    function (arg3) {
      arg3.preventDefault();
      arg3.stopPropagation();
      v4.currentTime = Math.min(v4.duration || 0, v4.currentTime + 10);
      window.haptic();
    },
    {
      passive: false,
    },
  );
  var v20 = false;
  function v21(arg3, arg4) {
    if (arg3 && arg3.type === "click" && v20) {
      v20 = false;
      return;
    }
    if (arg3) {
      try {
        arg3.preventDefault();
      } catch (v1) {}
      try {
        arg3.stopPropagation();
      } catch (v1) {}
    }
    if (arg3 && arg3.type === "touchend") {
      v20 = true;
      setTimeout(function () {
        v20 = false;
      }, 350);
    }
    window.haptic();
    var v233 = arg4 || document.getElementById("v") || v4;
    try {
      v233.playbackRate = v72;
    } catch (v1) {}
    v230 = Date.now() + 800;
    clearTimeout(v228);
    v228 = null;
    v223 = false;
    v224 = false;
    if (v233.paused) {
      v233.play().catch(function () {});
    } else {
      v233.pause();
    }
  }
  v16.style.position = "relative";
  v16.style.zIndex = "20";
  v16.style.pointerEvents = "auto";
  v16.style.touchAction = "manipulation";
  v16.style.webkitTapHighlightColor = "transparent";
  v16.addEventListener("click", function (arg3) {
    v21(arg3, v4);
  });
  v16.addEventListener(
    "touchend",
    function (arg3) {
      v21(arg3, v4);
    },
    {
      passive: false,
    },
  );
  v17.addEventListener("click", function (arg3) {
    if (
      arg3.target &&
      arg3.target.closest &&
      arg3.target.closest(".cf-skip-btn")
    ) {
      return;
    }
    v21(arg3, v4);
  });
  v17.addEventListener(
    "touchend",
    function (arg3) {
      if (
        arg3.target &&
        arg3.target.closest &&
        arg3.target.closest(".cf-skip-btn")
      ) {
        return;
      }
      v21(arg3, v4);
    },
    {
      passive: false,
    },
  );
  var v22 = document.getElementById("btn-play");
  if (v22) {
    v22.style.position = "relative";
    v22.style.zIndex = "20";
    v22.style.pointerEvents = "auto";
    v22.addEventListener("click", function (arg3) {
      v21(arg3, v4);
    });
    v22.addEventListener(
      "touchend",
      function (arg3) {
        v21(arg3, v4);
      },
      {
        passive: false,
      },
    );
  }
  var v23 = document.getElementById("skip-left");
  var v24 = document.getElementById("skip-right");
  var v25 = document.getElementById("skip-left-lbl");
  var v26 = document.getElementById("skip-right-lbl");
  var v27 = document.getElementById("btn-pip");
  var v28 = document.getElementById("btn-fullscreen");
  var v29 = document.getElementById("btn-settings");
  var v30 = document.getElementById("settings-panel");
  var v31 = document.querySelectorAll(".settings-list-item[data-speed]");
  var v32 = document.getElementById("quality-opts");
  var v33 = document.getElementById("source-title-wrap");
  var v34 = document.getElementById("sub-font-select");
  var v35 = document.getElementById("sub-size-select");
  var v36 = document.getElementById("sub-color-input");
  var v37 = document.getElementById("sub-bg-color-input");
  var v38 = document.getElementById("sub-bg-opacity-select");
  var v39 = document.getElementById("sub-pos-select");
  var v40 = document.getElementById("sub-edge-select");
  var v41 = document.getElementById("subtitle-display");
  var v42 = document.getElementById("subtitle-text");
  var v43 = document.getElementById("tooltip");
  var v44 = document.getElementById("volume-slider");
  var v45 = document.getElementById("volume-icon");
  var v46 = {
    off: '<svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 640 512"><path fill="currentColor" d="M301.1 34.8C312.6 40 320 51.4 320 64V448c0 12.6-7.4 24-18.9 29.2s-25 3.1-34.4-5.3L131.8 352H64c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64h67.8L266.7 40.1c9.4-8.4 22.9-10.4 34.4-5.3zM425 167l55 55 55-55c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9l-55 55 55 55c9.4 9.4 9.4 24.6 0 33.9s-24.6 9.4-33.9 0l-55-55-55 55c-9.4 9.4-24.6 9.4-33.9 0s-9.4-24.6 0-33.9l55-55-55-55c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0z"/></svg>',
    low: '<svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 640 512"><path fill="currentColor" d="M301.1 34.8C312.6 40 320 51.4 320 64V448c0 12.6-7.4 24-18.9 29.2s-25 3.1-34.4-5.3L131.8 352H64c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64h67.8L266.7 40.1c9.4-8.4 22.9-10.4 34.4-5.3zm105.5 145.2C434.1 199.1 448 225.9 448 256s-13.9 56.9-35.4 74.5c-10.3 8.4-25.4 6.8-33.8-3.5s-6.8-25.4 3.5-33.8C393.1 284.4 400 271 400 256s-6.9-28.4-17.7-37.3c-10.3-8.4-11.8-23.5-3.5-33.8s23.5-11.8 33.8-3.5z"/></svg>',
    mid: '<svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 640 512"><path fill="currentColor" d="M473.1 107c43.2 35.2 70.9 88.9 70.9 149s-27.7 113.8-70.9 149c-10.3 8.4-25.4 6.8-33.8-3.5s-6.8-25.4 3.5-33.8C475.3 341.3 496 301.1 496 256s-20.7-85.3-53.2-111.8c-10.3-8.4-11.8-23.5-3.5-33.8s23.5-11.8 33.8-3.5zm-60.5 74.5C434.1 199.1 448 225.9 448 256s-13.9 56.9-35.4 74.5c-10.3 8.4-25.4 6.8-33.8-3.5s-6.8-25.4 3.5-33.8C393.1 284.4 400 271 400 256s-6.9-28.4-17.7-37.3c-10.3-8.4-11.8-23.5-3.5-33.8s23.5-11.8 33.8-3.5zM301.1 34.8C312.6 40 320 51.4 320 64V448c0 12.6-7.4 24-18.9 29.2s-25 3.1-34.4-5.3L131.8 352H64c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64h67.8L266.7 40.1c9.4-8.4 22.9-10.4 34.4-5.3z"/></svg>',
    high: '<svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 640 512"><path fill="currentColor" d="M533.6 32.5C598.5 85.3 640 165.8 640 256s-41.5 170.8-106.4 223.5c-10.3 8.4-25.4 6.8-33.8-3.5s-6.8-25.4 3.5-33.8C557.5 398.2 592 331.2 592 256s-34.5-142.2-88.7-186.3c-10.3-8.4-11.8-23.5-3.5-33.8s23.5-11.8 33.8-3.5zM473.1 107c43.2 35.2 70.9 88.9 70.9 149s-27.7 113.8-70.9 149c-10.3 8.4-25.4 6.8-33.8-3.5s-6.8-25.4 3.5-33.8C475.3 341.3 496 301.1 496 256s-20.7-85.3-53.2-111.8c-10.3-8.4-11.8-23.5-3.5-33.8s23.5-11.8 33.8-3.5zm-60.5 74.5C434.1 199.1 448 225.9 448 256s-13.9 56.9-35.4 74.5c-10.3 8.4-25.4 6.8-33.8-3.5s-6.8-25.4 3.5-33.8C393.1 284.4 400 271 400 256s-6.9-28.4-17.7-37.3c-10.3-8.4-11.8-23.5-3.5-33.8s23.5-11.8 33.8-3.5zM301.1 34.8C312.6 40 320 51.4 320 64V448c0 12.6-7.4 24-18.9 29.2s-25 3.1-34.4-5.3L131.8 352H64c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64h67.8L266.7 40.1c9.4-8.4 22.9-10.4 34.4-5.3z"/></svg>',
  };
  function v47() {
    var v1 = v4.muted ? 0 : v4.volume;
    if (v44) {
      v44.value = Math.round(v1 * 100);
    }
    if (v45) {
      if (v1 === 0) {
        v45.innerHTML = v46.off;
      } else if (v1 < 0.25) {
        v45.innerHTML = v46.low;
      } else if (v1 < 0.6) {
        v45.innerHTML = v46.mid;
      } else {
        v45.innerHTML = v46.high;
      }
    }
  }
  v47();
  v47();
  var v48 = null;
  var v49 = false;
  var v50 = false;
  var v51 = false;
  var v52 = 0;
  var v53 = 0;
  var v54 = {
    sans: "var(--font)",
    serif: "Georgia, serif",
    mono: "monospace",
  };
  var v55 = {
    small: "14px",
    medium: "18px",
    large: "23px",
    xlarge: "28px",
    xxlarge: "34px",
  };
  var v56 = {
    shadow: "0 2px 6px rgba(0,0,0,0.85), 0 1px 3px rgba(0,0,0,0.9)",
    outline:
      "-1px -1px 0 rgba(0,0,0,0.9), 1px -1px 0 rgba(0,0,0,0.9), -1px 1px 0 rgba(0,0,0,0.9), 1px 1px 0 rgba(0,0,0,0.9)",
    uniform: "0 0 4px rgba(0,0,0,1), 0 0 4px rgba(0,0,0,1)",
    none: "none",
  };
  var v57 = {
    top: "80%",
    high: "28%",
    mid: "10%",
    low: "4%",
    bottom: "1%",
  };
  function v58(arg3, arg4) {
    var v233 = parseInt(arg3.slice(1, 3), 16);
    var v234 = parseInt(arg3.slice(3, 5), 16);
    var v235 = parseInt(arg3.slice(5, 7), 16);
    return "rgba(" + v233 + ", " + v234 + ", " + v235 + ", " + arg4 + ")";
  }
  var v59 = (function () {
    try {
      return JSON.parse(localStorage.getItem("subSettings") || "{}");
    } catch (v1) {
      return {};
    }
  })();
  var v60 = {
    activeTrack: -1,
    font: v59.font || "sans",
    color: v59.color || "#ffffff",
    size: v59.size || "medium",
    bgColor: v59.bgColor || "#000000",
    bgOpacity: v59.bgOpacity !== undefined ? v59.bgOpacity : "0.75",
    overallOpacity: v59.overallOpacity !== undefined ? v59.overallOpacity : "1",
    textShadow: v59.textShadow || "shadow",
    pos: v59.pos || "mid",
    edge: v59.edge || "shadow",
    weight: v59.weight || "500",
    spacing: v59.spacing || "normal",
    cues: [],
    cueTimer: null,
  };
  var v61 = {
    brightness: 100,
    contrast: 100,
    saturate: 100,
    ratio: "contain",
    ascii: false,
    asciiColor: true,
  };
  var v62 =
    " `.-':_,^=;><+!rc*/z?sLTv)J7(|Fi{C}fI31tlu[neoZ5Yxjya]2ESwqkP6h9d4VpOGbUAKXHm8RD#$Bg0MNWQ%&@";
  var v63 = null;
  var v64 = null;
  var v65 = null;
  var v66 = null;
  var v67 = null;
  var v68 = null;
  var v69 = null;
  var v57 = {
    top: "82%",
    high: "35%",
    mid: "12%",
    low: "6%",
    bottom: "2%",
  };
  var v70 = {
    light: "300",
    normal: "500",
    bold: "700",
  };
  var v71 = {
    tight: "-0.5px",
    normal: "0px",
    wide: "1px",
    extra: "2px",
  };
  var v72 = (function () {
    try {
      var v1 = parseFloat(localStorage.getItem("playbackSpeed"));
      if (!isNaN(v1) && v1 > 0 && v1 <= 2) {
        return v1;
      } else {
        return 1;
      }
    } catch (v2) {
      return 1;
    }
  })();
  var v73 = (function () {
    try {
      return localStorage.getItem("speedBoostEnabled") !== "false";
    } catch (v1) {
      return true;
    }
  })();
  function v74(arg3, arg4) {
    try {
      var v233 = JSON.parse(localStorage.getItem("videoTimestamps") || "{}");
      v233[arg3] = arg4;
      localStorage.setItem("videoTimestamps", JSON.stringify(v233));
    } catch (v1) {}
  }
  function v75(arg3) {
    try {
      var v233 = JSON.parse(localStorage.getItem("videoTimestamps") || "{}");
      return v233[arg3] || 0;
    } catch (v1) {
      return 0;
    }
  }
  function v76(arg3) {
    try {
      var v233 = JSON.parse(localStorage.getItem("videoTimestamps") || "{}");
      delete v233[arg3];
      localStorage.setItem("videoTimestamps", JSON.stringify(v233));
    } catch (v1) {}
  }
  function v77() {
    try {
      localStorage.setItem(
        "subSettings",
        JSON.stringify({
          font: v60.font,
          size: v60.size,
          color: v60.color,
          bgColor: v60.bgColor,
          bgOpacity: v60.bgOpacity,
          overallOpacity: v60.overallOpacity,
          textShadow: v60.textShadow,
          pos: v60.pos,
          edge: v60.edge,
          weight: v60.weight,
          spacing: v60.spacing,
        }),
      );
    } catch (v1) {}
  }
  function v78() {
    v41.style.bottom = v57[v60.pos];
    v41.style.opacity = v60.overallOpacity;
    v42.style.fontFamily = v54[v60.font];
    v42.style.fontSize = v55[v60.size];
    v42.style.color = v60.color;
    var v1 = "";
    if (v60.textShadow === "shadow") {
      v1 = v56.shadow;
    } else if (v60.textShadow === "outline") {
      v1 = v56.outline;
    } else if (v60.textShadow === "both") {
      v1 = v56.shadow + ", " + v56.outline;
    } else {
      v1 = v56.none;
    }
    v42.style.textShadow = v1;
    v42.style.fontWeight = v70[v60.weight] || "500";
    v42.style.letterSpacing = v71[v60.spacing] || "0px";
    var v2 = parseFloat(v60.bgOpacity);
    if (v2 > 0) {
      v42.style.background = v58(v60.bgColor, v2);
      v42.style.padding = "4px 10px";
    } else {
      v42.style.background = "transparent";
      v42.style.padding = "0";
    }
  }
  function v79() {
    v4.style.filter =
      "brightness(" +
      v61.brightness +
      "%) contrast(" +
      v61.contrast +
      "%) saturate(" +
      v61.saturate +
      "%)";
    v4.style.objectFit = v61.ratio;
  }
  function v80() {
    if (v64 && v66 && v68) {
      return;
    }
    var v1 = document.getElementById("player");
    v64 = document.createElement("canvas");
    v64.id = "ascii-output-canvas";
    v64.style.position = "fixed";
    v64.style.top = "0";
    v64.style.left = "0";
    v64.style.width = "100vw";
    v64.style.height = "100vh";
    v64.style.display = "none";
    v64.style.pointerEvents = "none";
    v64.style.zIndex = "17";
    v64.style.background = "black";
    document.body.appendChild(v64);
    v65 = v64.getContext("2d");
    v66 = document.createElement("canvas");
    v66.style.position = "absolute";
    v66.style.left = "-9999px";
    v66.style.width = "1px";
    v66.style.height = "1px";
    v66.style.visibility = "hidden";
    document.body.appendChild(v66);
    v67 = v66.getContext("2d");
    v68 = document.createElement("canvas");
    v69 = v68.getContext("2d");
  }
  function v81() {
    var v1 = document.getElementById("btn-toggle-ascii");
    var v2 = document.getElementById("btn-toggle-ascii-color");
    if (v1) {
      v1.classList.toggle("on", v61.ascii);
    }
    if (v2) {
      v2.classList.toggle("on", v61.asciiColor);
    }
  }
  function v82(arg3) {
    if (!v64) {
      return;
    }
    v64.style.display = arg3 ? "block" : "none";
  }
  function v83(arg3) {
    v61.ascii = arg3;
    v192();
    v81();
    v80();
    v82(arg3);
    var v233 = document.getElementById("player-controls-wrapper");
    var v234 = document.getElementById("title-bar");
    if (arg3) {
      if (v233) {
        v233.style.zIndex = "20";
        v233.style.position = "fixed";
        v233.style.bottom = "0";
        v233.style.left = "0";
        v233.style.width = "100vw";
      }
      if (v234) {
        v234.style.zIndex = "20";
        v234.style.position = "fixed";
        v234.style.top = "0";
        v234.style.left = "0";
        v234.style.width = "100vw";
      }
    } else {
      if (v233) {
        v233.style.zIndex = "";
        v233.style.position = "";
        v233.style.bottom = "";
        v233.style.left = "";
        v233.style.width = "";
      }
      if (v234) {
        v234.style.zIndex = "";
        v234.style.position = "";
        v234.style.top = "";
        v234.style.left = "";
        v234.style.width = "";
      }
    }
    var v235 = document.getElementById("v") || v4;
    if (arg3) {
      if (v235) {
        v235.style.opacity = "0";
        v235.style.pointerEvents = "none";
      }
      v103();
    } else {
      if (v235) {
        v235.style.opacity = "1";
        v235.style.pointerEvents = "";
        v235.style.visibility = "";
      }
      v104();
    }
  }
  function v84(arg3) {
    v61.asciiColor = arg3;
    v81();
    if (v61.ascii) {
      v106();
    }
  }
  v61.vr = false;
  v61.vrSplit = "single";
  var v85 = null;
  var v86 = null;
  var v87 = null;
  var v88 = null;
  var v89 = null;
  var v90 = 0;
  var v91 = 0;
  var v92 = null;
  var v93 = null;
  function v94() {
    if (v85) {
      return true;
    }
    v85 = document.createElement("canvas");
    v85.id = "vr-canvas";
    document.body.appendChild(v85);
    v86 = v85.getContext("webgl") || v85.getContext("experimental-webgl");
    if (!v86) {
      return false;
    }
    return v95();
  }
  function v95() {
    var v1 = v86;
    var v2 =
      "attribute vec2 aPos;varying vec2 vUv;void main(){vUv=aPos*0.5+0.5;gl_Position=vec4(aPos,0.0,1.0);}";
    var v233 =
      "precision mediump float;varying vec2 vUv;uniform sampler2D uTex;uniform float uYaw;uniform float uPitch;uniform float uEyeOffset;uniform float uCurve;void main(){vec2 p=(vUv-0.5)*2.0;p.x+=uEyeOffset;float r=length(p);vec2 warped=p*(1.0+uCurve*r*r);float lon=warped.x*1.2+uYaw;float lat=warped.y*1.0+uPitch;if(abs(lon)>1.0||abs(lat)>1.0){gl_FragColor=vec4(0.0,0.0,0.0,1.0);return;}vec2 uv=vec2(lon*0.5+0.5,1.0-(lat*0.5+0.5));gl_FragColor=texture2D(uTex,uv);}";
    function v234(arg3, arg4) {
      var v238 = v1.createShader(arg3);
      v1.shaderSource(v238, arg4);
      v1.compileShader(v238);
      return v238;
    }
    var v235 = v234(v1.VERTEX_SHADER, v2);
    var v236 = v234(v1.FRAGMENT_SHADER, v233);
    v87 = v1.createProgram();
    v1.attachShader(v87, v235);
    v1.attachShader(v87, v236);
    v1.linkProgram(v87);
    if (!v1.getProgramParameter(v87, v1.LINK_STATUS)) {
      return false;
    }
    var v237 = v1.createBuffer();
    v1.bindBuffer(v1.ARRAY_BUFFER, v237);
    v1.bufferData(
      v1.ARRAY_BUFFER,
      new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]),
      v1.STATIC_DRAW,
    );
    v88 = v1.createTexture();
    v1.bindTexture(v1.TEXTURE_2D, v88);
    v1.texParameteri(v1.TEXTURE_2D, v1.TEXTURE_WRAP_S, v1.CLAMP_TO_EDGE);
    v1.texParameteri(v1.TEXTURE_2D, v1.TEXTURE_WRAP_T, v1.CLAMP_TO_EDGE);
    v1.texParameteri(v1.TEXTURE_2D, v1.TEXTURE_MIN_FILTER, v1.LINEAR);
    v1.texParameteri(v1.TEXTURE_2D, v1.TEXTURE_MAG_FILTER, v1.LINEAR);
    v87._aPos = v1.getAttribLocation(v87, "aPos");
    v87._uTex = v1.getUniformLocation(v87, "uTex");
    v87._uYaw = v1.getUniformLocation(v87, "uYaw");
    v87._uPitch = v1.getUniformLocation(v87, "uPitch");
    v87._uEyeOffset = v1.getUniformLocation(v87, "uEyeOffset");
    v87._uCurve = v1.getUniformLocation(v87, "uCurve");
    v87._buf = v237;
    return true;
  }
  function v96() {
    if (!v85) {
      return;
    }
    v85.width = window.innerWidth * (window.devicePixelRatio || 1);
    v85.height = window.innerHeight * (window.devicePixelRatio || 1);
  }
  function v97() {
    if (!v61.vr || !v86 || !v87) {
      return;
    }
    var v1 = document.getElementById("v") || v4;
    if (!v1 || v1.readyState < 2) {
      v89 = requestAnimationFrame(v97);
      return;
    }
    var v2 = v86;
    v2.bindTexture(v2.TEXTURE_2D, v88);
    try {
      v2.texImage2D(v2.TEXTURE_2D, 0, v2.RGBA, v2.RGBA, v2.UNSIGNED_BYTE, v1);
    } catch (v234) {}
    v2.useProgram(v87);
    v2.bindBuffer(v2.ARRAY_BUFFER, v87._buf);
    v2.enableVertexAttribArray(v87._aPos);
    v2.vertexAttribPointer(v87._aPos, 2, v2.FLOAT, false, 0, 0);
    v2.uniform1i(v87._uTex, 0);
    v2.uniform1f(v87._uYaw, v90);
    v2.uniform1f(v87._uPitch, v91);
    v2.uniform1f(v87._uCurve, 0.35);
    if (v61.vrSplit === "split") {
      var v233 = Math.floor(v85.width / 2);
      v2.viewport(0, 0, v233, v85.height);
      v2.uniform1f(v87._uEyeOffset, -0.06);
      v2.drawArrays(v2.TRIANGLE_STRIP, 0, 4);
      v2.viewport(v233, 0, v85.width - v233, v85.height);
      v2.uniform1f(v87._uEyeOffset, 0.06);
      v2.drawArrays(v2.TRIANGLE_STRIP, 0, 4);
    } else {
      v2.viewport(0, 0, v85.width, v85.height);
      v2.uniform1f(v87._uEyeOffset, 0);
      v2.drawArrays(v2.TRIANGLE_STRIP, 0, 4);
    }
    v89 = requestAnimationFrame(v97);
  }
  function v98(arg3) {
    if (arg3.gamma === null || arg3.beta === null) {
      return;
    }
    var v233 = Math.max(-90, Math.min(90, arg3.gamma));
    var v234 = Math.max(-90, Math.min(90, arg3.beta - 90));
    v90 = (v233 / 90) * 1.4;
    v91 = (v234 / 90) * 1.1;
  }
  function v99() {
    v92 = v98;
    window.addEventListener("deviceorientation", v92, true);
  }
  function v100() {
    if (v92) {
      window.removeEventListener("deviceorientation", v92, true);
      v92 = null;
    }
    v90 = 0;
    v91 = 0;
  }
  function v101(arg3) {
    if (
      typeof DeviceOrientationEvent !== "undefined" &&
      typeof DeviceOrientationEvent.requestPermission === "function"
    ) {
      DeviceOrientationEvent.requestPermission()
        .then(function (arg4) {
          arg3(arg4 === "granted");
        })
        .catch(function () {
          arg3(false);
        });
    } else {
      arg3(true);
    }
  }
  function v102(arg3) {
    if (!window.isMobile || !window.isMobile()) {
      return;
    }
    v61.vr = arg3;
    var v233 = document.getElementById("btn-toggle-vr");
    if (v233) {
      v233.classList.toggle("on", arg3);
    }
    var v234 = document.getElementById("vr-split-row");
    if (v234) {
      v234.style.display = arg3 ? "flex" : "none";
    }
    var v235 = document.getElementById("v") || v4;
    if (arg3) {
      if (!v94()) {
        v61.vr = false;
        if (v233) {
          v233.classList.remove("on");
        }
        return;
      }
      v96();
      v85.style.display = "block";
      if (v235) {
        v235.style.opacity = "0";
        v235.style.pointerEvents = "none";
      }
      v101(function (arg4) {
        if (arg4) {
          v99();
        }
      });
      if (v89) {
        cancelAnimationFrame(v89);
      }
      v97();
    } else {
      if (v85) {
        v85.style.display = "none";
      }
      if (v235) {
        v235.style.opacity = "1";
        v235.style.pointerEvents = "";
      }
      if (v89) {
        cancelAnimationFrame(v89);
        v89 = null;
      }
      v100();
    }
  }
  window.addEventListener("resize", function () {
    if (v61.vr) {
      v96();
    }
  });
  function v103() {
    if (v63) {
      return;
    }
    v63 = requestAnimationFrame(v106);
  }
  function v104() {
    if (v63) {
      cancelAnimationFrame(v63);
      v63 = null;
    }
  }
  function v105() {
    if (!v65) {
      return;
    }
    var v1 = window.devicePixelRatio || 1;
    var v2 = window.innerWidth * v1;
    var v233 = window.innerHeight * v1;
    v64.width = v2;
    v64.height = v233;
    v64.style.width = "100vw";
    v64.style.height = "100vh";
    v65.setTransform(1, 0, 0, 1, 0, 0);
    v65.fillStyle = "#000";
    v65.fillRect(0, 0, v2, v233);
    v65.font = "18px sans-serif";
    v65.fillStyle = "#fff";
    v65.fillText("ASCII Render unavailable. CORS blocks frame read.", 20, 40);
    v65.fillText("Switch back to normal playback to continue.", 20, 72);
  }
  function v106() {
    v63 = null;
    if (!v61.ascii) {
      var v1 = document.getElementById("v") || v4;
      if (v1) {
        v1.style.visibility = "";
      }
      return;
    }
    var v2 = document.getElementById("v") || v4;
    if (!v2 || !v65 || !v67) {
      v63 = requestAnimationFrame(v106);
      return;
    }
    v2.style.visibility = "hidden";
    var v233 = v2.videoWidth || v2.clientWidth || window.innerWidth;
    var v234 = v2.videoHeight || v2.clientHeight || window.innerHeight;
    if (v233 === 0 || v234 === 0) {
      v63 = requestAnimationFrame(v106);
      return;
    }
    v66.width = v233;
    v66.height = v234;
    try {
      v67.drawImage(v2, 0, 0, v233, v234);
    } catch (v258) {
      v105();
      return;
    }
    var v235 = window.devicePixelRatio || 1;
    var v236 = window.innerWidth * v235;
    var v237 = window.innerHeight * v235;
    v64.width = v236;
    v64.height = v237;
    v64.style.width = "100vw";
    v64.style.height = "100vh";
    v65.setTransform(1, 0, 0, 1, 0, 0);
    v65.font = v235 * 7 + 'px "Courier New", Courier, monospace';
    var v238 = v65.measureText("M").width;
    var v239 = v65.measureText("M");
    var v240 = Math.ceil(v238);
    var v241 = Math.ceil(
      v239.fontBoundingBoxAscent + v239.fontBoundingBoxDescent || v240 * 2,
    );
    var v242 = Math.floor(v236 / v240);
    var v243 = Math.floor(v237 / v241);
    v68.width = v242;
    v68.height = v243;
    v69.drawImage(v66, 0, 0, v242, v243);
    var v244;
    try {
      v244 = v69.getImageData(0, 0, v242, v243).data;
    } catch (v258) {
      v105();
      return;
    }
    v65.fillStyle = "#000";
    v65.fillRect(0, 0, v236, v237);
    v65.textBaseline = "top";
    v65.textAlign = "left";
    if (!window._asciiDebugLogged) {
      window._asciiDebugLogged = true;
      var v239 = v65.measureText("M");
    }
    var v245 = Math.max(0, Math.floor((v236 - v242 * v240) / 2));
    var v246 = Math.max(0, Math.floor((v237 - v243 * v241) / 2));
    var v247 = v62.length - 1;
    for (var v248 = 0; v248 < v243; v248++) {
      for (var v249 = 0; v249 < v242; v249++) {
        var v250 = (v248 * v242 + v249) * 4;
        var v251 = v244[v250];
        var v252 = v244[v250 + 1];
        var v253 = v244[v250 + 2];
        var v254 = v251 * 0.299 + v252 * 0.587 + v253 * 0.114;
        var v255 = Math.min(v247, Math.max(0, Math.floor((v254 / 255) * v247)));
        var v256 = v62.charAt(v255);
        if (v256 === " ") {
          continue;
        }
        if (v61.asciiColor) {
          v65.fillStyle = "rgb(" + v251 + "," + v252 + "," + v253 + ")";
        } else {
          var v257 = Math.round(v254);
          v65.fillStyle = "rgb(" + v257 + "," + v257 + "," + v257 + ")";
        }
        v65.fillText(v256, v245 + v249 * v240, v246 + v248 * v241);
      }
    }
    v63 = requestAnimationFrame(v106);
  }
  if (v34) {
    v34.value = v60.font;
  }
  if (v35) {
    v35.value = v60.size;
  }
  if (v36) {
    v36.value = v60.color;
  }
  if (v37) {
    v37.value = v60.bgColor;
  }
  if (v38) {
    v38.value = v60.bgOpacity;
  }
  if (v39) {
    v39.value = v60.pos;
  }
  if (v40) {
    v40.value = v60.edge;
  }
  v78();
  v81();
  function v107(arg3, arg4, arg5, arg6) {
    var v233 = document.getElementById(arg3);
    v233.querySelectorAll(".settings-list-item").forEach(function (arg7) {
      arg7.classList.remove("active");
      var v236 = arg7.querySelector("i");
      if (v236) {
        v236.className = "fa-regular fa-circle";
      }
    });
    arg4.classList.add("active");
    var v234 = arg4.querySelector("i");
    if (v234) {
      v234.className = "fa-regular fa-circle-dot";
    }
    var v235 = document.getElementById(arg5);
    if (v235) {
      v235.textContent = arg6;
    }
  }
  var v108 = 0;
  window.showUI = function v233(arg3) {
    if (window.__sourceDiscoveryUiHidden) {
      // إذا بدأ الفيديو فعلياً فالاكتشاف انتهى؛ لا نُبقي الواجهة مخفية.
      if (v4 && !v4.paused && v4.currentTime > 0) {
        window.__sourceDiscoveryUiHidden = false;
      } else {
        return;
      }
    }
    if (Date.now() < v52 && arg3 !== true) {
      return;
    }
    var v234 = document.getElementById("player");
    if (!v234) {
      return;
    }
    v5.classList.add("on");
    v6.classList.add("on");
    v234.classList.add("ui-on");
    v50 = true;
    v108 = Date.now();
    clearTimeout(v48);
    if (!arg3 && !v4.paused && !v51) {
      v48 = setTimeout(hideUI, 3200);
    }
  };
  window.hideUI = function v1() {
    if (v51) {
      return;
    }
    if (Date.now() - v108 < 320) {
      return;
    }
    var v2 = document.getElementById("player");
    if (!v2) {
      return;
    }
    v5.classList.remove("on");
    v6.classList.remove("on");
    v2.classList.remove("ui-on");
    v50 = false;
  };
  v4.addEventListener("play", function () {
    v16.className = "fa-solid fa-pause";
    v17.classList.remove("paused");
  });
  v4.addEventListener("pause", function () {
    v16.className = "fa-solid fa-play";
    v17.classList.add("paused");
  });
  function v109() {
    v16.classList.remove("pop");
    v16.offsetWidth;
    v16.classList.add("pop");
  }
  var v110 = null;
  function v111() {
    if (!v4.duration || v49) {
      return;
    }
    if (v110) {
      return;
    }
    v110 = requestAnimationFrame(function () {
      v110 = null;
      if (!v4.duration || v49) {
        return;
      }
      var v1 = (v4.currentTime / v4.duration) * 100;
      v9.style.width = v1 + "%";
      v11.style.left = "calc(" + v1 + "% - " + (v1 / 100) * 0 + "px)";
      v12.textContent = window.fmt(v4.currentTime);
      v13.textContent = window.fmt(v4.duration);
      if (v14) {
        v14.textContent = window.fmt(v4.currentTime);
      }
      if (v15) {
        v15.textContent = window.fmt(v4.duration);
      }
      if (v4.buffered.length) {
        var v2 = 0;
        for (var v233 = 0; v233 < v4.buffered.length; v233++) {
          if (v4.buffered.start(v233) <= v4.currentTime + 1) {
            v2 = Math.max(v2, v4.buffered.end(v233));
          }
        }
        v10.style.width = (v2 / v4.duration) * 100 + "%";
      }
    });
  }
  var v112 = null;
  var v113 = 0;
  function v114(arg3) {
    var v233 = v8.getBoundingClientRect();
    v113 = Math.max(0, Math.min(1, (arg3 - v233.left) / v233.width));
    var v234 = v113;
    v9.style.width = v234 * 100 + "%";
    v11.style.left = v234 * 100 + "%";
    v12.textContent = window.fmt(v234 * (v4.duration || 0));
    if (!v49) {
      v4.currentTime = v234 * (v4.duration || 0);
    }
  }
  function v115(arg3) {
    var v233 = v8.getBoundingClientRect();
    var v234 =
      arg3 !== undefined
        ? Math.max(0, Math.min(1, (arg3 - v233.left) / v233.width))
        : v113;
    v4.currentTime = v234 * (v4.duration || 0);
    if (typeof window._checkAndShowNextEpBtn === "function") {
      window._checkAndShowNextEpBtn();
    }
  }
  var v116 = document.getElementById("tooltip-time");
  var v117 = -1;
  var v118 = 0;
  var v119 = 0;
  var v120 = {
    left: null,
    right: null,
  };
  function v121(arg3) {
    if (!v4.duration) {
      return;
    }
    var v233 = v8.getBoundingClientRect();
    var v234 = Math.max(0, Math.min(1, (arg3 - v233.left) / v233.width));
    var v235 = v234 * v4.duration;
    var v236 = 8;
    var v237 = Math.max(v236, Math.min(v233.width - v236, v234 * v233.width));
    v43.style.left = v237 + "px";
    v116.textContent = window.fmt(v235);
    v43.classList.add("show");
    v117 = v234;
  }
  window.doSkip = function v233(arg3, arg4) {
    var v234 = arg4 * 10;
    var v235 = arg3 === "left" ? -v234 : v234;
    v4.currentTime = Math.max(
      0,
      Math.min(v4.duration || 0, v4.currentTime + v235),
    );
    if (typeof window._checkAndShowNextEpBtn === "function") {
      window._checkAndShowNextEpBtn();
    }
    var v236 = arg3 === "left" ? v23 : v24;
    var v237 = arg3 === "left" ? v25 : v26;
    if (arg3 === "left") {
      v118 += v234;
      v237.textContent = "-" + v118 + "s";
      clearTimeout(v120.left);
      v120.left = setTimeout(function () {
        v118 = 0;
        v236.classList.remove("show");
        v236.classList.add("hide");
        setTimeout(function () {
          v236.classList.remove("hide");
          v237.textContent = "-10s";
        }, 420);
      }, 900);
    } else {
      v119 += v234;
      v237.textContent = "+" + v119 + "s";
      clearTimeout(v120.right);
      v120.right = setTimeout(function () {
        v119 = 0;
        v236.classList.remove("show");
        v236.classList.add("hide");
        setTimeout(function () {
          v236.classList.remove("hide");
          v237.textContent = "+10s";
        }, 420);
      }, 900);
    }
    v236.classList.remove("hide");
    v236.offsetWidth;
    v236.classList.add("show");
    window.haptic();
  };
  function v122() {
    v4.classList.add("ready");
    var v1 = setInterval(function () {
      if (v4.buffered.length && v4.currentTime < v4.buffered.start(0) - 0.5) {
        v4.currentTime = v4.buffered.start(0);
        clearInterval(v1);
      } else if (
        v4.currentTime > 0 ||
        (v4.buffered.length && v4.currentTime >= v4.buffered.start(0))
      ) {
        clearInterval(v1);
      }
    }, 100);
    v4.playbackRate = v72;
    function v2() {
      if (Math.abs(v4.playbackRate - v72) > 0.01) {
        v4.playbackRate = v72;
      }
    }
    v4.addEventListener("ratechange", v2);
    setTimeout(function () {
      v4.removeEventListener("ratechange", v2);
    }, 3000);
    v13.textContent = window.fmt(v4.duration);
    var v233 = document.querySelector(".loader-bottom-glow");
    if (v233) {
      v233.classList.add("video-playing");
    }
    setTimeout(function () {
      showUI(true);
    }, 180);
    v133();
    v125();
    v128();
    if (v45) {
      v45.innerHTML = v46.high;
    }
    if (v44) {
      v44.value = 100;
    }
    v47();
    if (v44) {
      v44.addEventListener("input", function () {
        v4.volume = this.value / 100;
        v4.muted = this.value == 0;
        v47();
      });
    }
    var v234 = document.getElementById("btn-volume");
    if (v234) {
      v234.addEventListener("click", function (arg3) {
        arg3.stopPropagation();
        v4.muted = !v4.muted;
        v47();
      });
    }
    v4.addEventListener("volumechange", v47);
  }
  var v123 = false;
  var v124 = false;
  function v125() {
    var v1 = v4.play();
    if (v1 !== undefined) {
      v1.then(function () {
        if (v4.muted) {
          v124 = true;
          v126();
        } else {
          v123 = true;
        }
      }).catch(function () {
        v4.muted = true;
        v4.play()
          .then(function () {
            v124 = true;
            v126();
          })
          .catch(function () {
            v126();
          });
      });
    } else {
      v4.muted = true;
      v126();
    }
  }
  function v126() {
    var v1 = document.getElementById("unmute-hint");
    var v2 = false;
    v1.style.opacity = "1";
    v1.style.pointerEvents = "auto";
    function v233() {
      if (v2) {
        return;
      }
      v2 = true;
      v4.muted = false;
      v4.volume = 1;
      v123 = true;
      v124 = false;
      v1.style.opacity = "0";
      setTimeout(function () {
        v1.style.display = "none";
      }, 300);
      v1.removeEventListener("touchend", v234);
      v1.removeEventListener("click", v235);
      document.removeEventListener("touchend", v237, true);
      document.removeEventListener("click", v238, true);
      window.haptic();
    }
    function v234(arg3) {
      arg3.stopPropagation();
      arg3.preventDefault();
      v233();
    }
    function v235(arg3) {
      arg3.stopPropagation();
      v233();
    }
    var v236 = false;
    setTimeout(function () {
      v236 = true;
    }, 600);
    function v237(arg3) {
      if (!v236) {
        return;
      }
      if (arg3.target.id === "__hx") {
        return;
      }
      v233();
    }
    function v238(arg3) {
      if (!v236) {
        return;
      }
      if (arg3.target.id === "__hx") {
        return;
      }
      v233();
    }
    v1.addEventListener("touchend", v234, {
      passive: false,
    });
    v1.addEventListener("click", v235);
    document.addEventListener("touchend", v237, true);
    document.addEventListener("click", v238, true);
  }
  function v127() {
    if (v123) {
      return;
    }
    function v1() {
      if (v4.paused) {
        v4.muted = true;
        v4.play()
          .then(function () {
            v124 = true;
            v126();
          })
          .catch(function () {});
      }
      document.removeEventListener("touchstart", v1);
      document.removeEventListener("mousedown", v1);
    }
    document.addEventListener("touchstart", v1, {
      once: true,
      passive: true,
    });
    document.addEventListener("mousedown", v1, {
      once: true,
    });
  }
  window.addEventListener("orientationchange", function () {
    setTimeout(function () {
      v50 = false;
      showUI(true);
      var v1 = document.getElementById("player-controls-wrapper");
      if (v1) {
        v1.style.pointerEvents = "";
        v1.style.opacity = "";
      }
    }, 350);
  });
  v127();
  function v128() {
    try {
      var v1 = parseFloat(localStorage.getItem("playerVolume"));
      if (!isNaN(v1) && v1 >= 0 && v1 <= 1) {
        v4.volume = v1;
      }
    } catch (v2) {}
  }
  v4.addEventListener("volumechange", function () {
    if (!v4.muted) {
      try {
        localStorage.setItem("playerVolume", v4.volume);
      } catch (v1) {}
    }
  });
  var v129 = 0;
  var v130 = 6;
  var v131 = null;
  var v132 = null;
  function v133() {
    if (v129 >= v130) {
      return;
    }
    v131 = setTimeout(function () {
      if (!isNaN(v4.duration) && v4.duration > 0) {
        return;
      }
      if (v4.readyState >= 2) {
        return;
      }
      v129++;
      v137();
      var v1 = v149(v3);
      if (!v1 && Hls.isSupported()) {
        hls.stopLoad();
        hls.startLoad();
      }
      v133();
    }, 800);
  }
  function v134() {
    clearInterval(v132);
    var v1 = 0;
    v132 = setInterval(function () {
      v1++;
      if (!isNaN(v4.duration) && v4.duration > 0) {
        clearInterval(v132);
        v13.textContent = window.fmt(v4.duration);
        v207();
        return;
      }
      if (v1 >= 40) {
        clearInterval(v132);
      }
    }, 250);
  }
  var v135 = document.getElementById("buffering-spinner");
  var v136 = null;
  function v137() {
    clearTimeout(v136);
    v136 = setTimeout(function () {
      if (v4.paused || v4.readyState >= 3) {
        return;
      }
      v135.classList.add("active");
    }, 500);
  }
  function v138() {
    clearTimeout(v136);
    v135.style.display = "flex";
    v135.classList.add("active");
  }
  function v139() {
    clearTimeout(v136);
    v135.classList.remove("active");
    v135.style.display = "";
  }
  v4.addEventListener("waiting", v137);
  v4.addEventListener("stalled", v137);
  v4.addEventListener("playing", v139);
  v4.addEventListener("canplay", v139);
  v4.addEventListener("playing", function () {
    var v1 = document.getElementById("error-screen");
    if (v1) {
      v1.classList.remove("show");
    }
  });
  v4.addEventListener("canplay", function () {
    var v1 = document.getElementById("error-screen");
    if (v1 && v4.duration > 0 && !isNaN(v4.duration)) {
      v1.classList.remove("show");
    }
  });
  var v140 = false;
  var v141 = false;
  var v142 = false;
  function v143(arg3) {
    console.error("Error", {
      message: arg3,
      currentUrl: window._activeMediaUrl || v4.src,
      readyState: v4.readyState,
      networkState: v4.networkState,
      error: v4.error,
    });
    if (
      typeof currentSourceIndex === "number" &&
      Array.isArray(window.sources) &&
      currentSourceIndex < window.sources.length - 1
    ) {
      currentSourceIndex++;
      var v233 = window.sources[currentSourceIndex];
      if (typeof v198 === "function") {
        v198(v233, currentSourceIndex);
        return;
      }
    }
    if (v142) {
      return;
    }
    v142 = true;
    var v234 = document.querySelector(".err-text");
    var v235 = document.querySelector(".err-sub");
    if (v234) {
      v234.textContent = "Playback failed";
    }
    if (!v235 && v234) {
      v234.insertAdjacentHTML("afterend", '<div class="err-sub"></div>');
      v235 = document.querySelector(".err-sub");
    }
    if (v235) {
      var v236 =
        arg3 ||
        "The video source could not be played. This may be due to a temporary network issue or an unsupported format.";
      v235.textContent =
        v236 + " (Source: " + (window._activeSourceLabel || "Unknown") + ")";
    }
    var v237 = document.getElementById("error-screen");
    if (v237) {
      v237.classList.add("show");
    }
    v139();
  }
  v4.addEventListener("error", function () {
    if (v140 || !v141) {
      return;
    }
    var v1 =
      window.__lastSourceError &&
      window.__lastSourceError.details &&
      window.__lastSourceError.details.error
        ? window.__lastSourceError.details.error
        : "The video source could not be loaded. It may be unavailable or the URL may be incorrect.";
    v143(v1);
  });
  var v144 = true;
  var v145 = null;
  function v146() {
    v32.innerHTML = "";
    var v1 = [];
    if (window.hls && window.hls.levels && window.hls.levels.length > 0) {
      window.hls.levels.forEach(function (arg3, arg4) {
        v1.push({
          label: arg3.height ? arg3.height + "p" : "Source " + (arg4 + 1),
          value: arg4,
          type: "hls",
          height: arg3.height || 0,
        });
      });
    } else if (Array.isArray(window.sources)) {
      window.sources.forEach(function (arg3) {
        if (arg3.quality || (arg3.label && /\d+p/i.test(arg3.label))) {
          v1.push({
            label: arg3.quality || arg3.label,
            value: arg3.url,
            type: "direct",
            height: parseInt(arg3.quality || arg3.label) || 0,
          });
        }
      });
    }
    v1.sort(function (arg3, arg4) {
      return arg4.height - arg3.height;
    });
    var v2 = {};
    v1.forEach(function (arg3) {
      if (v2[arg3.label]) {
        return;
      }
      v2[arg3.label] = true;
      var v235 = document.createElement("div");
      v235.className = "quality-row";
      v235.innerHTML =
        '<span class="quality-row-label">' +
        arg3.label +
        '</span><i class="fa-solid fa-check quality-row-check"></i>';
      v235.addEventListener("click", function (arg4) {
        arg4.stopPropagation();
        v144 = false;
        v145 = arg3.label;
        if (arg3.type === "hls") {
          window.hls.currentLevel = arg3.value;
          window.hls.loadLevel = arg3.value;
          var v236 = v4.currentTime;
          window.hls.stopLoad();
          window.hls.startLoad();
          v4.currentTime = v236;
        } else if (arg3.type === "dash") {
          window.dashPlayer.setQualityFor("video", arg3.value, true);
        } else {
          v193(arg3.value, true);
        }
        v148();
        v147();
        window.haptic(6);
      });
      v32.appendChild(v235);
    });
    var v233 = document.createElement("div");
    v233.className = "quality-divider";
    v32.appendChild(v233);
    var v234 = document.createElement("div");
    v234.className = "quality-auto-row";
    v234.innerHTML =
      '<span class="quality-auto-label">Automatic quality</span><div class="settings-toggle' +
      (v144 ? " on" : "") +
      '" id="quality-auto-toggle"><div class="settings-toggle-knob"></div></div>';
    v32.appendChild(v234);
    v234
      .querySelector("#quality-auto-toggle")
      .addEventListener("click", function (arg3) {
        arg3.stopPropagation();
        v144 = true;
        v145 = null;
        if (window.hls) {
          window.hls.currentLevel = -1;
          window.hls.loadLevel = -1;
        }
        if (window.dashPlayer) {
          window.dashPlayer.updateSettings({
            streaming: {
              abr: {
                autoSwitchBitrate: {
                  video: true,
                },
              },
            },
          });
        }
        v148();
        v147();
        window.haptic(6);
      });
    v147();
  }
  function v147() {
    var v1 = v32.querySelectorAll(".quality-row");
    v1.forEach(function (arg3) {
      var v233 = arg3.querySelector(".quality-row-label").textContent;
      var v234 = arg3.querySelector(".quality-row-check");
      var v235 = !v144 && v145 === v233;
      arg3.classList.toggle("quality-row-active", v235);
      if (v234) {
        v234.style.display = v235 ? "block" : "none";
      }
    });
    var v2 = document.getElementById("quality-auto-toggle");
    if (v2) {
      v2.classList.toggle("on", v144);
    }
  }
  function v148() {
    var v1 = document.getElementById("lbl-quality");
    if (!v1) {
      return;
    }
    if (!v144 && v145) {
      v1.textContent = v145;
      return;
    }
    if (window.hls && window.hls.levels && window.hls.levels.length > 0) {
      var v2 =
        window.hls.currentLevel === -1
          ? window.hls.loadLevel
          : window.hls.currentLevel;
      var v233 = window.hls.levels[v2];
      if (v233) {
        var v234 = v233.height;
        var v235 = v234 + "p";
        if (v234 >= 2000) {
          v235 = "4K";
        }
        v1.textContent = "Auto (" + v235 + ")";
        return;
      }
    }
    v1.textContent = "Auto";
  }
  function v149(arg3) {
    if (!arg3) {
      return false;
    }
    var v233 = String(arg3);
    if (/\.m3u8/i.test(v233)) {
      return false;
    }
    if (/\.(mp4|m4v|webm|ogg|mov|mkv|avi)(?:\?|#|$)/i.test(v233)) {
      return true;
    }
    if (/[?&](fn|file|fs|fx)=1/i.test(v233)) {
      return true;
    }
    if (/(?:^|[/?&])type=mp4(?:$|[?&])/i.test(v233)) {
      return true;
    }
    if (/\/videos\//i.test(v233)) {
      return true;
    }
    try {
      var v234 = new URL(v233, window.location.href);
      var v235 = v234.searchParams;
      var v236 =
        v234.pathname === "/api" ||
        v234.pathname.endsWith("/api") ||
        v234.pathname.includes("/api/proxy");
      if (v236 && v235.has("url")) {
        return true;
      }
    } catch (v1) {}
    return false;
  }
  function v150(arg3) {
    if (!arg3) {
      return false;
    }
    return /\.mpd(?:\?|#|$)/i.test(String(arg3));
  }
  function v151(arg3) {
    if (window.dashjs) {
      arg3();
      return;
    }
    var v233 = document.createElement("script");
    v233.src =
      "https://cdnjs.cloudflare.com/ajax/libs/dashjs/4.7.4/dash.all.min.js";
    v233.onload = arg3;
    v233.onerror = function () {
      v143("Failed to load DASH player");
    };
    document.head.appendChild(v233);
  }
  function v152(arg3, arg4) {
    if (!arg3) {
      return;
    }
    window._activeMediaUrl = arg3;
    v138();
    v193(arg3, arg4 !== false);
  }
  v152(v3, true);
  if (v72 !== 1) {
    v31.forEach(function (arg3) {
      if (parseFloat(arg3.dataset.speed) === v72) {
        v107("speed-opts", arg3, "lbl-speed", arg3.textContent.trim());
      }
    });
  }
  // مسارات ملفات حقيقية حتى تعمل حتى لو لم تتوفر قواعد إعادة الكتابة (.htaccess)
  var v153 = window.baseURL + "/api/proxy.php?url=";
  var v154 =
    window.baseURL +
    "/api/subtitles/index.php?" +
    (s
      ? "type=tv&id=" + id + "&season=" + s + "&episode=" + (e || "1")
      : "type=movie&id=" + id);
  document.getElementById("lbl-subtitle").textContent = "Off";
  var v155 = document.getElementById("sub-entries-inline");
  if (v155) {
    v155.innerHTML =
      '<div class="sub-skeleton"><div class="sub-skel-item"></div><div class="sub-skel-item"></div><div class="sub-skel-item"></div></div>';
  }
  function v156(arg3) {
    arg3 = arg3.trim().split(" ")[0].replace(",", ".");
    var v233 = arg3.split(":");
    if (v233.length === 2) {
      return +v233[0] * 60 + +v233[1];
    }
    return +v233[0] * 3600 + +v233[1] * 60 + +v233[2];
  }
  function v157(arg3) {
    return arg3
      .replace(/<[^>]+>/g, "")
      .replace(/\{[^}]+\}/g, "")
      .trim();
  }
  function v158(arg3) {
    var v233 = [];
    arg3
      .trim()
      .split(/\n\s*\n/)
      .forEach(function (arg4) {
        var v234 = arg4.trim().split("\n");
        var v235 = -1;
        for (var v236 = 0; v236 < v234.length; v236++) {
          if (v234[v236].includes("-->")) {
            v235 = v236;
            break;
          }
        }
        if (v235 < 0) {
          return;
        }
        var v237 = v234[v235].split("-->");
        var v238 = v234
          .slice(v235 + 1)
          .map(v157)
          .join("\n")
          .trim();
        if (v238) {
          v233.push({
            start: v156(v237[0]),
            end: v156(v237[1]),
            text: v238,
          });
        }
      });
    return v233;
  }
  function v159(arg3) {
    var v233 = [];
    arg3
      .trim()
      .split(/\n\s*\n/)
      .forEach(function (arg4) {
        var v234 = arg4.trim().split("\n");
        var v235 = -1;
        for (var v236 = 0; v236 < v234.length; v236++) {
          if (v234[v236].includes("-->")) {
            v235 = v236;
            break;
          }
        }
        if (v235 < 0) {
          return;
        }
        var v237 = v234[v235].split("-->");
        var v238 = v234
          .slice(v235 + 1)
          .map(v157)
          .join("\n")
          .trim();
        if (v238) {
          v233.push({
            start: v156(v237[0]),
            end: v156(v237[1]),
            text: v238,
          });
        }
      });
    return v233;
  }
  function v160(arg3) {
    var v233 = arg3.trim();
    var v234 = v158(v233);
    if (!v234.length) {
      v234 = v159(v233);
    }
    return v234;
  }
  function v161(arg3, arg4) {
    var v233 = 0;
    var v234 = arg3.length - 1;
    while (v233 <= v234) {
      var v235 = (v233 + v234) >> 1;
      var v236 = arg3[v235];
      if (arg4 < v236.start) {
        v234 = v235 - 1;
      } else if (arg4 > v236.end) {
        v233 = v235 + 1;
      } else {
        return v236.text;
      }
    }
    return "";
  }
  var v162 = null;
  function v163() {
    if (v60.activeTrack < 0 || !v60.cues.length) {
      if (v162 !== "") {
        v42.textContent = "";
        v162 = "";
      }
      return;
    }
    var v1 = v161(v60.cues, v4.currentTime);
    if (v1 !== v162) {
      v42.textContent = v1;
      v162 = v1;
    }
  }
  v4.addEventListener("timeupdate", v163);
  if (v60.cueTimer) {
    clearInterval(v60.cueTimer);
    v60.cueTimer = null;
  }
  window.getSessionToken = function () {
    if (window.store && window.store.sessionToken) {
      return Promise.resolve(window.store.sessionToken);
    }
    return fetch("/api/auth", {
      method: "POST",
    })
      .then(function (arg3) {
        if (!arg3.ok) {
          throw new Error("Auth failed");
        }
        return arg3.json();
      })
      .then(function (arg3) {
        if (arg3.token && window.store) {
          window.store.sessionToken = arg3.token;
        }
        return arg3.token;
      });
  };
  function v164(arg3, arg4) {
    return (
      window.store && window.store.sessionToken
        ? Promise.resolve(window.store.sessionToken)
        : window.getSessionToken()
    ).then(function (arg5) {
      var v233 = {};
      if (arg5) {
        v233["X-Session-Token"] = arg5;
      }
      return fetch(
        arg3,
        Object.assign({}, arg4 || {}, {
          headers: Object.assign(
            v233,
            arg4 && arg4.headers ? arg4.headers : {},
          ),
        }),
      );
    });
  }
  function v165(arg3) {
    return v164(arg3)
      .then(function (arg4) {
        if (!arg4.ok) {
          throw new Error("HTTP " + arg4.status);
        }
        return arg4.text();
      })
      .then(function (arg4) {
        var v233 = arg4.trim();
        if (v233.length < 10) {
          throw new Error("empty");
        }
        if (v233.startsWith("#EXTM3U")) {
          throw new Error("HLS");
        }
        if (v233.startsWith("{") || v233.startsWith("[")) {
          throw new Error("JSON");
        }
        var v234 = v160(v233);
        if (!v234.length) {
          throw new Error("no cues");
        }
        return v234;
      })
      .catch(function (arg4) {
        var v233 = v153 + encodeURIComponent(arg3);
        return v164(v233)
          .then(function (arg5) {
            if (!arg5.ok) {
              throw new Error("HTTP " + arg5.status);
            }
            return arg5.text();
          })
          .then(function (arg5) {
            var v234 = arg5.trim();
            if (v234.length < 10) {
              throw new Error("empty");
            }
            if (v234.startsWith("#EXTM3U")) {
              throw new Error("HLS");
            }
            if (v234.startsWith("{") || v234.startsWith("[")) {
              throw new Error("JSON");
            }
            var v235 = v160(v234);
            if (!v235.length) {
              throw new Error("no cues");
            }
            return v235;
          })
          .catch(function (arg5) {
            throw arg5;
          });
      });
  }
  // ── تجميع الترجمات من كل المصادر ──────────────────────────────────────────
  window.__subtitlePool = window.__subtitlePool || [];
  var _subSeen = {};
  function renderSubtitleList() {
    var v233 = window.__subtitlePool.filter(function (arg4) {
      return arg4 && (arg4.file || arg4.url) && arg4.label;
    });
    if (!v233.length) {
      if (v155) {
        v155.innerHTML =
          '<div style="padding:20px;text-align:center;color:rgba(255,255,255,0.3);font-size:14px;">None available</div>';
        v155.style.display = "block";
      }
      return;
    }
    window.availableSubtitles = v233;
    var v234 = {};
    v233.forEach(function (arg4, arg5) {
      arg4._idx = arg5;
      var v235 = arg4.label || "Unknown";
      var v236 = v235.replace(/\d+$/, "").trim().split(" ")[0];
      if (!v234[v236]) {
        v234[v236] = {
          label: v236,
          subs: [],
        };
      }
      v234[v236].subs.push(arg4);
    });
    window._buildLangGroups = function () {
      if (!v155) {
        return;
      }
      v155.innerHTML = "";
      v155.style.display = "block";
      Object.keys(v234).forEach(function (arg4) {
        var v235 = v234[arg4];
        var v236 = window.getLangCode ? window.getLangCode(v235.label) : "";
        var v237 = document.createElement("div");
        v237.className = "sub-lang-group-item";
        v237.innerHTML =
          (window.flagImg ? window.flagImg(v236) : "") +
          '<span class="slg-name">' +
          v235.label +
          '</span><span class="slg-count">' +
          v235.subs.length +
          '</span><i class="fa-solid fa-chevron-right slg-chevron"></i>';
        v237.addEventListener("click", function () {
          window.haptic(6);
          v166(v235.label, v235.subs, v236);
        });
        v155.appendChild(v237);
      });
    };
    window._buildLangGroups();
  }
  // تُستدعى من أي مصدر (المزوّدون + نقطة الترجمة المركزية)
  window.mergeSubtitles = function (list) {
    if (!Array.isArray(list) || !list.length) return;
    var added = 0;
    list.forEach(function (arg4) {
      if (!arg4) return;
      var u = arg4.file || arg4.url;
      if (!u || _subSeen[u]) return;
      _subSeen[u] = true;
      window.__subtitlePool.push({
        label: arg4.label || arg4.display || arg4.language || "Subtitle",
        language: arg4.language || "",
        source: arg4.source || "",
        format: arg4.format || "",
        file: u,
        url: u,
      });
      added++;
    });
    if (added) renderSubtitleList();
  };
  // ادمج أي ترجمات وصلت من المزوّدين قبل جاهزية المشغّل
  if (Array.isArray(window.__providerSubtitles) && window.__providerSubtitles.length) {
    window.mergeSubtitles(window.__providerSubtitles);
  }
  v164(v154)
    .then(function (arg3) {
      if (!arg3.ok) {
        throw new Error("HTTP " + arg3.status);
      }
      return arg3.json();
    })
    .then(function (arg3) {
      var list = Array.isArray(arg3) ? arg3 : arg3.subtitles || [];
      window.mergeSubtitles(list);
      if (!window.__subtitlePool.length) renderSubtitleList();
    })
    .catch(function () {
      renderSubtitleList();
    });

  function v166(arg3, arg4, arg5) {
    var v233 = document.getElementById("sub-entries-inline");
    if (!v233) {
      return;
    }
    v233.innerHTML = "";
    var v234 = document.querySelector("#sub-lang-group-view .sub-special-list");
    var v235 = document.getElementById("sub-section-divider");
    var v236 = document.querySelector("#sub-lang-group-view .svsh-title");
    var v237 = document.getElementById("sub-customize-open-btn");
    var v238 = document.querySelector("#sub-lang-group-view .svsh-back");
    if (v234) {
      v234.style.display = "none";
    }
    if (v235) {
      v235.style.display = "none";
    }
    if (v237) {
      v237.style.display = "none";
    }
    var v239 =
      arg5 || (typeof getLangCode === "function" ? getLangCode(arg3) : "");
    if (v236) {
      v236.innerHTML =
        (v239
          ? '<img class="slg-flag" src="https://flagcdn.com/20x15/' +
            v239 +
            '.png" width="20" height="15" style="border-radius:2px;object-fit:cover;vertical-align:middle;margin-right:6px;">'
          : "") + arg3;
    }
    var v240 = null;
    if (v238) {
      v240 = v238.cloneNode(true);
      v238.replaceWith(v240);
      v240.addEventListener("click", function () {
        v233.innerHTML = "";
        if (v234) {
          v234.style.display = "";
        }
        if (v235) {
          v235.style.display = "";
        }
        if (v237) {
          v237.style.display = "";
        }
        if (v236) {
          v236.textContent = "Subtitles";
        }
        if (typeof window._buildLangGroups === "function") {
          window._buildLangGroups();
        }
        var v1 = document.querySelector("#sub-lang-group-view .svsh-back");
        if (v1) {
          v1.addEventListener("click", function () {
            if (typeof v169 === "function") {
              v169("main");
            }
            if (typeof window.haptic === "function") {
              window.haptic(6);
            }
          });
        }
        if (typeof window.haptic === "function") {
          window.haptic(6);
        }
      });
    }
    arg4.forEach(function (arg6) {
      var v241 = document.createElement("div");
      v241.className = "sub-entry-row";
      var v242 = arg6.file || arg6.url || "";
      var v243 =
        v242.replace(/^https?:\/\//, "").substring(0, 28) +
        (v242.length > 28 ? "…" : "");
      var v244 = (
        arg6.format ||
        arg6.type ||
        (v242.toLowerCase().includes(".srt") ? "srt" : "vtt")
      ).toUpperCase();
      var v245 = arg6.source || "";
      var v246 =
        arg5 || (typeof getLangCode === "function" ? getLangCode(arg3) : "");
      var v247 = v246
        ? '<img src="https://flagcdn.com/20x15/' +
          v246 +
          '.png" width="26" height="20" style="border-radius:3px;object-fit:cover;flex-shrink:0;" alt="">'
        : '<i class="fa-solid fa-globe" style="font-size:13px;color:var(--white-45);width:26px;text-align:center;"></i>';
      v241.innerHTML =
        v247 +
        '<div class="se-info"><span class="se-url">' +
        v243 +
        '</span><div class="se-badges"><span class="window.fmt-badge">' +
        v244 +
        "</span>" +
        (v245
          ? '<span class="window.fmt-badge se-src-badge">' +
            v245.toUpperCase() +
            "</span>"
          : "") +
        '</div></div><i class="fa-solid fa-language se-lang-icon"></i>';
      v241.addEventListener("mouseenter", function () {
        this.style.background = "rgba(255,255,255,0.06)";
      });
      v241.addEventListener("mouseleave", function () {
        if (!this.dataset.active) {
          this.style.background = "";
        }
      });
      v241.addEventListener("click", function () {
        v241.style.opacity = "0.5";
        if (typeof v165 === "function") {
          v165(v242)
            .then(function (arg7) {
              v233.querySelectorAll(".sub-entry-row").forEach(function (arg8) {
                arg8.removeAttribute("data-active");
                arg8.style.background = "";
              });
              v241.setAttribute("data-active", "1");
              v241.style.background = "rgba(255,255,255,0.1)";
              v241.style.opacity = "";
              v60.activeTrack = arg6._idx;
              v60.cues = arg7;
              v162 = null;
              document.getElementById("lbl-subtitle").textContent = arg3;
              var v248 = document.getElementById("sub-off-check");
              if (v248) {
                v248.style.display = "none";
              }
              var v249 = document.getElementById("subtitle-toggle");
              if (v249) {
                v249.classList.add("on");
              }
              if (typeof window.haptic === "function") {
                window.haptic(6);
              }
              if (typeof v168 === "function") {
                v168();
              }
            })
            .catch(function () {
              v241.style.opacity = "";
            });
        }
      });
      v233.appendChild(v241);
    });
    v233.style.display = "";
  }
  function v167() {
    v51 = true;
    v169("main");
    document.getElementById("settings-modal-wrap").classList.add("open");
    document.getElementById("settings-overlay-backdrop").classList.add("open");
    showUI(true);
    window.haptic(10);
  }
  function v168() {
    v51 = false;
    document.getElementById("settings-modal-wrap").classList.remove("open");
    document
      .getElementById("settings-overlay-backdrop")
      .classList.remove("open");
    if (!v4.paused) {
      clearTimeout(v48);
      v48 = setTimeout(hideUI, 3200);
    }
  }
  function v169(arg3) {
    document.querySelectorAll(".settings-view").forEach(function (arg4) {
      arg4.classList.remove("active");
      arg4.style.display = "none";
    });
    var v233 = document.getElementById("settings-view-" + arg3);
    if (v233) {
      v233.style.display = "flex";
      v233.classList.add("active");
      if (arg3 === "subtitles") {
        document.getElementById("sub-lang-group-view").style.display = "flex";
        document.getElementById("sub-custom-view").style.display = "none";
      }
    }
  }
  v29.addEventListener("click", function (arg3) {
    arg3.stopPropagation();
    arg3.stopImmediatePropagation();
    if (v51) {
      v168();
    } else {
      v167();
    }
  });
  var v170 = document.getElementById("settings-close-btn");
  if (v170) {
    v170.addEventListener("click", function (arg3) {
      arg3.stopPropagation();
      v168();
    });
  }
  document
    .getElementById("settings-overlay-backdrop")
    .addEventListener("click", function () {
      v168();
    });
  document
    .getElementById("main-watchparty-btn")
    .addEventListener("click", function (arg3) {
      arg3.stopPropagation();
      v169("watchparty");
      window.haptic(6);
    });
  document
    .getElementById("main-segment-btn")
    .addEventListener("click", function (arg3) {
      arg3.stopPropagation();
      v169("segments");
      window.haptic(6);
      v196();
    });
  var v171 = null;
  var v172 = false;
  var v173 = [];
  function v174(arg3) {
    if (arg3 == null) {
      return "0";
    }
    var v233 = Math.floor(arg3 / 1000);
    var v234 = Math.floor(v233 / 60);
    v233 = v233 % 60;
    return v234 + ":" + (v233 < 10 ? "0" : "") + v233;
  }
  var v175 = {
    intro: {
      label: "Intro",
      icon: "fa-clapperboard",
      color: "var(--white)",
      btnLabel: "Skip Intro",
    },
    recap: {
      label: "Recap",
      icon: "fa-clock-rotate-left",
      color: "var(--white)",
      btnLabel: "Skip Recap",
    },
    credits: {
      label: "Credits",
      icon: "fa-film",
      color: "var(--white)",
      btnLabel: "Skip Credits",
    },
    preview: {
      label: "Preview",
      icon: "fa-forward",
      color: "var(--white)",
      btnLabel: "Skip Preview",
    },
  };
  function v176() {
    var v1 = document.getElementById("seg-content");
    if (!v1) {
      return;
    }
    if (!v171) {
      v1.innerHTML =
        '<div class="seg-empty"><div class="seg-empty-icon"><i class="fa-solid fa-film"></i></div><div class="seg-empty-title">No segments found</div><div class="seg-empty-desc">No skip segments are available for this title yet.</div></div>';
      return;
    }
    var v2 = ["intro", "recap", "credits", "preview"];
    var v233 = [];
    v2.forEach(function (arg3) {
      var v235 = v171[arg3];
      if (v235 && v235.length) {
        v235.forEach(function (arg4, arg5) {
          if (arg4.start_ms != null || arg4.end_ms != null) {
            v233.push({
              type: arg3,
              seg: arg4,
              idx: arg5,
            });
          }
        });
      }
    });
    if (!v233.length) {
      v1.innerHTML =
        '<div class="seg-empty"><div class="seg-empty-title">No skip segments</div><div class="seg-empty-desc">This title has no skippable segments in the database.</div></div>';
      return;
    }
    var v234 = '<div class="seg-list">';
    v233.forEach(function (arg3) {
      var v235 = v175[arg3.type] || {
        label: arg3.type,
        icon: "fa-forward",
        color: "#888",
      };
      var v236 = arg3.seg;
      var v237 = v174(v236.start_ms);
      var v238 = v174(v236.end_ms);
      v234 +=
        '<div class="seg-item"><div class="seg-icon" style="background:' +
        v235.color +
        '20;"><i class="fa-solid ' +
        v235.icon +
        '" style="color:' +
        v235.color +
        ';"></i></div><div class="seg-info"><div class="seg-label">' +
        v235.label +
        (v233.filter(function (arg4) {
          return arg4.type === arg3.type;
        }).length > 1
          ? " " + (arg3.idx + 1)
          : "") +
        '</div><div class="seg-time">' +
        v237 +
        " - " +
        v238 +
        "</div></div></div>";
    });
    v234 += "</div>";
    v1.innerHTML = v234;
  }
  function v177() {
    if (!v171) {
      return;
    }
    v173 = [];
    var v1 = ["intro", "recap", "credits", "preview"];
    v1.forEach(function (arg3) {
      var v235 = v171[arg3];
      if (!v235 || !v235.length) {
        return;
      }
      v235.forEach(function (arg4) {
        var v236 = v175[arg3] || {
          btnLabel: "Skip",
        };
        v173.push({
          start: arg4.start_ms != null ? arg4.start_ms / 1000 : 0,
          end: arg4.end_ms != null ? arg4.end_ms / 1000 : v4.duration || 0,
          label: v236.btnLabel,
        });
      });
    });
    var v2 = document.getElementById("skip-segment-btn");
    var v233 = document.getElementById("skip-segment-label");
    v4.addEventListener("timeupdate", function () {
      if (!v173.length) {
        return;
      }
      var v235 = v4.currentTime;
      var v236 = null;
      for (var v237 = 0; v237 < v173.length; v237++) {
        var v238 = v173[v237];
        if (v235 >= v238.start && v235 < v238.end) {
          v236 = v238;
          break;
        }
      }
      if (v236) {
        v233.textContent = v236.label;
        v2.classList.add("show");
        v2._activeSeg = v236;
      } else {
        v2.classList.remove("show");
        v2._activeSeg = null;
      }
    });
    v2.addEventListener("click", function () {
      var v235 = this._activeSeg;
      if (v235) {
        v4.currentTime = v235.end;
        window.haptic(6);
      }
    });
    function v234() {
      if (v4.duration && v4.duration > 0) {
        v173.forEach(function (arg3) {
          if (arg3.end === 0 || isNaN(arg3.end)) {
            arg3.end = v4.duration;
          }
        });
      }
    }
    v4.addEventListener("loadedmetadata", v234);
    v4.addEventListener("durationchange", v234);
  }
  (function () {
    v196();
  })();
  (function () {
    var v1 = {
      active: false,
      isHost: false,
      roomCode: null,
      peer: null,
      connections: [],
      hostConn: null,
      overlayOn: false,
      members: 1,
      syncInterval: null,
      lockControls: false,
      disconnected: false,
      lastRoomCode: null,
    };
    var v2 = document.getElementById("wp-main-view");
    var v233 = document.getElementById("wp-join-view");
    var v234 = document.getElementById("wp-hosting-view");
    var v235 = document.getElementById("wp-host-btn");
    var v236 = document.getElementById("wp-join-btn");
    var v237 = document.getElementById("wp-join-cancel-btn");
    var v238 = document.getElementById("wp-join-confirm-btn");
    var v239 = document.getElementById("wp-code-input");
    var v240 = document.getElementById("wp-room-code");
    var v241 = document.getElementById("wp-leave-btn");
    var v242 = document.getElementById("wp-reconnect-btn");
    var v243 = document.getElementById("wp-code-display");
    var v244 = document.getElementById("wp-members-list");
    var v245 = document.getElementById("wp-overlay-toggle");
    var v246 = document.getElementById("wp-backend-label");
    var v247 = document.getElementById("wp-backend-name");
    if (v246) {
      v246.textContent = "P2P via WebRTC (PeerJS)";
    }
    if (v247) {
      v247.textContent = "PeerJS";
    }
    function v248() {
      var v272 = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
      var v273 = "";
      for (var v274 = 0; v274 < 6; v274++) {
        v273 += v272[Math.floor(Math.random() * v272.length)];
      }
      return v273;
    }
    function v249(arg3) {
      if (v2) {
        v2.style.display = "none";
      }
      if (v233) {
        v233.style.display = "none";
      }
      if (v234) {
        v234.style.display = "none";
      }
      if (arg3 === "main" && v2) {
        v2.style.display = "flex";
      } else if (arg3 === "join" && v233) {
        v233.style.display = "flex";
      } else if (arg3 === "hosting" && v234) {
        v234.style.display = "flex";
      }
    }
    function v250() {
      if (v244) {
        if (v1.members <= 1) {
          v244.textContent = "▸ Alone — share the code!";
        } else {
          v244.textContent = "▸ " + v1.members + " watching together";
        }
      }
    }
    function v251(arg3) {
      v1.lockControls = arg3;
      var v272 = document.getElementById("wp-guest-lock-banner");
      if (arg3) {
        if (!v272) {
          v272 = document.createElement("div");
          v272.id = "wp-guest-lock-banner";
          v272.style.cssText =
            "position:absolute;bottom:72px;left:50%;transform:translateX(-50%);z-index:28;background:rgba(0,0,0,0.72);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);border-radius:100px;padding:7px 18px;font-size:12px;font-weight:600;color:rgba(255,255,255,0.7);pointer-events:none;white-space:nowrap;display:flex;align-items:center;gap:7px;";
          v272.innerHTML =
            '<i class="fa-solid fa-lock" style="font-size:11px;"></i> Host controls playback';
          document.getElementById("player").appendChild(v272);
        }
        v272.style.display = "flex";
        var v273 = document.getElementById("btn-play");
        if (v273) {
          v273.style.opacity = "0.35";
        }
        var v274 = document.getElementById("track-wrap");
        if (v274) {
          v274.style.pointerEvents = "none";
        }
      } else {
        if (v272) {
          v272.style.display = "none";
        }
        var v273 = document.getElementById("btn-play");
        if (v273) {
          v273.style.opacity = "";
        }
        var v274 = document.getElementById("track-wrap");
        if (v274) {
          v274.style.pointerEvents = "";
        }
      }
    }
    function v252(arg3) {
      if (!arg3) {
        return "";
      }
      try {
        return decodeURIComponent(String(arg3).trim());
      } catch (v272) {
        return String(arg3 || "").trim();
      }
    }
    function v253() {
      return v252(window._activeMediaUrl || v4.currentSrc || v4.src || "");
    }
    function v254() {
      var v272 =
        Array.isArray(sources) && sources[currentSourceIndex]
          ? sources[currentSourceIndex]
          : null;
      var v273 = v272
        ? v272.label || v272.source || "Source"
        : window._activeSourceLabel || "Source";
      var v274 = v272 && v272.url ? v272.url : window._activeMediaUrl || "";
      return {
        label: v273,
        index: typeof currentSourceIndex === "number" ? currentSourceIndex : -1,
        url: v274,
        sourceKey: v272 ? v272.key || v272.source || "" : "",
      };
    }
    function v255(arg3) {
      if (!arg3) {
        return;
      }
      var v272 = arg3.url || arg3.sourceUrl || "";
      if (arg3.sourceLabel) {
        window._activeSourceLabel = String(arg3.sourceLabel).trim();
        var v273 = document.getElementById("lbl-source");
        if (v273) {
          var v274 =
            window._activeSourceLabel.charAt(0).toUpperCase() +
            window._activeSourceLabel.slice(1);
          v273.textContent = v274;
        }
      }
      if (
        typeof arg3.sourceIndex === "number" &&
        Array.isArray(sources) &&
        sources[arg3.sourceIndex]
      ) {
        currentSourceIndex = arg3.sourceIndex;
        window._activeSourceLabel =
          sources[arg3.sourceIndex].label ||
          sources[arg3.sourceIndex].source ||
          window._activeSourceLabel ||
          "Source";
        if (v272 && !sources[arg3.sourceIndex].url) {
          sources[arg3.sourceIndex].url = v272;
        }
      }
      if (v272 && Array.isArray(sources)) {
        var v275 = sources.find(function (arg4) {
          return arg4 && v252(arg4.url || "") === v252(v272);
        });
        if (v275) {
          currentSourceIndex = sources.indexOf(v275);
          window._activeSourceLabel =
            v275.label || v275.source || window._activeSourceLabel || "Source";
          if (!v275.url) {
            v275.url = v272;
          }
        }
      }
      if (typeof buildSourceList === "function") {
        buildSourceList();
      }
    }
    function v256(arg3, arg4, arg5) {
      var v272 = v254();
      return {
        type: arg3,
        time: arg4,
        paused: arg5,
        src: v253(),
        sourceLabel: v272.label,
        sourceIndex: v272.index,
        sourceUrl: v272.url,
        sourceKey: v272.sourceKey,
      };
    }
    function v257(arg3) {
      v1.connections.forEach(function (arg4) {
        if (arg4.open) {
          try {
            arg4.send(arg3);
          } catch (v272) {}
        }
      });
    }
    function v258(arg3) {
      if (!arg3 || !arg3.type) {
        return;
      }
      v255(arg3);
      var v272 = v252(arg3.src || arg3.sourceUrl || "");
      var v273 = v253();
      var v274 = !!v272 && (!v273 || v272 !== v273);
      var v275 = arg3.type === "play" || (arg3.type === "sync" && !arg3.paused);
      if (arg3.type === "play") {
        if (Math.abs(v4.currentTime - arg3.time) > 0.5) {
          v4.currentTime = arg3.time;
        }
        if (!v274) {
          v4.play().catch(function () {});
        } else {
          try {
            v193(v272, false, v275);
          } catch (v278) {
            try {
              window.play(
                v272,
                window.store && window.store.id ? window.store.id : null,
              );
            } catch (v279) {}
          }
        }
      } else if (arg3.type === "pause") {
        if (Math.abs(v4.currentTime - arg3.time) > 0.5) {
          v4.currentTime = arg3.time;
        }
        if (!v274) {
          v4.pause();
        } else {
          try {
            v193(v272, false, v275);
          } catch (v278) {}
        }
      } else if (arg3.type === "seek") {
        if (!v274) {
          v4.currentTime = arg3.time;
        } else {
          try {
            v193(v272, false, false);
          } catch (v278) {}
        }
      } else if (arg3.type === "sync") {
        if (v274) {
          try {
            if (arg3.sourceUrl && Array.isArray(sources)) {
              var v276 = sources.find(function (arg4) {
                return arg4 && v252(arg4.url || "") === v272;
              });
              if (v276) {
                currentSourceIndex = sources.indexOf(v276);
                window._activeSourceLabel =
                  v276.label ||
                  v276.source ||
                  window._activeSourceLabel ||
                  "Source";
                if (!v276.url) {
                  v276.url = v272;
                }
              }
            }
            v193(v272, false, v275);
          } catch (v278) {
            try {
              window.play(
                v272,
                window.store && window.store.id ? window.store.id : null,
              );
            } catch (v279) {}
          }
          return;
        }
        var v277 = v4.currentTime - arg3.time;
        if (!v4.paused && Math.abs(v277) > 1.5) {
          v4.currentTime = arg3.time;
        }
        if (arg3.paused && !v4.paused) {
          v4.pause();
        }
        if (!arg3.paused && v4.paused) {
          v4.play().catch(function () {});
        }
      } else if (arg3.type === "member_count") {
        v1.members = arg3.count;
        v250();
        v268();
      }
    }
    function v259() {
      v4.addEventListener("play", function () {
        var v272 = document.getElementById("play-btn-icon");
        if (v272) {
          v272.className = "fa-solid fa-pause";
        }
      });
      v4.addEventListener("pause", function () {
        var v272 = document.getElementById("play-btn-icon");
        if (v272) {
          v272.className = "fa-solid fa-play";
        }
      });
      v4.addEventListener("seeked", function () {
        if (!v1.active || !v1.isHost) {
          return;
        }
        v257(v256("seek", v4.currentTime, v4.paused));
      });
    }
    v259();
    function v260() {
      clearInterval(v1.syncInterval);
      v1.syncInterval = setInterval(function () {
        if (!v1.active || !v1.isHost) {
          return;
        }
        v257(v256("sync", v4.currentTime, v4.paused));
      }, 5000);
    }
    function v261(arg3, arg4) {
      if (typeof Peer === "undefined") {
        var v272 = document.createElement("script");
        v272.src = "https://unpkg.com/peerjs@1.5.2/dist/peerjs.min.js";
        v272.onload = function () {
          v262(arg3, arg4);
        };
        v272.onerror = function () {
          v263("Failed to load PeerJS. Check your connection.");
        };
        document.head.appendChild(v272);
      } else {
        v262(arg3, arg4);
      }
    }
    function v262(arg3, arg4) {
      if (v1.peer) {
        try {
          v1.peer.destroy();
        } catch (v273) {}
      }
      var v272 = new Peer(arg3, {
        debug: 0,
      });
      v1.peer = v272;
      v272.on("open", function (arg5) {
        arg4(arg5);
      });
      v272.on("error", function (arg5) {
        var v273 =
          arg5.type === "unavailable-id"
            ? "Room code already in use. Try a different one."
            : arg5.type === "peer-unavailable"
              ? "Room not found. Check the code and try again."
              : "Connection error: " + (arg5.message || arg5.type);
        v263(v273);
        v267();
      });
      v272.on("connection", function (arg5) {
        arg5.on("open", function () {
          v1.connections.push(arg5);
          v1.members = 1 + v1.connections.length;
          v250();
          v268();
          v257({
            type: "member_count",
            count: v1.members,
          });
          try {
            arg5.send(v256("sync", v4.currentTime, v4.paused));
          } catch (v273) {}
          setTimeout(function () {
            try {
              arg5.send(v256("sync", v4.currentTime, v4.paused));
            } catch (v273) {}
          }, 800);
        });
        arg5.on("data", function (arg6) {
          if (arg6 && arg6.type === "request_sync") {
            try {
              arg5.send(v256("sync", v4.currentTime, v4.paused));
            } catch (v273) {}
          }
        });
        arg5.on("close", function () {
          v1.connections = v1.connections.filter(function (arg6) {
            return arg6 !== arg5;
          });
          v1.members = 1 + v1.connections.length;
          v250();
          v268();
          v257({
            type: "member_count",
            count: v1.members,
          });
        });
        arg5.on("error", function () {
          v1.connections = v1.connections.filter(function (arg6) {
            return arg6 !== arg5;
          });
          v1.members = 1 + v1.connections.length;
          v250();
        });
      });
    }
    function v263(arg3) {
      var v272 = document.getElementById("wp-error-msg");
      if (!v272) {
        v272 = document.createElement("div");
        v272.id = "wp-error-msg";
        v272.style.cssText =
          "font-size:13px;color:#ff6b6b;text-align:center;padding:10px 16px;line-height:1.5;";
        if (v2) {
          v2.insertBefore(v272, v2.firstChild);
        }
      }
      v272.textContent = arg3;
      v272.style.display = "block";
      setTimeout(function () {
        if (v272) {
          v272.style.display = "none";
        }
      }, 5000);
    }
    function v264(arg3, arg4, arg5) {
      if (!arg3) {
        return;
      }
      arg3.disabled = arg4;
      arg3.textContent = arg4 ? "Connecting…" : arg5;
    }
    function v265() {
      if (typeof window.setWatchPartySourceMode === "function") {
        window.setWatchPartySourceMode(false);
      }
      var v272 = v248();
      var v273 = "vyla-wp-" + v272;
      v264(v235, true, "Host a Watch Party");
      v261(v273, function (arg3) {
        v264(v235, false, "Host a Watch Party");
        v1.active = true;
        v1.isHost = true;
        v1.roomCode = v272;
        v1.members = 1;
        v1.connections = [];
        if (v240) {
          v240.textContent = v272;
        }
        v250();
        v249("hosting");
        v268();
        v260();
        v251(false);
      });
    }
    function v266(arg3) {
      if (typeof window.setWatchPartySourceMode === "function") {
        window.setWatchPartySourceMode(true);
      }
      var v272 = arg3.toUpperCase().trim();
      var v273 = "vyla-wp-guest-" + Math.random().toString(36).slice(2, 8);
      var v274 = "vyla-wp-" + v272;
      v264(v238, true, "Join");
      v261(v273, function () {
        var v275 = v1.peer.connect(v274, {
          reliable: true,
        });
        v1.hostConn = v275;
        var v276 = setTimeout(function () {
          v264(v238, false, "Join");
          v263("Could not reach that room. Is the code correct?");
          v249("join");
        }, 10000);
        v275.on("open", function () {
          clearTimeout(v276);
          v264(v238, false, "Join");
          v1.active = true;
          v1.isHost = false;
          v1.roomCode = v272;
          v1.lastRoomCode = v272;
          v1.disconnected = false;
          v1.members = 2;
          if (v240) {
            v240.textContent = v272;
          }
          v250();
          v249("hosting");
          v268();
          v251(true);
          if (v242) {
            v242.style.display = "none";
          }
          if (v241) {
            v241.style.display = "block";
          }
          setTimeout(function () {
            try {
              v275.send({
                type: "request_sync",
              });
            } catch (v277) {}
          }, 250);
        });
        v275.on("data", function (arg4) {
          v258(arg4);
        });
        v275.on("close", function () {
          if (!v1.active) {
            return;
          }
          v1.disconnected = true;
          v1.lastRoomCode = v1.roomCode;
          v263("Host disconnected.");
          if (v242) {
            v242.style.display = "block";
          }
          if (v241) {
            v241.style.display = "none";
          }
        });
        v275.on("error", function () {
          clearTimeout(v276);
          v264(v238, false, "Join");
          v263("Could not reach that room. Is the code correct?");
          v249("join");
        });
      });
    }
    function v267() {
      if (typeof window.setWatchPartySourceMode === "function") {
        window.setWatchPartySourceMode(false);
      }
      clearInterval(v1.syncInterval);
      v1.syncInterval = null;
      if (v1.hostConn) {
        try {
          v1.hostConn.close();
        } catch (v272) {}
        v1.hostConn = null;
      }
      v1.connections.forEach(function (arg3) {
        try {
          arg3.close();
        } catch (v272) {}
      });
      v1.connections = [];
      if (v1.peer) {
        try {
          v1.peer.destroy();
        } catch (v272) {}
        v1.peer = null;
      }
      v1.active = false;
      v1.isHost = false;
      v1.roomCode = null;
      v1.members = 1;
      v1.disconnected = false;
      v1.lastRoomCode = null;
      v251(false);
      if (v242) {
        v242.style.display = "none";
      }
      if (v241) {
        v241.style.display = "block";
      }
      v249("main");
      v268();
    }
    function v268() {
      var v272 = document.getElementById("wp-status-overlay");
      if (!v1.active) {
        if (v272) {
          v272.style.display = "none";
        }
        return;
      }
      if (!v272) {
        v272 = document.createElement("div");
        v272.id = "wp-status-overlay";
        v272.style.cssText =
          "position:absolute;top:10px;right:10px;z-index:25;background:rgba(0,0,0,0.7);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);border-radius:12px;padding:8px 14px;display:flex;flex-direction:column;gap:3px;pointer-events:none;min-width:140px;";
        document.getElementById("player").appendChild(v272);
      }
      if (!v1.overlayOn) {
        v272.style.display = "none";
        return;
      }
      v272.style.display = "";
      v272.innerHTML =
        '<div style="display:flex;align-items:center;gap:7px;"><i class="fa-solid fa-podcast" style="font-size:11px;color:var(--white);"></i><span style="font-size:12px;font-weight:700;color:rgba(255,255,255,0.9);">' +
        (v1.isHost ? "Hosting" : "Watching") +
        '</span><span style="font-size:13px;font-weight:700;color:var(--white);letter-spacing:0.08em;">' +
        v1.roomCode +
        '</span></div><div style="font-size:11px;color:rgba(255,255,255,0.55);">▸ ' +
        (v1.members <= 1 ? "Alone" : v1.members + " watching") +
        "</div>";
    }
    if (v235) {
      v235.addEventListener("click", function () {
        v265();
        window.haptic(6);
      });
    }
    if (v236) {
      v236.addEventListener("click", function () {
        v249("join");
        v239.value = "";
        setTimeout(function () {
          v239.focus();
        }, 120);
        window.haptic(6);
      });
    }
    if (v237) {
      v237.addEventListener("click", function () {
        v249("main");
        window.haptic(6);
      });
    }
    if (v238) {
      v238.addEventListener("click", function () {
        var v272 = v239.value.trim();
        if (!v272) {
          return;
        }
        v266(v272);
        window.haptic(6);
      });
    }
    if (v239) {
      v239.addEventListener("keydown", function (arg3) {
        if (arg3.key === "Enter") {
          v238.click();
        }
      });
    }
    if (v241) {
      v241.addEventListener("click", function () {
        v267();
        window.haptic(6);
      });
    }
    if (v242) {
      v242.addEventListener("click", function () {
        if (v1.disconnected && v1.lastRoomCode) {
          v1.disconnected = false;
          if (v242) {
            v242.style.display = "none";
          }
          if (v241) {
            v241.style.display = "block";
          }
          if (v239) {
            v239.value = v1.lastRoomCode;
          }
          if (v238) {
            v238.click();
          }
        }
        window.haptic(6);
      });
    }
    if (v243) {
      v243.addEventListener("click", function () {
        var v272 =
          location.origin +
          location.pathname +
          location.search +
          "&wp=" +
          v1.roomCode;
        if (navigator.clipboard) {
          navigator.clipboard
            .writeText(v272)
            .then(function () {
              var v273 = v243.querySelector("i");
              if (v273) {
                v273.className = "fa-solid fa-check";
                setTimeout(function () {
                  v273.className = "fa-solid fa-copy";
                }, 1500);
              }
            })
            .catch(function () {});
        }
        window.haptic(6);
      });
    }
    var v269 = document.getElementById("btn-subtitles-shortcut");
    if (v269) {
      v269.addEventListener("click", function (arg3) {
        arg3.stopPropagation();
        v167();
        v169("subtitles");
      });
    }
    if (v245) {
      v245.addEventListener("click", function () {
        v1.overlayOn = !v1.overlayOn;
        this.classList.toggle("on", v1.overlayOn);
        v268();
        window.haptic(6);
      });
    }
    document.addEventListener(
      "keydown",
      function (arg3) {
        if (!v1.lockControls) {
          return;
        }
        if (arg3.key === " " || arg3.key === "k" || arg3.key === "K") {
          arg3.stopImmediatePropagation();
          arg3.preventDefault();
        }
        if (arg3.key === "ArrowLeft" || arg3.key === "ArrowRight") {
          arg3.stopImmediatePropagation();
          arg3.preventDefault();
        }
      },
      true,
    );
    var v270 = document.getElementById("settings-view-watchparty");
    if (v270) {
      v270.addEventListener("click", function (arg3) {
        arg3.stopPropagation();
      });
    }
    var v271 =
      (location.hash.match(/wp=([A-Z0-9]+)/) || [])[1] ||
      new URLSearchParams(location.search).get("wp") ||
      null;
    if (v271) {
      setTimeout(function () {
        if (document.getElementById("main-watchparty-btn")) {
          document.getElementById("main-watchparty-btn").click();
        }
        if (v239) {
          v239.value = v271;
        }
        if (v236) {
          v236.click();
        }
        setTimeout(function () {
          if (v239) {
            v239.value = v271;
          }
          if (v238) {
            v238.click();
          }
        }, 200);
      }, 1500);
    }
  })();
  document
    .querySelector('.settings-tile[data-nav="sources"]')
    .addEventListener("click", function (arg3) {
      arg3.stopPropagation();
      v169("sources");
      window.haptic(6);
    });
  document
    .querySelector('.settings-tile[data-nav="quality"]')
    .addEventListener("click", function (arg3) {
      arg3.stopPropagation();
      v146();
      v169("quality");
      window.haptic(6);
    });
  document
    .querySelector('.settings-tile[data-nav="subtitles"]')
    .addEventListener("click", function (arg3) {
      arg3.stopPropagation();
      v169("subtitles");
      window.haptic(6);
    });
  document
    .querySelector('.settings-tile[data-nav="video"]')
    .addEventListener("click", function (arg3) {
      arg3.stopPropagation();
      v169("video");
      window.haptic(6);
    });
  document.querySelectorAll(".settings-back-btn").forEach(function (arg3) {
    if (arg3.id === "sub-main-back-btn") {
      return;
    }
    arg3.addEventListener("click", function (arg4) {
      arg4.stopPropagation();
      v169("main");
      window.haptic(6);
    });
  });
  var v178 = document.getElementById("subtitle-toggle");
  if (v178) {
    v178.addEventListener("click", function (arg3) {
      arg3.stopPropagation();
      if (v60.activeTrack >= 0) {
        v60.activeTrack = -1;
        v60.cues = [];
        v42.textContent = "";
        v162 = "";
        v178.classList.remove("on");
        document.getElementById("lbl-subtitle").textContent = "Off";
        var v233 = document.querySelector(".sub-off-item");
        if (v233) {
          document
            .querySelectorAll(".sub-special-item, .sub-lang-item")
            .forEach(function (arg4) {
              arg4.classList.remove("active-sub-item");
              var v236 = arg4.querySelector(".sub-active-check");
              if (v236) {
                v236.style.display = "none";
              }
            });
          v233.classList.add("active-sub-item");
          var v234 = v233.querySelector(".sub-active-check");
          if (v234) {
            v234.style.display = "block";
          }
        }
      } else {
        var v235 = document.querySelector(".sub-lang-item:not(.disabled)");
        if (v235) {
          v235.click();
        } else {
          v178.classList.remove("on");
        }
      }
      window.haptic(6);
    });
    var v179 = document.getElementById("btn-toggle-vr");
    if (v179) {
      if (!window.isMobile || !window.isMobile()) {
        var v180 = document.getElementById("vr-toggle-row");
        var v181 = document.getElementById("vr-mode-sub");
        if (v180) {
          v180.style.display = "none";
        }
        if (v181) {
          v181.style.display = "none";
        }
      }
      v179.addEventListener("click", function (arg3) {
        arg3.stopPropagation();
        v102(!v61.vr);
        window.haptic(6);
      });
    }
    var v182 = document.getElementById("vr-split-select");
    if (v182) {
      v182.addEventListener("change", function (arg3) {
        arg3.stopPropagation();
        v61.vrSplit = this.value;
        window.haptic(6);
      });
    }
    var v183 = document.getElementById("speed-boost-toggle");
    if (v183) {
      if (!v73) {
        v183.classList.remove("on");
      }
      v183.addEventListener("click", function (arg3) {
        arg3.stopPropagation();
        v73 = !v73;
        v183.classList.toggle("on", v73);
        try {
          localStorage.setItem("speedBoostEnabled", v73 ? "true" : "false");
        } catch (v1) {}
        window.haptic(6);
      });
    }
  }
  var v184 = document.getElementById("main-pip-btn");
  if (v184) {
    v184.addEventListener("click", function (arg3) {
      arg3.stopPropagation();
      v169("download");
      window.haptic(6);
      var v233 = document.getElementById("download-list");
      if (v233.dataset.loaded) {
        return;
      }
      v233.dataset.loaded = "1";
      v233.innerHTML =
        '<div class="source-skeleton"><div class="source-skel-item"></div><div class="source-skel-item"></div><div class="source-skel-item"></div></div>';
      var v234 = window.e || 1;
      var v235 = (window.id || "").toString().trim();
      var v236 = (window.s || "").toString().trim();
      var v237 = (window.baseURL || "").toString().trim();
      var v238 = window.s
        ? v237 + "/downloads/tv/" + v235 + "/" + v236 + "/" + v234
        : v237 + "/downloads/movie/" + v235;
      function v239(arg4 = 0) {
        var v240 = 2;
        var v241 = [1000, 2000, 4000];
        var v242 = {};
        if (window.store && window.store.sessionToken) {
          v242["x-session-token"] = window.store.sessionToken;
        }
        fetch(v238, {
          headers: v242,
        })
          .then((arg5) => {
            if (!arg5.ok) {
              throw new Error("HTTP " + arg5.status);
            }
            return arg5.json();
          })
          .then((arg5) => {
            var v243 = arg5.downloads || [];
            if (!v243.length) {
              v233.innerHTML =
                '<div style="padding:20px;text-align:center;color:var(--white-45);font-size:14px;">No downloads available.</div>';
              return;
            }
            v233.innerHTML = "";
            v243.forEach((arg6) => {
              var v244 = document.createElement("a");
              v244.className = "download-item";
              v244.href = arg6.url;
              v244.target = "_blank";
              v244.rel = "noopener noreferrer";
              v244.innerHTML =
                '<div class="download-item-left"><span class="download-item-name">' +
                arg6.quality +
                (arg6.size
                  ? ' <span class="download-item-quality">' +
                    arg6.size +
                    "</span>"
                  : "") +
                '</span><span class="download-item-type">' +
                (arg6.format || "") +
                '</span></div><div class="download-item-actions"><i class="fa-solid fa-download"></i></div>';
              v233.appendChild(v244);
            });
          })
          .catch(() => {
            if (arg4 < v240) {
              v233.innerHTML =
                '<div style="padding:20px;text-align:center;color:var(--white-45);font-size:14px;">Retrying... (' +
                (arg4 + 1) +
                "/" +
                (v240 + 1) +
                ')</div><div class="source-skeleton"><div class="source-skel-item"></div><div class="source-skel-item"></div><div class="source-skel-item"></div></div>';
              setTimeout(() => v239(arg4 + 1), v241[arg4]);
            } else {
              v233.innerHTML =
                '<div style="padding:20px;text-align:center;color:var(--white-45);font-size:14px;">Failed to fetch downloads.</div>';
            }
          });
      }
      v239();
    });
  }
  var v185 = document.getElementById("main-playback-btn");
  if (v185) {
    v185.addEventListener("click", function (arg3) {
      arg3.stopPropagation();
      v169("speed");
      window.haptic(6);
    });
  }
  var v186 = document.getElementById("main-video-btn");
  if (v186) {
    v186.addEventListener("click", function (arg3) {
      arg3.stopPropagation();
      v169("video");
      window.haptic(6);
    });
  }
  var v187 = ["brightness", "contrast", "saturate"];
  v187.forEach(function (arg3) {
    var v233 = document.getElementById("vid-" + arg3);
    if (!v233) {
      return;
    }
    v233.addEventListener("input", function (arg4) {
      arg4.stopPropagation();
      v61[arg3] = this.value;
      v79();
      v192();
    });
  });
  var v188 = document.querySelectorAll(".settings-list-item[data-ratio]");
  v188.forEach(function (arg3) {
    arg3.addEventListener("click", function (arg4) {
      arg4.stopPropagation();
      v61.ratio = this.dataset.ratio;
      v79();
      v107("ratio-opts", this, "lbl-ratio", this.textContent.trim());
      window.haptic(6);
    });
  });
  var v189 = document.getElementById("btn-reset-video");
  if (v189) {
    v189.addEventListener("click", function (arg3) {
      arg3.stopPropagation();
      v61.brightness = 100;
      v61.contrast = 100;
      v61.saturate = 100;
      v61.ratio = "contain";
      v79();
      v192();
      var v233;
      v233 = document.getElementById("vid-brightness");
      if (v233) {
        v233.value = 100;
      }
      v233 = document.getElementById("vid-contrast");
      if (v233) {
        v233.value = 100;
      }
      v233 = document.getElementById("vid-saturate");
      if (v233) {
        v233.value = 100;
      }
      var v234 = document.querySelector(
        '.settings-list-item[data-ratio="contain"]',
      );
      if (v234) {
        v107("ratio-opts", v234, "lbl-ratio", "Fit");
      }
      window.haptic(6);
    });
  }
  var v190 = document.getElementById("btn-toggle-ascii");
  if (v190) {
    v190.addEventListener("click", function (arg3) {
      arg3.stopPropagation();
      v83(!v61.ascii);
      window.haptic(6);
    });
  }
  var v191 = document.getElementById("btn-toggle-ascii-color");
  if (v191) {
    v191.addEventListener("click", function (arg3) {
      arg3.stopPropagation();
      v84(!v61.asciiColor);
      window.haptic(6);
    });
  }
  function v192() {
    var v1 = document.getElementById("lbl-video");
    if (!v1) {
      return;
    }
    if (v61.ascii) {
      v1.textContent = "ASCII";
      return;
    }
    var v2 =
      v61.brightness == 100 &&
      v61.contrast == 100 &&
      v61.saturate == 100 &&
      v61.ratio === "contain";
    v1.textContent = v2 ? "Default" : "Custom";
  }
  v31.forEach(function (arg3) {
    arg3.addEventListener("click", function (arg4) {
      arg4.stopPropagation();
      var v233 = parseFloat(this.dataset.speed);
      v4.playbackRate = v233;
      v72 = v233;
      try {
        localStorage.setItem("playbackSpeed", v233);
      } catch (v1) {}
      v107("speed-opts", this, "lbl-speed", this.textContent.trim());
      window.haptic(6);
      showUI(true);
    });
  });
  function v193(arg3, arg4) {
    var v233 = v4.currentTime || 0;
    v141 = true;
    v142 = false;
    v140 = true;
    setTimeout(function () {
      v140 = false;
    }, 2000);
    window._activeMediaUrl = arg3;
    if (window.hls && typeof window.hls.destroy === "function") {
      window.hls.destroy();
      window.hls = null;
    }
    if (window.dashPlayer && typeof window.dashPlayer.destroy === "function") {
      window.dashPlayer.destroy();
      window.dashPlayer = null;
    }
    v4.pause();
    v4.src = "";
    v4.removeAttribute("src");
    v4.load();
    v138();
    if (v150(arg3)) {
      v151(function () {
        v195(arg3, v233, arg4, false);
      });
      return;
    }
    var v234 = !v149(arg3);
    if (v234 && typeof Hls !== "undefined" && Hls.isSupported()) {
      v194(arg3, v233, arg4);
    } else {
      v4.src = arg3;
      v4.load();
      function v1() {
        v4.removeEventListener("error", v1);
        if (typeof Hls !== "undefined" && Hls.isSupported()) {
          v194(arg3, v233, arg4);
        } else {
          v143("Format not supported");
        }
      }
      v4.addEventListener("error", v1);
      function v2() {
        v4.removeEventListener("loadedmetadata", v2);
        v139();
        var v236 = document.querySelector(".loader-bottom-glow");
        if (v236) {
          v236.classList.add("video-playing");
        }
        v122();
        v134();
      }
      v4.addEventListener("loadedmetadata", v2);
      var v235 = v4.play();
      if (v235 !== undefined) {
        v235
          .then(function () {
            if (!isNaN(v233) && v233 > 0) {
              v4.currentTime = v233;
            }
          })
          .catch(function (arg5) {
            if (
              arg5.name === "NotSupportedError" &&
              typeof Hls !== "undefined" &&
              Hls.isSupported()
            ) {
              v4.removeEventListener("error", v1);
              v194(arg3, v233, arg4);
            } else {
              v4.muted = true;
              v4.play().catch(function () {});
            }
          });
      }
    }
  }
  function v194(arg3, arg4, arg5) {
    if (window.hls) {
      window.hls.destroy();
    }
    v4.pause();
    v4.removeAttribute("src");
    v4.load();
    window.hls = new Hls({
      xhrSetup: function (arg6, arg7) {
        if (arg7.startsWith(window.baseURL)) {
          var v233 = window.store && window.store.sessionToken;
          if (v233) {
            arg6.setRequestHeader("X-Session-Token", v233);
          }
        }
      },
    });
    window.hls.loadSource(arg3);
    window.hls.attachMedia(v4);
    window.hls.on(Hls.Events.MANIFEST_PARSED, function () {
      if (!isNaN(arg4) && arg4 > 0) {
        v4.currentTime = arg4;
      }
      v139();
      v146();
      v148();
      v122();
      v134();
      if (arg5 !== false) {
        v4.play().catch(function () {
          v4.muted = true;
          v4.play().catch(function () {});
        });
      }
    });
    window.hls.on(Hls.Events.LEVEL_SWITCHED, function () {
      v148();
    });
    window.hls.on(Hls.Events.ERROR, function (arg6, arg7) {
      if (arg7.fatal) {
        if (arg7.type === Hls.ErrorTypes.NETWORK_ERROR) {
          window.hls.startLoad();
        } else if (arg7.type === Hls.ErrorTypes.MEDIA_ERROR) {
          window.hls.recoverMediaError();
        } else {
          v143(arg7.details);
        }
      }
    });
  }
  function v195(arg3, arg4, arg5, arg6) {
    if (window.dashPlayer) {
      try {
        window.dashPlayer.destroy();
      } catch (v1) {}
      window.dashPlayer = null;
    }
    v4.pause();
    v4.removeAttribute("src");
    v4.load();
    var v233 = dashjs.MediaPlayer().create();
    window.dashPlayer = v233;
    v233.extend(
      "RequestModifier",
      function () {
        return {
          modifyRequestHeader: function (arg7, arg8) {
            if (arg8.url && arg8.url.startsWith(window.baseURL)) {
              var v234 = window.store && window.store.sessionToken;
              if (v234) {
                arg7.setRequestHeader("X-Session-Token", v234);
              }
            }
            return arg7;
          },
          modifyRequestURL: function (arg7) {
            return arg7;
          },
        };
      },
      true,
    );
    v233.initialize(v4, arg3, false);
    v233.on(dashjs.MediaPlayer.events.STREAM_INITIALIZED, function () {
      if (!isNaN(arg4) && arg4 > 0) {
        v4.currentTime = arg4;
      }
      v139();
      v146();
      v148();
      if (arg6) {
        v122();
        v134();
      }
      if (arg5 !== false) {
        v4.play().catch(function () {
          v4.muted = true;
          v4.play().catch(function () {});
        });
      }
    });
    v233.on(dashjs.MediaPlayer.events.QUALITY_CHANGE_RENDERED, function () {
      v148();
    });
    v233.on(dashjs.MediaPlayer.events.ERROR, function (arg7) {
      v143((arg7 && arg7.error && arg7.error.message) || "DASH playback error");
    });
  }
  function v196() {
    var v1 = document.getElementById("seg-content");
    if (!v1) {
      return;
    }
    if (!id) {
      v1.innerHTML = "";
      return;
    }
    if (v172) {
      v176();
      return;
    }
    v1.innerHTML =
      '<div style="display:flex;align-items:center;justify-content:center;padding:40px 0;"><svg width="32" height="32" viewBox="0 0 52 52" style="animation:_vyla_spin 0.9s linear infinite"><circle cx="26" cy="26" r="22" fill="none" stroke="rgba(255,255,255,0.4)" stroke-width="3.5" stroke-dasharray="100" stroke-dashoffset="70"/></svg></div>';
    var v2 = "https://api.theintrodb.org/v3/media?tmdb_id=" + id;
    if (s) {
      v2 += "&season=" + s + "&episode=" + (e || "1");
    }
    fetch(v2)
      .then(function (arg3) {
        return arg3.json();
      })
      .then(function (arg3) {
        v171 = arg3;
        v172 = true;
        v176();
        v177();
      })
      .catch(function (arg3) {
        v172 = true;
        v171 = null;
        v176();
      });
  }
  function v197() {
    if (window._activeSourceLabel) {
      return window._activeSourceLabel;
    }
    var v1 =
      Array.isArray(sources) && sources[currentSourceIndex]
        ? sources[currentSourceIndex]
        : null;
    if (v1) {
      return v1.label || v1.source || "Source";
    } else {
      return "Source";
    }
  }
  buildSourceList = function () {
    var v1 = document.getElementById("sources-opts");
    if (!v1) {
      return;
    }
    v1.innerHTML = "";
    var v2 = v197();
    v2 = v2.charAt(0).toUpperCase() + v2.slice(1);
    var v233 = document.getElementById("lbl-source");
    if (v233) {
      v233.textContent = v2;
    }
    var groups = [];
    var groupMap = {};
    sources.forEach(function (arg3, arg4) {
      var groupId = arg3.groupId || arg3.source || arg3.key;
      if (!groupMap[groupId]) {
        groupMap[groupId] = {
          id: groupId,
          name: arg3.groupName || arg3.name || arg3.source || "Source",
          items: [],
        };
        groups.push(groupMap[groupId]);
      }
      groupMap[groupId].items.push({ source: arg3, index: arg4 });
    });

    groups.forEach(function (group) {
      var wrapper = document.createElement("div");
      wrapper.className = "source-group";
      var header = document.createElement("div");
      header.className = "source-group-header";
      var branches = document.createElement("div");
      branches.className = "source-group-branches";

      var playable = group.items.filter(function (item) {
        return item.source.url && !item.source.isProviderStatus;
      });
      var checking = group.items.some(function (item) {
        return item.source.status === "checking";
      });
      var status = playable.length ? "online" : checking ? "checking" : "offline";
      var subtitleCount = group.items.reduce(function (count, item) {
        return Math.max(
          count,
          Number(item.source.groupSubtitleCount || item.source.subtitleCount || 0),
        );
      }, 0);
      var branchLabel = playable.length
        ? playable.length + " source" + (playable.length === 1 ? "" : "s")
        : status === "checking"
          ? "Checking…"
          : "Unavailable";
      var statusLabel =
        status === "online" ? "Online" : status === "checking" ? "Checking" : "Offline";
      var statusClass = "source-status-" + status;

      header.innerHTML =
        '<span class="source-group-chevron"><i class="fa-solid fa-chevron-right"></i></span>' +
        '<span class="source-group-name">' +
        String(group.name).replace(/</g, "&lt;") +
        "</span>" +
        '<span class="source-group-meta">' +
        '<span class="source-group-status ' +
        statusClass +
        '">' +
        statusLabel +
        "</span>" +
        '<span class="source-group-count">' +
        branchLabel +
        "</span>" +
        (subtitleCount
          ? '<span class="source-group-subs"><i class="fa-solid fa-closed-captioning"></i> ' +
            subtitleCount +
            "</span>"
          : "") +
        "</span>";

      var activeGroup = group.items.some(function (item) {
        return item.index === currentSourceIndex;
      });
      if (activeGroup) {
        branches.classList.add("is-open");
        header.classList.add("is-open");
      }
      header.addEventListener("click", function () {
        window.haptic(6);
        branches.classList.toggle("is-open");
        header.classList.toggle("is-open");
      });

      if (playable.length) {
        group.items.forEach(function (item) {
          var arg3 = item.source;
          if (!arg3.url || arg3.isProviderStatus) return;
          var arg4 = item.index;
          var isActive = arg4 === currentSourceIndex;
          var row = document.createElement("div");
          row.className = "src-list-item source-branch" + (isActive ? " is-active" : "");
          row.dataset.sourceIndex = String(arg4);
          row.innerHTML =
            '<span class="source-branch-indent"></span>' +
            '<span class="source-branch-name">' +
            String(arg3.label || arg3.quality || "Source").replace(/</g, "&lt;") +
            "</span>" +
            (isActive
              ? '<span class="src-check"><i class="fa-solid fa-check"></i></span>'
              : "");
          row.addEventListener("click", function (event) {
            event.stopPropagation();
            if (arg4 === currentSourceIndex) return;
            window.haptic(10);
            v198(arg3, arg4);
          });
          branches.appendChild(row);
        });
      } else {
        var empty = document.createElement("div");
        empty.className = "source-branch-empty";
        var first = group.items[0] && group.items[0].source;
        empty.textContent = first && first.error ? first.error : branchLabel;
        branches.appendChild(empty);
      }
      wrapper.appendChild(header);
      wrapper.appendChild(branches);
      v1.appendChild(wrapper);
    });
    var v234 = document.getElementById("src-find-next-btn");
    if (v234) {
      v234.onclick = function () {
        var v236 = (currentSourceIndex + 1) % sources.length;
        if (sources[v236]) {
          window.haptic(10);
          v198(sources[v236], v236);
        }
      };
    }
    var v235 = document.getElementById("src-detail-back");
    if (v235) {
      v235.onclick = function () {
        var v236 = document.getElementById("src-detail-view");
        var v237 = document.getElementById("src-list-view");
        var v238 = document.getElementById("src-loading-state");
        var v239 = document.getElementById("src-failed-state");
        if (v236) {
          v236.style.display = "none";
        }
        if (v237) {
          v237.style.display = "flex";
        }
        if (v238) {
          v238.style.display = "none";
        }
        if (v239) {
          v239.style.display = "none";
        }
      };
    }
  };
  function v198(arg3, arg4) {
    var v233 = document.getElementById("src-list-view");
    var v234 = document.getElementById("src-detail-view");
    var v235 = document.getElementById("src-detail-title");
    var v236 = document.getElementById("src-loading-state");
    var v237 = document.getElementById("src-failed-state");
    if (!v233 || !v234 || !v235) {
      return;
    }
    var v238 = arg3.label || arg3.source || arg3.key || "Source";
    var v239 = v238.charAt(0).toUpperCase() + v238.slice(1);
    var v240 = arg3.emoji || "";
    v235.textContent = v239 + (v240 ? " " + v240 : "");
    v233.style.display = "none";
    v234.style.display = "flex";
    if (v236) {
      v236.style.display = "flex";
    }
    if (v237) {
      v237.style.display = "none";
    }
    function v241(arg5) {
      if (v236) {
        v236.style.display = "none";
      }
      if (v237) {
        v237.style.display = "none";
      }
      v234.style.display = "none";
      v233.style.display = "flex";
      currentSourceIndex = arg4;
      window._activeSourceLabel = arg3.label || arg3.source || v238;
      if (typeof v168 === "function") {
        v168();
      }
      v193(arg5, true);
      if (typeof buildSourceList === "function") {
        buildSourceList();
      }
    }
    if (arg3.url) {
      var v242 = arg3.url;
      v241(v242);
    } else {
      var _pid = arg3.source || arg3.key || v238;
      var _nonce244 = (function () {
        if (typeof crypto !== "undefined" && crypto.getRandomValues) {
          return Array.from(
            crypto.getRandomValues(new Uint8Array(16)),
            function (b) { return b.toString(16).padStart(2, "0"); }
          ).join("");
        }
        return Math.random().toString(36).slice(2) + Date.now().toString(36);
      })();
      var v243 = new URLSearchParams({
        type: (typeof s !== "undefined" && s) ? "tv" : "movie",
        id: id,
        _st: window.store && window.store.st ? window.store.st : "",
        _ts: Math.floor(Date.now() / 1000),
        _nonce: _nonce244,
      });
      if (typeof s !== "undefined" && s) {
        v243.set("season", s);
        v243.set("episode", typeof e !== "undefined" && e ? e : "1");
      }
      if (window.store && window.store.title) v243.set("title", window.store.title);
      if (_pid === "animecurx") {
        v243.set("action", "streams");
        v243.set("format", "player");
        if (typeof s !== "undefined" && s) {
          v243.set("s", s);
          v243.set("e", typeof e !== "undefined" && e ? e : "1");
        }
      }
      var v244 = "/api/" + _pid + "/index.php?" + v243.toString();
      fetch(v244, {
        headers: {
          "X-Session-Token":
            window.store && window.store.sessionToken
              ? window.store.sessionToken
              : "",
        },
      })
        .then(function (arg5) {
          if (!arg5.ok) {
            throw new Error("Network error: " + arg5.status);
          }
          return arg5.json();
        })
        .then(function (arg5) {
          var v246 = null;
          if (arg5 && arg5.source && arg5.source.m3u8) {
            v246 = arg5.source.m3u8;
          } else if (arg5 && arg5.sources && arg5.sources.length) {
            v246 = arg5.sources[0].url;
          } else if (arg5 && arg5.url) {
            v246 = arg5.url;
          }
          // ادمج ترجمات هذا المصدر مع بقية الترجمات
          if (typeof window.mergeSubtitles === "function") {
            var _subs =
              (arg5 && arg5.subtitles) ||
              (arg5 && arg5.source && arg5.source.subtitles) ||
              [];
            window.mergeSubtitles(
              (_subs || []).map(function (x) {
                return Object.assign({}, x, { source: x.source || _pid });
              }),
            );
          }
          if (!arg5.ok || !v246) {
            throw new Error("Source failed");
          }
          arg3.url = v246;
          v241(v246);
        })

        .catch(function (arg5) {
          if (v236) {
            v236.style.display = "none";
          }
          if (v237) {
            v237.style.display = "flex";
          }
        });
    }
  }
  function v199() {
    if (sourcesLoaded && typeof buildSourceList === "function") {
      buildSourceList();
    }
  }
  v199();
  if (sourcesLoaded && typeof buildSourceList === "function") {
    buildSourceList();
  }
  function v200(arg3, arg4, arg5) {
    if (!arg3) {
      return;
    }
    var v233 = arg5 ? "input" : "change";
    arg3.addEventListener(v233, function (arg6) {
      arg6.stopPropagation();
      v60[arg4] = this.value;
      v78();
      if (!arg5) {
        v77();
      }
    });
    if (arg5) {
      arg3.addEventListener("change", function (arg6) {
        arg6.stopPropagation();
        v77();
        window.haptic(6);
      });
    } else {
      arg3.addEventListener("change", function () {
        window.haptic(6);
      });
    }
  }
  v200(v34, "font", false);
  v200(v35, "size", false);
  v200(v36, "color", true);
  v200(v37, "bgColor", true);
  v200(v38, "bgOpacity", false);
  v200(v39, "pos", false);
  v200(v40, "edge", false);
  if (v27) {
    var v201 =
      "pictureInPictureEnabled" in document ||
      "webkitPictureInPictureEnabled" in document ||
      "pictureInPictureElement" in document;
    if (!v201) {
      v27.style.display = "none";
    } else {
      v27.addEventListener("click", function (arg3) {
        arg3.stopPropagation();
        window.haptic(10);
        var v233 =
          document.pictureInPictureElement ||
          document.webkitPictureInPictureElement;
        if (v233) {
          if (document.exitPictureInPicture) {
            document.exitPictureInPicture();
          } else if (document.webkitExitPictureInPicture) {
            document.webkitExitPictureInPicture();
          }
        } else if (v4.requestPictureInPicture) {
          v4.requestPictureInPicture();
        } else if (v4.webkitRequestPictureInPicture) {
          v4.webkitRequestPictureInPicture();
        }
      });
    }
  }
  if (v28) {
    v28.addEventListener("click", function (arg3) {
      arg3.stopPropagation();
      window.haptic(10);
      if (window.isIOS() && typeof v4.webkitEnterFullscreen === "function") {
        if (v4.webkitDisplayingFullscreen) {
          v4.webkitExitFullscreen();
        } else {
          v4.webkitEnterFullscreen();
        }
        return;
      }
      var v233 =
        document.fullscreenElement ||
        document.webkitFullscreenElement ||
        document.mozFullScreenElement ||
        document.msFullscreenElement;
      if (v233) {
        if (document.exitFullscreen) {
          document.exitFullscreen();
        } else if (document.webkitExitFullscreen) {
          document.webkitExitFullscreen();
        } else if (document.mozCancelFullScreen) {
          document.mozCancelFullScreen();
        } else if (document.msExitFullscreen) {
          document.msExitFullscreen();
        }
      } else {
        var v234 = document.getElementById("player");
        if (v234.requestFullscreen) {
          v234.requestFullscreen();
        } else if (v234.webkitRequestFullscreen) {
          v234.webkitRequestFullscreen();
        } else if (v234.mozRequestFullScreen) {
          v234.mozRequestFullScreen();
        } else if (v234.msRequestFullscreen) {
          v234.msRequestFullscreen();
        }
      }
    });
  }
  v8.addEventListener("mouseenter", function () {
    v7.classList.add("hover");
  });
  v8.addEventListener("mouseleave", function () {
    if (!v49) {
      v7.classList.remove("hover");
    }
    v43.classList.remove("show");
    v117 = -1;
  });
  v8.addEventListener("mousemove", function (arg3) {
    arg3.stopPropagation();
    v121(arg3.clientX);
  });
  v8.addEventListener("mousedown", function (arg3) {
    arg3.stopPropagation();
    v49 = true;
    v7.classList.add("drag");
    v114(arg3.clientX);
    showUI(true);
    window.haptic(6);
  });
  function v202(arg3) {
    if (!v4.duration) {
      return;
    }
    var v233 = v8.getBoundingClientRect();
    var v234 = Math.max(0, Math.min(1, (arg3 - v233.left) / v233.width));
    var v235 = 8;
    var v236 = Math.max(v235, Math.min(v233.width - v235, v234 * v233.width));
    v43.style.left = v236 + "px";
    v116.textContent = window.fmt(v234 * v4.duration);
    v43.classList.add("show");
  }
  v8.addEventListener(
    "touchstart",
    function (arg3) {
      arg3.stopPropagation();
      clearTimeout(v228);
      v49 = true;
      v7.classList.add("drag");
      v114(arg3.touches[0].clientX);
      showUI(true);
      window.haptic();
      v202(arg3.touches[0].clientX);
    },
    {
      passive: true,
    },
  );
  v8.addEventListener(
    "touchmove",
    function (arg3) {
      if (!v49) {
        return;
      }
      arg3.preventDefault();
      v114(arg3.touches[0].clientX);
      v202(arg3.touches[0].clientX);
    },
    {
      passive: false,
    },
  );
  v8.addEventListener("touchend", function (arg3) {
    if (!v49) {
      return;
    }
    var v233 = arg3.changedTouches ? arg3.changedTouches[0].clientX : undefined;
    if (v233 !== undefined) {
      v114(v233);
      v115(v233);
    }
    v49 = false;
    v7.classList.remove("drag", "hover");
    v43.classList.remove("show");
    if (!v4.paused) {
      showUI();
    }
  });
  var v203 = 0;
  function v204(arg3) {
    if (!v49) {
      return;
    }
    v49 = false;
    v7.classList.remove("drag", "hover");
    var v233 = arg3.changedTouches
      ? arg3.changedTouches[0].clientX
      : arg3.clientX;
    v115(v233 !== undefined ? v233 : v203);
    v43.classList.remove("show");
    if (!v4.paused) {
      showUI();
    }
  }
  document.addEventListener("mousemove", function (arg3) {
    if (!v49) {
      return;
    }
    v203 = arg3.clientX;
    v114(arg3.clientX);
    v121(arg3.clientX);
  });
  document.addEventListener(
    "touchmove",
    function (arg3) {
      if (!v49) {
        return;
      }
      v203 = arg3.touches[0].clientX;
      v114(arg3.touches[0].clientX);
      v202(arg3.touches[0].clientX);
    },
    {
      passive: true,
    },
  );
  document.addEventListener("mouseup", v204);
  document.addEventListener("touchend", function (arg3) {
    if (v49) {
      v204(arg3);
    }
  });
  document.addEventListener("keydown", function (arg3) {
    if (
      arg3.target.tagName === "INPUT" ||
      arg3.target.tagName === "SELECT" ||
      arg3.target.tagName === "TEXTAREA"
    ) {
      return;
    }
    if (arg3.key === "ArrowLeft" || arg3.key === "ArrowRight") {
      if (document.body.classList.contains("tv-nav-mode")) {
        return;
      }
      if (arg3.key === "ArrowLeft") {
        doSkip("left", 1);
        showUI();
      }
      if (arg3.key === "ArrowRight") {
        doSkip("right", 1);
        showUI();
      }
      return;
    }
    if (arg3.key === " " || arg3.key === "k" || arg3.key === "K") {
      arg3.preventDefault();
      window.haptic(10);
      if (v4.paused) {
        v4.play();
      } else {
        v4.pause();
      }
    }
    if (arg3.key === "f" || arg3.key === "F") {
      if (window.isIOS() && typeof v4.webkitEnterFullscreen === "function") {
        if (v4.webkitDisplayingFullscreen) {
          v4.webkitExitFullscreen();
        } else {
          v4.webkitEnterFullscreen();
        }
        return;
      }
      var v233 =
        document.fullscreenElement ||
        document.webkitFullscreenElement ||
        document.mozFullScreenElement ||
        document.msFullscreenElement;
      if (v233) {
        if (document.exitFullscreen) {
          document.exitFullscreen();
        } else if (document.webkitExitFullscreen) {
          document.webkitExitFullscreen();
        } else if (document.mozCancelFullScreen) {
          document.mozCancelFullScreen();
        } else if (document.msExitFullscreen) {
          document.msExitFullscreen();
        }
      } else {
        var v234 = document.getElementById("player");
        if (v234.requestFullscreen) {
          v234.requestFullscreen();
        } else if (v234.webkitRequestFullscreen) {
          v234.webkitRequestFullscreen();
        } else if (v234.mozRequestFullScreen) {
          v234.mozRequestFullScreen();
        } else if (v234.msRequestFullscreen) {
          v234.msRequestFullscreen();
        }
      }
    }
  });
  (function () {
    var v1 = null;
    var v2 = null;
    var v233 = [
      {
        key: "Space / K",
        desc: "Play / Pause",
      },
      {
        key: "← →",
        desc: "Skip 10 seconds",
      },
      {
        key: "F",
        desc: "Fullscreen",
      },
    ];
    document.addEventListener("keydown", function (arg3) {
      if (arg3.key === "?") {
        if (!v1) {
          v1 = document.createElement("div");
          v233.forEach(function (arg4) {
            var v234 = document.createElement("div");
            v234.innerHTML =
              '<span style="background:rgba(255,255,255,0.12);border-radius:6px;padding:3px 10px;font-size:12px;font-weight:700;color:var(--white);letter-spacing:0.04em;min-width:36px;text-align:center;font-family:var(--font);">' +
              arg4.key +
              '</span><span style="font-size:13px;color:rgba(255,255,255,0.75);font-family:var(--font);font-weight:500;">' +
              arg4.desc +
              "</span>";
            v1.appendChild(v234);
          });
          document.body.appendChild(v1);
        }
        v1.style.opacity = "1";
        clearTimeout(v2);
        v2 = setTimeout(function () {
          v1.style.opacity = "0";
        }, 3000);
      }
    });
  })();
  var v205 = null;
  document.getElementById("player").addEventListener("mousemove", function () {
    var v1 = document.getElementById("player");
    if (v1) {
      v1.style.setProperty("cursor", "default", "important");
      clearTimeout(v205);
      v205 = setTimeout(function () {
        v1.style.removeProperty("cursor");
      }, 3000);
    }
    if (!v4.paused) {
      clearTimeout(v48);
      if (v50) {
        if (!v51) {
          v48 = setTimeout(hideUI, 3200);
        }
      } else {
        showUI();
      }
    } else {
      showUI();
    }
  });
  v4.addEventListener("timeupdate", v111);
  var v206 = false;
  function v207() {
    if (v206) {
      return;
    }
    var v1 = s ? arg2 + "_s" + s + "_e" + (e || "1") : arg2;
    var v2 = v75(v1);
    if (v2 > 5 && v4.duration > v2 + 5) {
      v4.currentTime = v2;
      v206 = true;
    }
  }
  v4.addEventListener("loadedmetadata", function () {
    v207();
  });
  v4.addEventListener("loadeddata", function () {
    v207();
  });
  v4.addEventListener("canplay", function () {
    v207();
  });
  v4.addEventListener("durationchange", function () {
    if (v4.duration) {
      clearTimeout(v131);
      v129 = v130;
      v139();
      v207();
    }
  });
  setTimeout(function () {
    v207();
  }, 2000);
  var v208 = 0;
  v4.addEventListener("timeupdate", function () {
    var v1 = Date.now();
    if (v1 - v208 > 5000) {
      var v2 = s ? arg2 + "_s" + s + "_e" + (e || "1") : arg2;
      v74(v2, v4.currentTime);
      v208 = v1;
    }
  });
  var v209 = s ? document.getElementById("next-ep-btn") : null;
  var v210 = s ? document.getElementById("next-ep-inner") : null;
  var v211 = s ? document.getElementById("next-ep-label") : null;
  var v212 = null;
  var v213 = false;
  function v214() {
    if (!v209 || !v213 || !v4.duration || v4.duration < 60) {
      return;
    }
    var v1 = v4.duration - v4.currentTime;
    v209.style.display = "";
    if (v1 <= 300) {
      v209.classList.add("show");
    } else {
      v209.classList.remove("show");
    }
  }
  window._checkAndShowNextEpBtn = v214;
  window._getNextEpBtn = function () {
    return v209;
  };
  window._isNextEpReady = function () {
    return v213;
  };
  if (s && v209 && v210 && v211) {
    v209.style.display = "none";
    var v215 = parseInt(e || "1") + 1;
    var v216 = parseInt(s);
    fetch(
      window.baseURL +
        "/api/tv?id=" +
        id +
        "&season=" +
        v216 +
        "&episode=" +
        v215,
      {
        headers: {
          "X-Session-Token":
            window.store && window.store.sessionToken
              ? window.store.sessionToken
              : "",
        },
      },
    )
      .then(function (arg3) {
        return arg3.json();
      })
      .then(function (arg3) {
        var v233 = arg3.meta
          ? arg3.meta.title || arg3.meta.name || "Unknown"
          : "Unknown";
        v211.textContent = "S" + v216 + " E" + v215 + " · " + v233;
        v212 =
          location.pathname +
          "?id=" +
          id +
          "&season=" +
          v216 +
          "&episode=" +
          v215 +
          "&ap=1";
        v213 = true;
        v214();
      })
      .catch(function () {});
    v210.addEventListener("click", function () {
      if (v212) {
        location.href = v212;
      }
    });
    v4.addEventListener("timeupdate", v214);
    v4.addEventListener("durationchange", v214);
    v4.addEventListener("ended", function () {
      var v1 = s ? id + "_s" + s + "_e" + (e || "1") : id;
      v76(v1);
      var v2 = parseInt(e || "1") + 1;
      var v233 = parseInt(s);
      v209.style.display = "none";
      var v234 = {};
      if (window.store && window.store.sessionToken) {
        v234["X-Session-Token"] = window.store.sessionToken;
      }
      fetch(
        window.baseURL +
          "/api/tv?id=" +
          id +
          "&season=" +
          v233 +
          "&episode=" +
          v2,
        {
          headers: v234,
        },
      )
        .then(function (arg3) {
          return arg3.json();
        })
        .then(function (arg3) {
          if (arg3.error || !arg3.url) {
            fetch(
              window.baseURL +
                "/api/tv?id=" +
                id +
                "&season=" +
                (v233 + 1) +
                "&episode=1",
              {
                headers: v234,
              },
            )
              .then(function (arg4) {
                return arg4.json();
              })
              .then(function (arg4) {
                if (arg4.error || !arg4.url) {
                  return;
                }
                var v237 = document.getElementById("now-playing-toast");
                if (!v237) {
                  return;
                }
                var v238 = arg4.meta
                  ? arg4.meta.title || arg4.meta.name || "Unknown"
                  : "Unknown";
                v238 += " · S" + (v233 + 1) + "E1";
                v237.innerHTML =
                  '<div class="np-glow"></div><div class="np-inner"><span class="np-label">Up Next</span><span class="np-title">“' +
                  v238 +
                  "”</span></div>";
                v237.className = "";
                setTimeout(function () {
                  v237.classList.add("enter");
                  setTimeout(function () {
                    v237.classList.remove("enter");
                    v237.classList.add("exit");
                    setTimeout(function () {
                      location.href =
                        location.pathname +
                        "?id=" +
                        id +
                        "&season=" +
                        (v233 + 1) +
                        "&episode=1&ap=1";
                    }, 800);
                  }, 3800);
                }, 400);
              })
              .catch(function () {});
            return;
          }
          var v235 = document.getElementById("now-playing-toast");
          if (!v235) {
            return;
          }
          var v236 = arg3.meta
            ? arg3.meta.title || arg3.meta.name || "Unknown"
            : "Unknown";
          v236 += " · S" + v233 + "E" + v2;
          v235.innerHTML =
            '<div class="np-glow"></div><div class="np-inner"><span class="np-label">Up Next</span><span class="np-title">“' +
            v236 +
            "”</span></div>";
          v235.className = "";
          setTimeout(function () {
            v235.classList.add("enter");
            setTimeout(function () {
              v235.classList.remove("enter");
              v235.classList.add("exit");
              setTimeout(function () {
                location.href =
                  location.pathname +
                  "?id=" +
                  id +
                  "&season=" +
                  v233 +
                  "&episode=" +
                  v2 +
                  "&ap=1";
              }, 800);
            }, 3800);
          }, 400);
        })
        .catch(function () {});
    });
  }
  window._checkAndShowNextEpBtn = v214;
  window._getNextEpBtn = function () {
    return v209;
  };
  window._isNextEpReady = function () {
    return v213;
  };
  if (s) {
    v209.style.display = "none";
    var v215 = parseInt(e || "1") + 1;
    var v216 = parseInt(s);
    fetch(
      window.baseURL +
        "/api/tv?id=" +
        id +
        "&season=" +
        _nextS +
        "&episode=" +
        _nextE,
      {
        headers: {
          "X-Session-Token":
            window.store && window.store.sessionToken
              ? window.store.sessionToken
              : "",
        },
      },
    )
      .then(function (arg3) {
        return arg3.json();
      })
      .then(function (arg3) {
        var v233 = arg3.meta
          ? arg3.meta.title || arg3.meta.name || "Unknown"
          : "Unknown";
        v211.textContent = "S" + v216 + " E" + v215 + " · " + v233;
        v212 =
          location.pathname +
          "?id=" +
          id +
          "&season=" +
          v216 +
          "&episode=" +
          v215 +
          "&ap=1";
        v213 = true;
        v214();
      })
      .catch(function () {});
    v210.addEventListener("click", function () {
      if (v212) {
        location.href = v212;
      }
    });
    v4.addEventListener("timeupdate", v214);
    v4.addEventListener("durationchange", v214);
    v4.addEventListener("ended", function () {
      var v1 = s ? id + "_s" + s + "_e" + (e || "1") : id;
      v76(v1);
      var v2 = parseInt(e || "1") + 1;
      var v233 = parseInt(s);
      v209.style.display = "none";
      var v234 = {};
      if (window.store && window.store.sessionToken) {
        v234["X-Session-Token"] = window.store.sessionToken;
      }
      fetch(endpoint, {
        headers: v234,
      });
      fetch(
        window.baseURL +
          "/api/tv?id=" +
          id +
          "&season=" +
          v233 +
          "&episode=" +
          v2,
        {
          headers: v234,
        },
      )
        .then(function (arg3) {
          return arg3.json();
        })
        .then(function (arg3) {
          if (arg3.error || !arg3.url) {
            fetch(
              window.baseURL +
                "/api/tv?id=" +
                id +
                "&season=" +
                (v233 + 1) +
                "&episode=1",
              {
                headers: v234,
              },
            )
              .then(function (arg4) {
                return arg4.json();
              })
              .then(function (arg4) {
                if (arg4.error || !arg4.url) {
                  return;
                }
                var v237 = document.getElementById("now-playing-toast");
                var v238 = arg4.meta
                  ? arg4.meta.title || arg4.meta.name || "Unknown"
                  : "Unknown";
                v238 += " · S" + (v233 + 1) + "E1";
                v237.innerHTML =
                  '<div class="np-glow"></div><div class="np-inner"><span class="np-label">Up Next</span><span class="np-title">“' +
                  v238 +
                  "”</span></div>";
                v237.className = "";
                setTimeout(function () {
                  v237.classList.add("enter");
                  setTimeout(function () {
                    v237.classList.remove("enter");
                    v237.classList.add("exit");
                    setTimeout(function () {
                      location.href =
                        location.pathname +
                        "?id=" +
                        id +
                        "&season=" +
                        (v233 + 1) +
                        "&episode=1&ap=1";
                    }, 800);
                  }, 3800);
                }, 400);
              })
              .catch(function () {});
            return;
          }
          var v235 = document.getElementById("now-playing-toast");
          var v236 = arg3.meta
            ? arg3.meta.title || arg3.meta.name || "Unknown"
            : "Unknown";
          v236 += " · S" + v233 + "E" + v2;
          v235.innerHTML =
            '<div class="np-glow"></div><div class="np-inner"><span class="np-label">Up Next</span><span class="np-title">“' +
            v236 +
            "”</span></div>";
          v235.className = "";
          setTimeout(function () {
            v235.classList.add("enter");
            setTimeout(function () {
              v235.classList.remove("enter");
              v235.classList.add("exit");
              setTimeout(function () {
                location.href =
                  location.pathname +
                  "?id=" +
                  id +
                  "&season=" +
                  v233 +
                  "&episode=" +
                  v2 +
                  "&ap=1";
              }, 800);
            }, 3800);
          }, 400);
        })
        .catch(function () {});
    });
  }
  var v217 = document.getElementById("player");
  if (v217 && window.getComputedStyle(v217).position === "static") {
    v217.style.position = "relative";
  }
  v4.style.pointerEvents = "none";
  var v218 = document.getElementById("click-overlay");
  if (v218) {
    v218.remove();
  }
  var v219 = document.createElement("div");
  v219.id = "click-overlay";
  v219.style.cssText = "position:fixed;inset:0;z-index:18;";
  v4.parentElement.insertBefore(v219, v4.nextSibling);
  var v220 = false;
  function v221(arg3) {
    if (!arg3) {
      return false;
    }
    var v233 = [];
    if (typeof arg3.composedPath === "function") {
      v233 = arg3.composedPath();
    } else if (arg3.target) {
      v233 = [arg3.target];
    }
    return v233.some(function (arg4) {
      return (
        !!arg4 &&
        (arg4 === v17 ||
          arg4 === v16 ||
          (!!arg4.closest && !!arg4.closest && !!arg4.closest("#center-flash")))
      );
    });
  }
  function v222(arg3) {
    if (v51 || v49) {
      return;
    }
    var v233 = window.matchMedia("(pointer: coarse)").matches;
    if (v233 && v50 && v221(arg3)) {
      window.haptic();
      v109();
      var v234 = document.getElementById("v") || v4;
      try {
        v234.playbackRate = v72;
      } catch (v1) {}
      if (v234.paused) {
        v234.play();
      } else {
        v234.pause();
      }
      return;
    }
    if (v233) {
      if (!v50) {
        showUI(true);
        v53 = Date.now() + 600;
      } else {
        hideUI();
        v52 = Date.now() + 600;
      }
      return;
    }
    if (!v50) {
      showUI(true);
      v53 = Date.now() + 600;
      return;
    }
    window.haptic();
    v109();
    var v234 = document.getElementById("v") || v4;
    if (Date.now() < v53) {
      return;
    }
    if (v234.paused) {
      v234.play();
    } else {
      v234.pause();
    }
  }
  v219.addEventListener(
    "touchend",
    function (arg3) {
      v220 = true;
      v222(arg3);
    },
    {
      passive: true,
    },
  );
  v219.addEventListener("click", function (arg3) {
    if (v220) {
      v220 = false;
      return;
    }
    if (v51 || v49) {
      return;
    }
    v222(arg3);
  });
  document.getElementById("player").addEventListener("click", function (arg3) {
    if (v51 || v49) {
      return;
    }
    var v233 = document.getElementById("click-overlay");
    if (v233 && (v233 === arg3.target || v233.contains(arg3.target))) {
      return;
    }
    if (v5.contains(arg3.target)) {
      return;
    }
    if (v30 && v30.contains(arg3.target)) {
      return;
    }
    if (v29 && v29.contains(arg3.target)) {
      return;
    }
    if (v33 && v33.contains(arg3.target)) {
      return;
    }
    if (arg3.target.closest && arg3.target.closest(".cf-skip-btn")) {
      return;
    }
    if (!v50) {
      showUI(true);
      v53 = Date.now() + 600;
      return;
    }
    hideUI();
  });
  var v223 = false;
  var v224 = false;
  var v225 = false;
  var v226 = 1;
  var v227 = document.getElementById("player");
  var v228 = null;
  var v229 = null;
  var v230 = 0;
  function v231() {
    if (Date.now() < v230) {
      return;
    }
    if (v223) {
      return;
    }
    v223 = true;
    v224 = true;
    v225 = v4.paused;
    v226 = v72;
    if (v4.paused) {
      var v1 = v4.play();
      if (v1 !== undefined) {
        v1.then(function () {
          if (v223) {
            v4.playbackRate = 2;
          } else {
            v4.pause();
          }
        }).catch(function () {});
      }
    }
    v4.playbackRate = 2;
    v227.style.cursor = "grabbing";
    var v2 = document.getElementById("speed-boost-badge");
    if (!v2) {
      v2 = document.createElement("div");
      v2.id = "speed-boost-badge";
      v2.style.cssText =
        "position:absolute;top:18px;left:50%;transform:translateX(-50%);z-index:30;background:rgba(0,0,0,0.65);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);color:var(--white);font-family:var(--font);font-size:13px;font-weight:700;padding:6px 16px;border-radius:100px;display:flex;align-items:center;gap:7px;letter-spacing:0.03em;opacity:0;transition:opacity 0.18s ease;pointer-events:none;";
      v2.innerHTML =
        '<i class="fa-solid fa-forward" style="font-size:12px;"></i> 2x speed';
      document.getElementById("player").appendChild(v2);
    }
    v229 = requestAnimationFrame(function () {
      v229 = null;
      v2.style.opacity = "1";
    });
  }
  function v232() {
    clearTimeout(v228);
    v228 = null;
    if (v229) {
      cancelAnimationFrame(v229);
      v229 = null;
    }
    v223 = false;
    v4.playbackRate = v226;
    v224 = false;
    if (v225) {
      var v1 = v4.play();
      if (v1 !== undefined) {
        v1.then(function () {
          v4.pause();
        }).catch(function () {});
      } else {
        v4.pause();
      }
    }
    v227.style.cursor = "";
    var v2 = document.getElementById("speed-boost-badge");
    if (v2) {
      v2.style.opacity = "0";
    }
  }
  v227.addEventListener("mousedown", function (arg3) {
    if (v5.contains(arg3.target)) {
      return;
    }
    if (v30 && v30.contains(arg3.target)) {
      return;
    }
    if (v29.contains(arg3.target)) {
      return;
    }
    if (arg3.button !== 0) {
      return;
    }
    v224 = false;
    if (v73) {
      v228 = setTimeout(function () {
        v231();
      }, 600);
    }
  });
  v227.addEventListener("mouseup", function (arg3) {
    v232();
  });
  v227.addEventListener("mouseleave", v232);
  v227.addEventListener(
    "click",
    function (arg3) {
      if (v224) {
        v224 = false;
        arg3.stopImmediatePropagation();
        return;
      }
    },
    true,
  );
  v227.addEventListener(
    "touchstart",
    function (arg3) {
      if (v5.contains(arg3.target)) {
        return;
      }
      if (v30 && v30.contains(arg3.target)) {
        return;
      }
      if (v29.contains(arg3.target)) {
        return;
      }
      if (v8.contains(arg3.target)) {
        return;
      }
      v224 = false;
      if (Date.now() >= v230 && v73) {
        v228 = setTimeout(function () {
          if (!v49) {
            v231();
          }
        }, 600);
      }
    },
    {
      passive: true,
    },
  );
  v227.addEventListener("touchend", function (arg3) {
    v232();
  });
  v4.addEventListener("play", function () {
    try {
      if (Math.abs(v4.playbackRate - v72) > 0.01 && !v223 && !v224) {
        v4.playbackRate = v72;
      }
    } catch (v1) {}
  });
  (function () {
    var v1 = document.getElementById("sub-customize-open-btn");
    var v2 = document.getElementById("sub-custom-back-btn");
    var v233 = document.getElementById("sub-lang-group-view");
    var v234 = document.getElementById("sub-custom-view");
    var v235 = document.getElementById("sub-view-title");
    var v236 = document.getElementById("sub-customize-open-btn");
    var v237 = document.getElementById("sub-main-back-btn");
    var v238 = document.getElementById("sub-advanced-btn");
    var v239 = document.getElementById("sub-advanced-content");
    var v240 = {
      default: {
        font: "sans",
        size: "medium",
        color: "#ffffff",
        bgColor: "#000000",
        bgOpacity: 0.75,
        textShadow: "shadow",
        pos: "mid",
        weight: "500",
      },
      clean: {
        font: "sans",
        size: "medium",
        color: "#ffffff",
        bgColor: "transparent",
        bgOpacity: 0,
        textShadow: "shadow",
        pos: "mid",
        weight: "500",
      },
      "high-contrast": {
        font: "sans",
        size: "medium",
        color: "#ffffff",
        bgColor: "#000000",
        bgOpacity: 1,
        textShadow: "none",
        pos: "mid",
        weight: "700",
      },
      cinema: {
        font: "serif",
        size: "medium",
        color: "#ffff00",
        bgColor: "#000000",
        bgOpacity: 0.9,
        textShadow: "both",
        pos: "mid",
        weight: "500",
      },
    };
    function v241(arg3) {
      var v276 = v240[arg3];
      if (!v276) {
        return;
      }
      Object.keys(v276).forEach(function (arg4) {
        v60[arg4] = v276[arg4];
      });
      v78();
      v77();
      v242();
      v243();
    }
    function v242() {
      document.querySelectorAll(".sub-size-btn").forEach(function (arg3) {
        arg3.classList.toggle("active", arg3.dataset.size === v60.size);
      });
      document.querySelectorAll(".sub-pos-btn").forEach(function (arg3) {
        arg3.classList.toggle("active", arg3.dataset.pos === v60.pos);
      });
      var v276 = "none";
      if (v60.bgOpacity > 0.8) {
        v276 = "dark";
      } else if (v60.bgOpacity > 0.3) {
        v276 = "light";
      }
      document.querySelectorAll(".sub-bg-btn").forEach(function (arg3) {
        arg3.classList.toggle("active", arg3.dataset.bg === v276);
      });
      var v277 = "default";
      Object.keys(v240).forEach(function (arg3) {
        var v278 = v240[arg3];
        var v279 = true;
        Object.keys(v278).forEach(function (arg4) {
          if (v60[arg4] !== v278[arg4]) {
            v279 = false;
          }
        });
        if (v279) {
          v277 = arg3;
        }
      });
      document.querySelectorAll(".sub-preset-btn").forEach(function (arg3) {
        arg3.classList.toggle("active", arg3.dataset.preset === v277);
      });
    }
    function v243() {
      var v276 = document.getElementById("sub-bg-opacity-range");
      var v277 = document.getElementById("sub-bg-opacity-val");
      if (v276 && v277) {
        v276.value = parseFloat(v60.bgOpacity) * 100;
        v277.textContent = Math.round(parseFloat(v60.bgOpacity) * 100) + "%";
      }
      var v278 = document.getElementById("sub-text-size-range");
      var v279 = document.getElementById("sub-text-size-val");
      if (v278 && v279) {
        v278.value = 100;
        v279.textContent = "100%";
      }
      var v280 = document.getElementById("sub-text-style-select");
      if (v280) {
        v280.value = v60.font;
      }
      var v281 = document.getElementById("sub-bold-toggle");
      if (v281) {
        v281.classList.toggle("on", v60.weight === "700");
      }
    }
    document.querySelectorAll(".sub-preset-btn").forEach(function (arg3) {
      arg3.addEventListener("click", function () {
        var v276 = this.dataset.preset;
        v241(v276);
        window.haptic(6);
      });
    });
    document.querySelectorAll(".sub-size-btn").forEach(function (arg3) {
      arg3.addEventListener("click", function () {
        v60.size = this.dataset.size;
        v78();
        v77();
        v242();
        window.haptic(6);
      });
    });
    document.querySelectorAll(".sub-pos-btn").forEach(function (arg3) {
      arg3.addEventListener("click", function () {
        v60.pos = this.dataset.pos;
        v78();
        v77();
        v242();
        window.haptic(6);
      });
    });
    document.querySelectorAll(".sub-bg-btn").forEach(function (arg3) {
      arg3.addEventListener("click", function () {
        var v276 = this.dataset.bg;
        if (v276 === "none") {
          v60.bgOpacity = 0;
        } else if (v276 === "light") {
          v60.bgOpacity = 0.5;
        } else if (v276 === "dark") {
          v60.bgOpacity = 0.9;
        }
        v78();
        v77();
        v242();
        v243();
        window.haptic(6);
      });
    });
    if (v238) {
      v238.addEventListener("click", function (arg3) {
        arg3.stopPropagation();
        arg3.stopImmediatePropagation();
        var v276 = document.getElementById("sub-advanced-content");
        var v277 = this.classList.contains("expanded");
        if (v277) {
          this.classList.remove("expanded");
          if (v276) {
            v276.style.display = "none";
          }
        } else {
          this.classList.add("expanded");
          if (v276) {
            v276.style.display = "flex";
            v243();
          }
        }
        window.haptic(6);
      });
    }
    if (v1) {
      v1.addEventListener("click", function () {
        document.getElementById("sub-lang-group-view").style.display = "none";
        document.getElementById("sub-custom-view").style.display = "flex";
        v242();
        v243();
      });
    }
    if (v2) {
      v2.addEventListener("click", function () {
        document.getElementById("sub-custom-view").style.display = "none";
        document.getElementById("sub-lang-group-view").style.display = "flex";
      });
    }
    if (v237) {
      v237.addEventListener("click", function (arg3) {
        arg3.stopPropagation();
        var v276 = document.getElementById("sub-custom-view");
        var v277 = document.getElementById("sub-lang-group-view");
        var v278 = document.getElementById("sub-advanced-content");
        var v279 = document.getElementById("sub-advanced-btn");
        if (
          v276 &&
          (v276.style.display === "flex" || v276.style.display === "block")
        ) {
          v276.style.display = "none";
          if (v277) {
            v277.style.display = "flex";
          }
          if (v235) {
            v235.textContent = "Subtitles";
          }
          if (v236) {
            v236.style.display = "";
          }
          if (v279) {
            v279.classList.remove("expanded");
          }
          if (v278) {
            v278.style.display = "none";
          }
        } else {
          v169("main");
        }
      });
    }
    document.querySelectorAll(".sub-special-item").forEach(function (arg3) {
      arg3.addEventListener("click", function () {
        var v276 = arg3.dataset.sub;
        document
          .querySelectorAll(".sub-special-item, .sub-lang-item")
          .forEach(function (arg4) {
            arg4.classList.remove("active-sub-item");
            var v279 = arg4.querySelector(".sub-active-check");
            if (v279) {
              v279.style.display = "none";
            }
          });
        arg3.classList.add("active-sub-item");
        var v277 = arg3.querySelector(".sub-active-check");
        if (v277) {
          v277.style.display = "block";
        }
        if (v276 === "off") {
          v60.activeTrack = -1;
          v60.cues = [];
          v42.textContent = "";
          v162 = "";
          document.getElementById("lbl-subtitle").textContent = "Off";
          var v278 = document.getElementById("subtitle-toggle");
          if (v278) {
            v278.classList.remove("on");
          }
          window.haptic(6);
        }
      });
    });
    function v244(arg3) {
      var v276 =
        (((arg3.value - arg3.min) / (arg3.max - arg3.min)) * 100).toFixed(1) +
        "%";
      arg3.style.setProperty("--val", v276);
    }
    var v245 = document.getElementById("sub-bg-opacity-range");
    var v246 = document.getElementById("sub-bg-opacity-val");
    if (v245) {
      v244(v245);
      v245.value = parseFloat(v60.bgOpacity) * 100;
      v246.textContent = Math.round(parseFloat(v60.bgOpacity) * 100) + "%";
      v245.addEventListener("input", function () {
        v60.bgOpacity = (this.value / 100).toFixed(2);
        v246.textContent = this.value + "%";
        v244(this);
        v78();
        v77();
      });
    }
    var v247 = document.getElementById("sub-blur-intensity-range");
    var v248 = document.getElementById("sub-blur-intensity-val");
    if (v247) {
      v244(v247);
      v247.addEventListener("input", function () {
        v248.textContent = this.value + "%";
        v244(this);
        var v276 = ((parseFloat(this.value) / 100) * 20).toFixed(1) + "px";
        v42.style.backdropFilter = "blur(" + v276 + ")";
        v42.style.webkitBackdropFilter = "blur(" + v276 + ")";
      });
    }
    var v249 = document.getElementById("sub-text-size-range");
    var v250 = document.getElementById("sub-text-size-val");
    var v251 = {
      small: 14,
      medium: 18,
      large: 23,
      xlarge: 28,
      xxlarge: 34,
    };
    if (v249) {
      v244(v249);
      v249.addEventListener("input", function () {
        v250.textContent = this.value + "%";
        v244(this);
        var v276 = v251[v60.size] || 18;
        v42.style.fontSize =
          (v276 * (parseFloat(this.value) / 100)).toFixed(1) + "px";
      });
    }
    var v252 = document.getElementById("sub-delay-range");
    var v253 = document.getElementById("sub-delay-val");
    var v254 = 0;
    if (v252) {
      v244(v252);
      v252.addEventListener("input", function () {
        v254 = parseFloat(this.value);
        v253.textContent = v254.toFixed(1) + "s";
        v244(this);
      });
    }
    var v255 = document.getElementById("sub-delay-heard");
    var v256 = document.getElementById("sub-delay-saw");
    if (v255 && v252) {
      v255.addEventListener("click", function () {
        v252.value = Math.max(-10, parseFloat(v252.value) - 0.1);
        v254 = parseFloat(v252.value);
        v253.textContent = v254.toFixed(1) + "s";
        v244(v252);
      });
    }
    if (v256 && v252) {
      v256.addEventListener("click", function () {
        v252.value = Math.min(10, parseFloat(v252.value) + 0.1);
        v254 = parseFloat(v252.value);
        v253.textContent = v254.toFixed(1) + "s";
        v244(v252);
      });
    }
    var v257 = document.getElementById("sub-text-style-select");
    if (v257) {
      v257.value = v60.font;
      v257.addEventListener("change", function () {
        v60.font = this.value;
        v78();
        v77();
        window.haptic(6);
      });
    }
    var v258 = document.getElementById("sub-bold-toggle");
    if (v258) {
      if (v60.weight === "700") {
        v258.classList.add("on");
      }
      v258.addEventListener("click", function () {
        this.classList.toggle("on");
        v60.weight = this.classList.contains("on") ? "700" : "500";
        v78();
        v77();
      });
    }
    var v259 = document.getElementById("sub-fix-caps-toggle");
    if (v259) {
      v259.addEventListener("click", function () {
        this.classList.toggle("on");
        var v276 = this.classList.contains("on");
        v42.style.textTransform = v276 ? "capitalize" : "";
      });
    }
    var v260 = document.getElementById("sub-bg-blur-toggle");
    if (v260) {
      v260.classList.add("on");
      v260.addEventListener("click", function () {
        this.classList.toggle("on");
        var v276 = this.classList.contains("on");
        if (!v276) {
          v42.style.backdropFilter = "none";
          v42.style.webkitBackdropFilter = "none";
        } else {
          var v277 = v247 ? v247.value : 50;
          var v278 = ((parseFloat(v277) / 100) * 20).toFixed(1) + "px";
          v42.style.backdropFilter = "blur(" + v278 + ")";
          v42.style.webkitBackdropFilter = "blur(" + v278 + ")";
        }
      });
    }
    var v261 = document.getElementById("native-sub-toggle");
    if (v261) {
      v261.addEventListener("click", function () {
        this.classList.toggle("on");
      });
    }
    var v262 = document.querySelectorAll(".sub-swatch");
    var v263 = document.getElementById("sub-custom-color-picker");
    v262.forEach(function (arg3) {
      arg3.addEventListener("click", function () {
        if (arg3.dataset.color === "custom") {
          v263.click();
          return;
        }
        v262.forEach(function (arg4) {
          arg4.classList.remove("sub-swatch-active");
          arg4.innerHTML =
            arg4.dataset.color === "custom"
              ? '<i class="fa-solid fa-paint-brush" style="color:var(--white-60);font-size:12px;"></i>'
              : "";
        });
        arg3.classList.add("sub-swatch-active");
        arg3.innerHTML =
          '<i class="fa-solid fa-check" style="color:#000;"></i>';
        v60.color = arg3.dataset.color;
        v78();
        v77();
      });
    });
    if (v263) {
      v263.addEventListener("change", function () {
        v262.forEach(function (arg3) {
          arg3.classList.remove("sub-swatch-active");
          arg3.innerHTML =
            arg3.dataset.color === "custom"
              ? '<i class="fa-solid fa-paint-brush" style="color:var(--white-60);font-size:12px;"></i>'
              : "";
        });
        var v276 = document.querySelector(".sub-swatch-brush");
        if (v276) {
          v276.style.background = v263.value;
          v276.classList.add("sub-swatch-active");
        }
        v60.color = v263.value;
        v78();
        v77();
      });
    }
    var v264 = document.querySelectorAll(".sub-bg-swatch");
    var v265 = document.getElementById("sub-custom-bg-color-picker");
    v264.forEach(function (arg3) {
      arg3.addEventListener("click", function () {
        if (arg3.dataset.bgColor === "custom") {
          v265.click();
          return;
        }
        v264.forEach(function (arg4) {
          arg4.classList.remove("sub-bg-swatch-active");
          arg4.innerHTML =
            arg4.dataset.bgColor === "custom"
              ? '<i class="fa-solid fa-paint-brush" style="color:var(--white-60);font-size:12px;"></i>'
              : "";
        });
        arg3.classList.add("sub-bg-swatch-active");
        arg3.innerHTML =
          '<i class="fa-solid fa-check" style="color:#000;"></i>';
        v60.bgColor = arg3.dataset.bgColor;
        v78();
        v77();
      });
    });
    if (v265) {
      v265.addEventListener("change", function () {
        v264.forEach(function (arg3) {
          arg3.classList.remove("sub-bg-swatch-active");
          arg3.innerHTML =
            arg3.dataset.bgColor === "custom"
              ? '<i class="fa-solid fa-paint-brush" style="color:var(--white-60);font-size:12px;"></i>'
              : "";
        });
        var v276 = document.querySelector(".sub-bg-swatch-brush");
        if (v276) {
          v276.style.background = v265.value;
          v276.classList.add("sub-bg-swatch-active");
        }
        v60.bgColor = v265.value;
        v78();
        v77();
      });
    }
    v264.forEach(function (arg3) {
      arg3.classList.remove("sub-bg-swatch-active");
      arg3.innerHTML =
        arg3.dataset.bgColor === "custom"
          ? '<i class="fa-solid fa-paint-brush" style="color:var(--white-60);font-size:12px;"></i>'
          : "";
    });
    if (v60.bgColor === "transparent") {
      var v266 = document.querySelector(
        '.sub-bg-swatch[data-bg-color="transparent"]',
      );
      if (v266) {
        v266.classList.add("sub-bg-swatch-active");
        v266.innerHTML =
          '<i class="fa-solid fa-check" style="color:#000;"></i>';
      }
    } else {
      var v267 = document.querySelector(
        '.sub-bg-swatch[data-bg-color="' + v60.bgColor + '"]',
      );
      if (v267) {
        v267.classList.add("sub-bg-swatch-active");
        v267.innerHTML =
          '<i class="fa-solid fa-check" style="color:#000;"></i>';
      } else {
        var v268 = document.querySelector(".sub-bg-swatch-brush");
        if (v268) {
          v268.style.background = v60.bgColor;
          v268.classList.add("sub-bg-swatch-active");
        }
        if (v265) {
          v265.value = v60.bgColor;
        }
      }
    }
    var v269 = document.getElementById("sub-pos-select");
    if (v269) {
      v269.value = v60.pos;
      v269.addEventListener("change", function () {
        v60.pos = this.value;
        v78();
        v77();
        window.haptic(6);
      });
    }
    var v270 = document.getElementById("sub-overall-opacity-range");
    var v271 = document.getElementById("sub-overall-opacity-val");
    if (v270) {
      v244(v270);
      v270.value = parseFloat(v60.overallOpacity) * 100;
      v271.textContent = Math.round(parseFloat(v60.overallOpacity) * 100) + "%";
      v270.addEventListener("input", function () {
        v60.overallOpacity = (this.value / 100).toFixed(2);
        v271.textContent = this.value + "%";
        v244(this);
        v78();
        v77();
      });
    }
    var v272 = document.getElementById("sub-text-shadow-select");
    if (v272) {
      v272.value = v60.textShadow;
      v272.addEventListener("change", function () {
        v60.textShadow = this.value;
        v78();
        v77();
        window.haptic(6);
      });
    }
    var v273 = document.getElementById("sub-custom-reset-btn");
    if (v273) {
      v273.addEventListener("click", function () {
        v60.bgOpacity = "0.75";
        v60.color = "#ffffff";
        v60.bgColor = "#000000";
        v60.overallOpacity = "1";
        v60.textShadow = "shadow";
        v60.font = "sans";
        v60.size = "medium";
        v60.pos = "mid";
        v60.weight = "500";
        if (v245) {
          v245.value = 75;
          v246.textContent = "75%";
          v244(v245);
        }
        if (v247) {
          v247.value = 50;
          v248.textContent = "50%";
          v244(v247);
        }
        if (v249) {
          v249.value = 100;
          v250.textContent = "100%";
          v244(v249);
        }
        if (v252 && v253) {
          v252.value = 0;
          v254 = 0;
          v253.textContent = "0.0s";
          v244(v252);
        }
        if (v257) {
          v257.value = "sans";
        }
        if (v269) {
          v269.value = "mid";
        }
        if (v272) {
          v272.value = "shadow";
        }
        if (v258) {
          v258.classList.remove("on");
        }
        if (v259) {
          v259.classList.remove("on");
        }
        if (v260) {
          v260.classList.add("on");
        }
        if (v261) {
          v261.classList.remove("on");
        }
        if (v270) {
          v270.value = 100;
          v271.textContent = "100%";
          v244(v270);
        }
        v42.style.textTransform = "";
        v78();
        v77();
        window.haptic(6);
      });
    }
    var v274 = v4.onSubTimeUpdate;
    function v275() {
      if (v60.activeTrack < 0 || !v60.cues.length) {
        if (v162 !== "") {
          v42.textContent = "";
          v162 = "";
        }
        return;
      }
      var v276 = v161(v60.cues, v4.currentTime - v254);
      if (v276 !== v162) {
        v42.textContent = v276;
        v162 = v276;
      }
    }
    v4.removeEventListener("timeupdate", v163);
    v4.addEventListener("timeupdate", v275);
  })();
  document.querySelectorAll(".settings-view").forEach(function (arg3) {
    arg3.style.display = "none";
    arg3.classList.remove("active");
  });
  if (sourcesLoaded && sources.length) {
    buildSourceList();
  }
}
