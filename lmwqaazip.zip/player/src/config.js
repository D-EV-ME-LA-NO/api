// Fully local backend: every /api/... call goes to this site's PHP API folder.
// No external Vyla infrastructure is used anymore.
export const TMDB_KEY = "3f6703f3e2a0b2b40fe4fbb3e1546244";
export const baseURL = "";
export const liveBaseURL = "";
